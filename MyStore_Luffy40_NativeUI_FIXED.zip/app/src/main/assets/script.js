

/* =========================================
   SUPABASE CONNECTION (PHASE 2A)
   This is a connection test only. Existing local
   application data remains unchanged until the next phase.
========================================= */
const SUPABASE_CONFIG = Object.freeze({
  url: "https://bpgbbdrhynkdiyzucgsb.supabase.co",
  publishableKey: "sb_publishable_L1Z-PolqDiQk8_3MlzZQIA__t9LC8eW"
});

function ensureSupabaseStatusUI() {
  const adminScreen = document.getElementById("adminScreen");
  if (!adminScreen || document.getElementById("supabaseConnectionStatus")) return;
  const status = document.createElement("div");
  status.id = "supabaseConnectionStatus";
  status.textContent = "☁️ جاري الاتصال بـ Supabase...";
  status.setAttribute("role", "status");
  status.style.cssText = "margin:10px 0;padding:9px 12px;border-radius:10px;font-size:13px;text-align:center;background:rgba(255,193,7,.12);color:#b88600;border:1px solid rgba(255,193,7,.25);";
  adminScreen.prepend(status);
}

function setSupabaseStatus(connected, detail = "") {
  const status = document.getElementById("supabaseConnectionStatus");
  if (!status) return;
  if (connected) {
    status.textContent = "☁️ متصل بـ Supabase";
    status.style.background = "rgba(34,197,94,.12)";
    status.style.color = "#15803d";
    status.style.borderColor = "rgba(34,197,94,.25)";
  } else {
    status.textContent = "☁️ وضع محلي" + (detail ? " — تعذر الاتصال بـ Supabase" : "");
    status.style.background = "rgba(239,68,68,.10)";
    status.style.color = "#b91c1c";
    status.style.borderColor = "rgba(239,68,68,.22)";
  }
}

async function testSupabaseConnection() {
  ensureSupabaseStatusUI();
  const endpoint = `${SUPABASE_CONFIG.url}/rest/v1/store_settings?select=id&limit=1`;
  try {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: {
        apikey: SUPABASE_CONFIG.publishableKey,
        Accept: "application/json"
      },
      cache: "no-store"
    });
    if (!response.ok) {
      const body = await response.text().catch(() => "");
      throw new Error(`HTTP ${response.status}${body ? `: ${body.slice(0, 180)}` : ""}`);
    }
    setSupabaseStatus(true);
    console.info("MyStore: Supabase connection successful.");
    return true;
  } catch (error) {
    setSupabaseStatus(false, true);
    console.warn("MyStore: Supabase connection failed.", error);
    return false;
  }
}


/* =========================================
   SUPABASE AUTH (PHASE 2B)
   Customer registration/login now uses Supabase Auth.
   Legacy local accounts remain available as a fallback so
   Phase 1 data and behavior are not lost during migration.
========================================= */
const SUPABASE_SESSION_KEY = "mystore_supabase_session_v1";

function getSupabaseSession() {
  try {
    const raw = localStorage.getItem(SUPABASE_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function saveSupabaseSession(session) {
  if (!session) {
    localStorage.removeItem(SUPABASE_SESSION_KEY);
    return;
  }
  localStorage.setItem(SUPABASE_SESSION_KEY, JSON.stringify(session));
}

function supabaseHeaders(accessToken = "") {
  const headers = {
    apikey: SUPABASE_CONFIG.publishableKey,
    "Content-Type": "application/json",
    Accept: "application/json"
  };
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  return headers;
}

async function supabaseAuthRequest(path, body = {}, method = "POST", accessToken = "") {
  const response = await fetch(`${SUPABASE_CONFIG.url}/auth/v1/${path}`, {
    method,
    headers: supabaseHeaders(accessToken),
    body: method === "GET" ? undefined : JSON.stringify(body),
    cache: "no-store"
  });

  const text = await response.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }

  if (!response.ok) {
    const message = data?.msg || data?.message || data?.error_description || data?.error || `HTTP ${response.status}`;
    throw new Error(message);
  }
  return data;
}

function supabaseAuthErrorMessage(error) {
  const message = String(error?.message || "");
  const lower = message.toLowerCase();
  if (lower.includes("email not confirmed")) return "يجب تأكيد البريد الإلكتروني أولًا، ثم حاول تسجيل الدخول.";
  if (lower.includes("invalid login credentials")) return "البريد الإلكتروني أو كلمة المرور غير صحيحة.";
  if (lower.includes("user already registered") || lower.includes("already registered")) return "هذا البريد الإلكتروني مسجل بالفعل.";
  if (lower.includes("password should be at least")) return "كلمة المرور يجب أن تكون 6 أحرف على الأقل.";
  if (lower.includes("rate limit")) return "تم تجاوز عدد المحاولات المسموح بها مؤقتًا. حاول لاحقًا.";
  return message || "حدث خطأ أثناء الاتصال بخدمة الحسابات.";
}

function getAuthRedirectUrl() {
  // CodePen/preview-safe URL: never send the confirmation link to localhost.
  // Remove hash/query so Supabase can append its authentication result cleanly.
  try {
    const url = new URL(window.location.href);
    url.hash = "";
    url.search = "";
    return url.toString();
  } catch {
    return window.location.origin + window.location.pathname;
  }
}

async function supabaseSignUp(email, password, name) {
  const redirectTo = getAuthRedirectUrl();
  return supabaseAuthRequest(`signup?redirect_to=${encodeURIComponent(redirectTo)}`, {
    email,
    password,
    data: { full_name: name, role: "customer" }
  });
}

async function handleSupabaseAuthCallback() {
  // Supabase email confirmation may return the session in the URL hash.
  // Consume it here, save the session, then remove tokens from the address bar.
  const hash = String(window.location.hash || "").replace(/^#/, "");
  if (!hash) return false;

  const params = new URLSearchParams(hash);
  const accessToken = params.get("access_token");
  const refreshToken = params.get("refresh_token");
  const type = params.get("type");

  if (!accessToken || !refreshToken) return false;

  try {
    const userResponse = await fetch(`${SUPABASE_CONFIG.url}/auth/v1/user`, {
      method: "GET",
      headers: supabaseHeaders(accessToken),
      cache: "no-store"
    });

    if (!userResponse.ok) {
      throw new Error(`HTTP ${userResponse.status}`);
    }

    const user = await userResponse.json();
    const session = {
      access_token: accessToken,
      refresh_token: refreshToken,
      token_type: params.get("token_type") || "bearer",
      expires_in: Number(params.get("expires_in") || 3600),
      expires_at: Math.floor(Date.now() / 1000) + Number(params.get("expires_in") || 3600),
      user
    };

    saveSupabaseSession(session);
    const account = createLocalAccountFromSupabaseUser(user);
    if (account) setCurrentUserId(account.id);

    // Remove authentication tokens from the visible URL.
    try {
      const cleanUrl = new URL(window.location.href);
      cleanUrl.hash = "";
      window.history.replaceState({}, document.title, cleanUrl.toString());
    } catch {}

    if (type === "signup" || type === "recovery") {
      return true;
    }
    return true;
  } catch (error) {
    console.warn("MyStore: Supabase auth callback failed.", error);
    return false;
  }
}

async function supabaseSignIn(email, password) {
  return supabaseAuthRequest("token?grant_type=password", { email, password });
}

async function c4GetOwnerProfile(session) {
  if (!session?.user?.id || !session?.access_token) return null;
  const response = await fetch(`${SUPABASE_CONFIG.url}/rest/v1/profiles?select=id,role,full_name,email&id=eq.${encodeURIComponent(session.user.id)}&limit=1`, {
    headers: supabaseHeaders(session.access_token),
    cache: "no-store"
  });
  if (!response.ok) return null;
  const rows = await response.json();
  return Array.isArray(rows) ? (rows[0] || null) : null;
}

async function c4RouteAuthenticatedUserToCorrectArea(user, session) {
  const profile = await c4GetOwnerProfile(session);
  const role = String(profile?.role || "").toLowerCase();
  if (role === "admin" || role === "store_owner") {
    sessionStorage.setItem("ownerSupabaseRole", role);
    sessionStorage.setItem("ownerSupabaseUserId", user.id);
    sessionStorage.setItem(ADMIN_SESSION_KEY, "1");
    await openAdminDashboard();
    return true;
  }
  sessionStorage.removeItem("ownerSupabaseRole");
  sessionStorage.removeItem("ownerSupabaseUserId");
  sessionStorage.removeItem(ADMIN_SESSION_KEY);
  return false;
}

async function supabaseRefreshSession(session) {
  if (!session?.refresh_token) return null;
  try {
    const refreshed = await supabaseAuthRequest("token?grant_type=refresh_token", {
      refresh_token: session.refresh_token
    });
    saveSupabaseSession(refreshed);
    return refreshed;
  } catch (error) {
    console.warn("MyStore: Supabase session refresh failed.", error);
    saveSupabaseSession(null);
    return null;
  }
}

async function restoreSupabaseSession() {
  const session = getSupabaseSession();
  if (!session) return null;

  // Refresh on startup. Supabase returns a fresh access token.
  return await supabaseRefreshSession(session);
}

function createLocalAccountFromSupabaseUser(user) {
  if (!user?.id || !user?.email) return null;
  const accounts = getAccounts();
  let account = accounts.find(item => item.supabaseAuthId === user.id || item.id === user.id || String(item.email || "").toLowerCase() === String(user.email || "").toLowerCase());
  const name = user.user_metadata?.full_name || user.user_metadata?.name || user.email.split("@")[0];

  if (!account) {
    account = {
      id: user.id,
      supabaseAuthId: user.id,
      name,
      email: user.email.toLowerCase(),
      passwordHash: null,
      avatar: null,
      favorites: [],
      cart: [],
      shippingAddress: { fullName: name, phone: "", wilaya: "", commune: "", address: "", notes: "" },
      orders: [],
      createdAt: user.created_at || new Date().toISOString()
    };
    accounts.push(account);
  } else {
    account.supabaseAuthId = user.id;
    account.email = user.email.toLowerCase();
    account.name = name || account.name;
  }

  saveAccounts(accounts);
  return account;
}

async function signOutSupabase() {
  const session = getSupabaseSession();
  try {
    if (session?.access_token) {
      await supabaseAuthRequest("logout", {}, "POST", session.access_token);
    }
  } catch (error) {
    console.warn("MyStore: Supabase logout request failed.", error);
  } finally {
    saveSupabaseSession(null);
  }
}

const KEYS = {
  accounts: "mystore_accounts_v1",
  currentUser: "mystore_current_user_v1"
};


/* =========================================
   PRODUCTS
========================================= */

let PRODUCTS = [

  {
    id: 1,
    name: "هاتف ذكي Pro",
    category: "إلكترونيات",
    icon: "📱",
    price: 85000,
    description: "هاتف ذكي حديث بأداء قوي"
  },

  {
    id: 2,
    name: "سماعات لاسلكية",
    category: "إلكترونيات",
    icon: "🎧",
    price: 7500,
    description: "صوت نقي واتصال لاسلكي"
  },

  {
    id: 3,
    name: "حاسوب محمول",
    category: "إلكترونيات",
    icon: "💻",
    price: 125000,
    description: "حاسوب مناسب للعمل والدراسة"
  },

  {
    id: 4,
    name: "ساعة ذكية",
    category: "إلكترونيات",
    icon: "⌚",
    price: 18000,
    description: "تابع نشاطك وإشعاراتك"
  },

  {
    id: 5,
    name: "حذاء رياضي",
    category: "أزياء",
    icon: "👟",
    price: 9500,
    description: "حذاء رياضي مريح للاستخدام اليومي"
  },

  {
    id: 6,
    name: "حقيبة ظهر",
    category: "أزياء",
    icon: "🎒",
    price: 4200,
    description: "حقيبة عملية للدراسة والعمل"
  },

  {
    id: 7,
    name: "قميص أنيق",
    category: "أزياء",
    icon: "👕",
    price: 3200,
    description: "قميص أنيق ومريح"
  },

  {
    id: 8,
    name: "نظارات شمسية",
    category: "أزياء",
    icon: "🕶️",
    price: 2800,
    description: "تصميم عصري للاستخدام اليومي"
  },

  {
    id: 9,
    name: "مصباح مكتبي",
    category: "المنزل",
    icon: "💡",
    price: 2300,
    description: "إضاءة مناسبة للمكتب"
  },

  {
    id: 10,
    name: "كرسي مكتبي",
    category: "المنزل",
    icon: "🪑",
    price: 14500,
    description: "كرسي مريح للعمل والدراسة"
  },

  {
    id: 11,
    name: "زجاجة مياه",
    category: "الرياضة",
    icon: "🥤",
    price: 1800,
    description: "زجاجة عملية للرياضة"
  },

  {
    id: 12,
    name: "كرة قدم",
    category: "الرياضة",
    icon: "⚽",
    price: 3500,
    description: "كرة مناسبة للتدريب والمباريات"
  }

];


/* =========================================
   MANAGED PRODUCTS / ADMIN DATA
========================================= */
const ADMIN_PRODUCTS_KEY = "mystore_products_v1";
const ADMIN_SESSION_KEY = "mystore_admin_session_v1";
const ADMIN_CREDENTIALS = { username: "admin", password: "admin123" };

function getManagedProducts() {
  try {
    const raw = localStorage.getItem(ADMIN_PRODUCTS_KEY);
    if (!raw) return PRODUCTS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length ? parsed : PRODUCTS;
  } catch (error) {
    console.error("MyStore products storage error", error);
    return PRODUCTS;
  }
}

function normalizeProductImages(product) {
  const source = Array.isArray(product?.images)
    ? product.images
    : (product?.image ? [product.image] : []);
  return source
    .filter(value => typeof value === "string" && value.trim())
    .map(value => value.trim())
    .slice(0, 5);
}

function normalizeProduct(product) {
  const images = normalizeProductImages(product);
  return {
    ...product,
    images,
    image: images[0] || "",
    stock: Math.max(0, Number(product.stock ?? 0)),
    active: product.active !== false,
    featured: !!product.featured
  };
}

function saveManagedProducts(products) {
  const normalized = products.map(normalizeProduct);
  localStorage.setItem(ADMIN_PRODUCTS_KEY, JSON.stringify(normalized));
  PRODUCTS = normalized;
}

function initializeManagedProducts() {
  const stored = getManagedProducts();
  if (!localStorage.getItem(ADMIN_PRODUCTS_KEY)) {
    const migrated = PRODUCTS.map(product => normalizeProduct({
      ...product,
      stock: Number.isFinite(Number(product.stock)) ? Number(product.stock) : 10,
      oldPrice: product.oldPrice ? Number(product.oldPrice) : null,
      image: product.image || "",
      active: product.active !== false,
      featured: !!product.featured
    }));
    saveManagedProducts(migrated);
  } else {
    const normalized = stored.map(normalizeProduct);
    PRODUCTS = normalized;
    // Migrate existing single-image products to the new five-image structure.
    if (JSON.stringify(stored) !== JSON.stringify(normalized)) saveManagedProducts(normalized);
  }
}

function isAdminLoggedIn() {
  return sessionStorage.getItem(ADMIN_SESSION_KEY) === "1"
    || ["admin", "store_owner"].includes(String(sessionStorage.getItem("ownerSupabaseRole") || "").toLowerCase());
}

function openAdminLogin() {
  clearMessage("adminLoginMessage");
  const form = document.getElementById("adminLoginForm");
  if (form) form.reset();
  showScreen("adminLoginScreen");
}

async function openAdminDashboard() {
  // Luffy 4: a Supabase admin/store_owner can open the owner dashboard
  // without using the legacy admin/admin123 credentials.
  if (!isAdminLoggedIn()) {
    try {
      const session = getSupabaseSession();
      if (session?.user?.id && session?.access_token) {
        const profile = await c4GetOwnerProfile(session);
        if (profile && ["admin", "store_owner"].includes(String(profile.role || "").toLowerCase())) {
          sessionStorage.setItem("ownerSupabaseRole", String(profile.role).toLowerCase());
          sessionStorage.setItem("ownerSupabaseUserId", session.user.id);
        }
      }
    } catch (error) {
      console.warn("MyStore Luffy 4: owner dashboard role check failed", error);
    }
  }
  if (!isAdminLoggedIn()) {
    openAdminLogin();
    return;
  }
  renderAdminDashboard();
  showScreen("adminScreen");
}

function adminLogin(event) {
  event.preventDefault();
  const username = document.getElementById("adminUsername")?.value.trim();
  const password = document.getElementById("adminPassword")?.value;
  if (username !== ADMIN_CREDENTIALS.username || password !== ADMIN_CREDENTIALS.password) {
    setMessage("adminLoginMessage", "بيانات دخول صاحب المتجر غير صحيحة.", "error");
    return;
  }
  sessionStorage.setItem(ADMIN_SESSION_KEY, "1");
  showToast("تم الدخول إلى لوحة صاحب المتجر", "✓");
  openAdminDashboard();
}

function adminLogout() {
  sessionStorage.removeItem(ADMIN_SESSION_KEY);
  sessionStorage.removeItem("ownerSupabaseRole");
  sessionStorage.removeItem("ownerSupabaseUserId");
  showToast("تم تسجيل الخروج من لوحة المتجر", "✓");
  showScreen("home");
}

function adminProductVisual(product) {
  const images = getProductImages(product);
  const firstImage = images[0] || product.image || "";
  if (firstImage) return `<div class="admin-product-thumb-stack"><img src="${escapeHTML(firstImage)}" alt="${escapeHTML(product.name)}" onerror="this.style.display='none'"><span>${images.length || 1} صور</span></div>`;
  return escapeHTML(product.icon || "📦");
}


/* =========================================
   ADMIN PRODUCT IMAGE GALLERY / UPLOAD
   - حتى 5 صور لكل منتج
   - اختيار عدة صور من الهاتف
   - معاينة وحذف وترتيب الصور
========================================= */
let adminSelectedProductImages = [];

function getProductImages(product) {
  return normalizeProductImages(product || {});
}

function setAdminProductImagesPreview(images) {
  const preview = document.getElementById("adminProductImagePreview");
  const clearBtn = document.getElementById("adminProductImageClear");
  if (!preview) return;

  adminSelectedProductImages = (images || []).filter(Boolean).slice(0, 5);

  if (!adminSelectedProductImages.length) {
    preview.innerHTML = `<span>لم يتم اختيار صور بعد (حتى 5 صور)</span>`;
    if (clearBtn) clearBtn.style.display = "none";
    return;
  }

  preview.innerHTML = adminSelectedProductImages.map((src, index) => `
    <div class="admin-image-item" data-image-index="${index}">
      <img src="${escapeHTML(src)}" alt="صورة المنتج ${index + 1}" onerror="this.parentElement.classList.add('broken')">
      <span class="admin-image-number">${index + 1}</span>
      <button type="button" class="admin-image-remove" data-remove-image="${index}" aria-label="حذف الصورة">×</button>
    </div>
  `).join("");

  if (clearBtn) clearBtn.style.display = "inline-flex";

  preview.querySelectorAll("[data-remove-image]").forEach(button => {
    button.addEventListener("click", event => {
      event.preventDefault();
      event.stopPropagation();
      const index = Number(button.dataset.removeImage);
      adminSelectedProductImages.splice(index, 1);
      syncAdminProductImageUrl();
      setAdminProductImagesPreview(adminSelectedProductImages);
    });
  });
}

function syncAdminProductImageUrl() {
  const urlInput = document.getElementById("adminProductImage");
  if (!urlInput) return;
  const first = adminSelectedProductImages[0] || "";
  urlInput.value = first.startsWith("data:") ? "" : first;
}

function clearAdminProductImage() {
  const urlInput = document.getElementById("adminProductImage");
  const fileInput = document.getElementById("adminProductImageFile");
  if (urlInput) urlInput.value = "";
  if (fileInput) fileInput.value = "";
  adminSelectedProductImages = [];
  setAdminProductImagesPreview([]);
}

function compressAdminProductImage(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith("image/")) {
      reject(new Error("أحد الملفات المختارة ليس صورة."));
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      reject(new Error("حجم إحدى الصور كبير جدًا. اختر صورًا أقل من 12MB للصورة الواحدة."));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error("تعذر قراءة الصورة."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("تعذر معالجة الصورة."));
      img.onload = () => {
        const maxSize = 1200;
        const scale = Math.min(1, maxSize / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
        const width = Math.max(1, Math.round((img.naturalWidth || img.width) * scale));
        const height = Math.max(1, Math.round((img.naturalHeight || img.height) * scale));
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d", { alpha: false });
        if (!ctx) {
          reject(new Error("المتصفح لا يدعم معالجة الصورة."));
          return;
        }
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.78));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

function bindAdminProductImageUpload() {
  const fileInput = document.getElementById("adminProductImageFile");
  const urlInput = document.getElementById("adminProductImage");
  const clearBtn = document.getElementById("adminProductImageClear");

  if (fileInput && !fileInput.dataset.bound) {
    fileInput.dataset.bound = "1";
    fileInput.addEventListener("change", async function () {
      const files = Array.from(this.files || []);
      if (!files.length) return;

      const remaining = Math.max(0, 5 - adminSelectedProductImages.length);
      if (!remaining) {
        this.value = "";
        showToast("يمكنك إضافة 5 صور فقط لكل منتج", "!");
        return;
      }

      const selected = files.slice(0, remaining);
      const results = [];
      try {
        for (const file of selected) results.push(await compressAdminProductImage(file));
        adminSelectedProductImages = [...adminSelectedProductImages, ...results].slice(0, 5);
        syncAdminProductImageUrl();
        setAdminProductImagesPreview(adminSelectedProductImages);
        showToast(`تمت إضافة ${results.length} ${results.length === 1 ? "صورة" : "صور"} بنجاح`, "✓");
      } catch (error) {
        showToast(error.message || "تعذر تحميل الصور", "!");
      } finally {
        this.value = "";
      }
    });
  }

  if (urlInput && !urlInput.dataset.previewBound) {
    urlInput.dataset.previewBound = "1";
    urlInput.addEventListener("change", () => {
      const value = urlInput.value.trim();
      if (!value) return;
      adminSelectedProductImages = [value, ...adminSelectedProductImages.filter(src => src !== value)].slice(0, 5);
      setAdminProductImagesPreview(adminSelectedProductImages);
    });
  }

  if (clearBtn && !clearBtn.dataset.bound) {
    clearBtn.dataset.bound = "1";
    clearBtn.addEventListener("click", clearAdminProductImage);
  }
}

function openAdminProductModal(productId = null) {
  const modal = document.getElementById("adminProductModal");
  const form = document.getElementById("adminProductForm");
  if (!modal || !form) return;
  form.reset();
  adminSelectedProductImages = [];
  setAdminProductImagesPreview([]);
  document.getElementById("adminProductId").value = "";
  document.getElementById("adminProductActive").checked = true;
  document.getElementById("adminProductModalTitle").textContent = productId ? "تعديل المنتج" : "إضافة منتج";
  clearMessage("adminProductMessage");
  if (productId !== null) {
    const product = PRODUCTS.find(item => sameProductId(item.id, productId));
    if (!product) return;
    document.getElementById("adminProductId").value = product.id;
    document.getElementById("adminProductName").value = product.name || "";
    document.getElementById("adminProductCategory").value = product.category || "";
    document.getElementById("adminProductPrice").value = product.price ?? 0;
    document.getElementById("adminProductOldPrice").value = product.oldPrice ?? "";
    document.getElementById("adminProductStock").value = product.stock ?? 0;
    document.getElementById("adminProductIcon").value = product.icon || "📦";
    const productImages = getProductImages(product);
    adminSelectedProductImages = productImages.slice(0, 5);
    document.getElementById("adminProductImage").value =
      (productImages[0] && !String(productImages[0]).startsWith("data:")) ? productImages[0] : "";
    document.getElementById("adminProductDescription").value = product.description || "";
    setAdminProductImagesPreview(productImages);
    document.getElementById("adminProductActive").checked = product.active !== false;
    document.getElementById("adminProductFeatured").checked = !!product.featured;
  }
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
}

function closeAdminProductModal() {
  const modal = document.getElementById("adminProductModal");
  if (!modal) return;
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
}

function saveAdminProduct(event) {
  event.preventDefault();
  const idValue = document.getElementById("adminProductId").value.trim();
  const name = document.getElementById("adminProductName").value.trim();
  const category = document.getElementById("adminProductCategory").value.trim();
  const price = Number(document.getElementById("adminProductPrice").value);
  const oldPriceRaw = document.getElementById("adminProductOldPrice").value;
  const stock = Math.max(0, Number(document.getElementById("adminProductStock").value));
  const icon = document.getElementById("adminProductIcon").value.trim() || "📦";
  const urlImage = document.getElementById("adminProductImage").value.trim();
  if (urlImage && !adminSelectedProductImages.includes(urlImage)) {
    adminSelectedProductImages = [urlImage, ...adminSelectedProductImages].slice(0, 5);
  }
  const images = adminSelectedProductImages.slice(0, 5);
  const image = images[0] || urlImage || "";
  const description = document.getElementById("adminProductDescription").value.trim();
  const active = document.getElementById("adminProductActive").checked;
  const featured = document.getElementById("adminProductFeatured").checked;
  if (!name || !category || !description || !Number.isFinite(price) || price < 0 || !Number.isFinite(stock)) {
    setMessage("adminProductMessage", "يرجى إدخال بيانات المنتج بشكل صحيح.", "error");
    return;
  }
  const products = [...PRODUCTS];
  const data = { name, category, price, oldPrice: oldPriceRaw === "" ? null : Math.max(0, Number(oldPriceRaw)), stock, icon, image, images, description, active, featured };
  if (idValue) {
    const index = products.findIndex(item => String(item.id) === idValue);
    if (index === -1) return;
    products[index] = { ...products[index], ...data };
  } else {
    const nextId = products.reduce((max, item) => Math.max(max, Number(item.id) || 0), 0) + 1;
    products.push({ id: nextId, ...data });
  }
  saveManagedProducts(products);
  renderCategories();
  renderProducts();
  renderAdminDashboard();
  closeAdminProductModal();
  showToast(idValue ? "تم تعديل المنتج" : "تمت إضافة المنتج", "✓");
}

function deleteAdminProduct(productId) {
  const product = PRODUCTS.find(item => sameProductId(item.id, productId));
  if (!product) return;
  if (!confirm(`هل تريد حذف المنتج «${product.name}»؟`)) return;
  saveManagedProducts(PRODUCTS.filter(item => !sameProductId(item.id, productId)));

  // تنظيف السلال والمفضلة فقط؛ الطلبات السابقة تبقى محفوظة كسجل تاريخي.
  const accounts = getAccounts().map(account => ({
    ...account,
    cart: Array.isArray(account.cart) ? account.cart.filter(item => !sameProductId(item.productId, productId)) : [],
    favorites: Array.isArray(account.favorites) ? account.favorites.filter(id => !sameProductId(id, productId)) : []
  }));
  saveAccounts(accounts);

  renderCategories();
  renderProducts();
  renderAdminDashboard();
  showToast("تم حذف المنتج", "✓");
}

function toggleAdminProduct(productId) {
  const products = PRODUCTS.map(product => sameProductId(product.id, productId) ? { ...product, active: product.active === false } : product);
  saveManagedProducts(products);
  renderCategories();
  renderProducts();
  renderAdminDashboard();
}

function getAllOrdersForAdmin() {
  const accounts = getAccounts();
  const cloudOrders = Array.isArray(window.__MYSTORE_CLOUD_ADMIN_ORDERS)
    ? window.__MYSTORE_CLOUD_ADMIN_ORDERS
    : [];
  const orders = [];
  accounts.forEach(account => {
    (Array.isArray(account.orders) ? account.orders : []).forEach(order => {
      orders.push({ ...order, accountId: account.id, accountName: account.name, accountEmail: account.email });
    });
  });
  const localKeys = new Set(orders.map(o => String(o.cloudId || o.id)));
  cloudOrders.forEach(order => {
    const key = String(order.cloudId || order.id);
    if (!localKeys.has(key)) orders.push({ ...order });
  });
  return orders.sort((a,b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
}

function orderStatusDbValue(status) {
  // Supabase orders_status_check accepts "processing"; the UI label is "قيد التجهيز".
  return status === "preparing" ? "processing" : status;
}

function orderStatusUiValue(status) {
  // Keep the Arabic UI option "preparing" while reading Supabase's canonical "processing".
  return status === "processing" ? "preparing" : status;
}

function orderStatusLabel(status) {
  return ({new:"جديد", confirmed:"مؤكد", processing:"قيد التجهيز", preparing:"قيد التجهيز", shipped:"تم الشحن", delivered:"تم التسليم", cancelled:"ملغى"})[status] || "جديد";
}

async function updateAdminOrderStatus(orderId, accountId, status) {
  const dbStatus = orderStatusDbValue(status);
  const accounts = getAccounts();
  const account = accounts.find(item => String(item.id) === String(accountId));
  const cloudOrders = Array.isArray(window.__MYSTORE_CLOUD_ADMIN_ORDERS)
    ? window.__MYSTORE_CLOUD_ADMIN_ORDERS
    : [];
  const cloudOrder = cloudOrders.find(item => String(item.id) === String(orderId) || String(item.cloudId) === String(orderId));

  // Cloud orders are authoritative. Update/delete them in Supabase first,
  // then mirror the result locally. This also handles cloud-only orders that
  // have no matching local account.
  if (cloudOrder?.id) {
    try {
      const token = await c3RequireOwner();
      if (status === "cancelled") {
        await c3Request(`orders?id=eq.${encodeURIComponent(String(cloudOrder.id))}`, "DELETE", undefined, token);
        window.__MYSTORE_CLOUD_ADMIN_ORDERS = cloudOrders.filter(item => String(item.id) !== String(cloudOrder.id));
      } else {
        const rows = await c3Request(`orders?id=eq.${encodeURIComponent(String(cloudOrder.id))}`, "PATCH", { status: dbStatus, updated_at: new Date().toISOString() }, token);
        const updated = Array.isArray(rows) ? rows[0] : null;
        window.__MYSTORE_CLOUD_ADMIN_ORDERS = cloudOrders.map(item =>
          String(item.id) === String(cloudOrder.id)
            ? { ...item, status: dbStatus, updatedAt: updated?.updated_at || new Date().toISOString() }
            : item
        );
      }
    } catch (error) {
      console.error("MyStore orders: cloud status update failed.", error);
      showToast(`تعذر تحديث الطلب: ${error.message || "خطأ في الاتصال"}`, "!");
      return;
    }
  }

  if (account && Array.isArray(account.orders)) {
    const orderIndex = account.orders.findIndex(item => String(item.cloudId || item.id) === String(orderId));
    if (orderIndex >= 0) {
      if (status === "cancelled") account.orders.splice(orderIndex, 1);
      else {
        account.orders[orderIndex].status = dbStatus;
        account.orders[orderIndex].updatedAt = new Date().toISOString();
      }
      saveAccounts(accounts);
    }
  }

  closeAdminOrderModal();
  await renderAdminDashboard();
  showToast(status === "cancelled" ? "تم حذف الطلب نهائيًا" : "تم تحديث حالة الطلب", status === "cancelled" ? "🗑️" : "✓");
}

function getAdminProductFilters() {
  return { search: String(document.getElementById("adminProductSearch")?.value || "").trim().toLowerCase(), filter: document.getElementById("adminProductFilter")?.value || "all" };
}

function renderAdminProducts() {
  const container = document.getElementById("adminProductsTable");
  if (!container) return;
  const { search, filter } = getAdminProductFilters();
  const products = PRODUCTS.filter(product => {
    const haystack = `${product.name || ""} ${product.category || ""}`.toLowerCase();
    if (search && !haystack.includes(search)) return false;
    if (filter === "active" && product.active === false) return false;
    if (filter === "hidden" && product.active !== false) return false;
    if (filter === "out" && Number(product.stock || 0) > 0) return false;
    return true;
  });
  if (!products.length) { container.innerHTML = `<div class="admin-empty">لا توجد منتجات مطابقة.</div>`; return; }
  container.innerHTML = `<table class="admin-table"><thead><tr><th>المنتج</th><th>السعر</th><th>المخزون</th><th>الحالة</th><th>الإجراءات</th></tr></thead><tbody>${products.map(product => `<tr><td><div class="admin-product-cell"><div class="admin-product-thumb">${adminProductVisual(product)}</div><div><strong>${escapeHTML(product.name)}</strong><small>${escapeHTML(product.category)}</small></div></div></td><td>${money(product.price)} دج${product.oldPrice ? `<small class="old-price"> ${money(product.oldPrice)} دج</small>` : ""}</td><td>${Number(product.stock || 0) === 0 ? `<span class="admin-status cancelled">نفد</span>` : Number(product.stock || 0)}</td><td>${product.active === false ? `<span class="admin-status cancelled">مخفي</span>` : `<span class="admin-status confirmed">ظاهر</span>`}</td><td><div class="admin-actions"><button class="admin-mini-btn" data-admin-edit="${product.id}" type="button">✏️ تعديل</button><button class="admin-mini-btn ${product.active === false ? "success" : ""}" data-admin-toggle="${product.id}" type="button">${product.active === false ? "إظهار" : "إخفاء"}</button><button class="admin-mini-btn danger" data-admin-delete="${product.id}" type="button">🗑️ حذف</button></div></td></tr>`).join("")}</tbody></table>`;
  container.querySelectorAll("[data-admin-edit]").forEach(btn => btn.onclick = () => openAdminProductModal(btn.dataset.adminEdit));
  container.querySelectorAll("[data-admin-toggle]").forEach(btn => btn.onclick = () => toggleAdminProduct(btn.dataset.adminToggle));
  container.querySelectorAll("[data-admin-delete]").forEach(btn => btn.onclick = () => deleteAdminProduct(btn.dataset.adminDelete));
}

function getAdminOrderFilters() {
  return { search: String(document.getElementById("adminOrderSearch")?.value || "").trim().toLowerCase(), filter: document.getElementById("adminOrderFilter")?.value || "all" };
}

function openAdminOrderModal(orderId, accountId) {
  const order = getAllOrdersForAdmin().find(item => String(item.id) === String(orderId) && String(item.accountId) === String(accountId));
  const modal = document.getElementById("adminOrderModal");
  const details = document.getElementById("adminOrderDetails");
  if (!order || !modal || !details) return;
  const customer = order.customer || {};
  const items = Array.isArray(order.items) ? order.items : [];
  details.innerHTML = `<h2>تفاصيل الطلب #${escapeHTML(String(order.id).slice(-8))}</h2><div class="admin-detail-grid"><div class="admin-detail-box"><small>الزبون</small><strong>${escapeHTML(customer.fullName || order.accountName || "زبون")}</strong></div><div class="admin-detail-box"><small>الهاتف</small><strong>${escapeHTML(customer.phone || "غير مسجل")}</strong></div><div class="admin-detail-box"><small>الولاية</small><strong>${escapeHTML(customer.wilaya || "-")}</strong></div><div class="admin-detail-box"><small>البلدية</small><strong>${escapeHTML(customer.commune || "-")}</strong></div><div class="admin-detail-box"><small>العنوان</small><strong>${escapeHTML(customer.address || "-")}</strong></div><div class="admin-detail-box"><small>التاريخ</small><strong>${order.createdAt ? escapeHTML(new Date(order.createdAt).toLocaleString("ar-DZ")) : "-"}</strong></div></div><div class="admin-detail-items">${items.length ? items.map(item => { const linkedProduct = PRODUCTS.find(p => sameProductId(p.id, item.productId ?? item.id)); const img = String(item.image || (Array.isArray(item.images) ? item.images[0] : "") || linkedProduct?.image || (Array.isArray(linkedProduct?.images) ? linkedProduct.images[0] : "") || "").trim(); const icon = item.icon || linkedProduct?.icon || "📦"; return `<div class="admin-detail-item admin-detail-item-product">${img ? `<img src="${escapeHTML(img)}" alt="${escapeHTML(item.name || linkedProduct?.name || "منتج")}" class="admin-order-product-image" onerror="this.style.display='none'">` : `<span class="admin-order-product-icon">${escapeHTML(icon)}</span>`}<span>${escapeHTML(item.name || item.title || linkedProduct?.name || "منتج")} × ${Number(item.quantity || 0)}</span><strong>${money(Number(item.price || linkedProduct?.price || 0) * Number(item.quantity || 0))} دج</strong></div>`; }).join("") : `<div class="admin-detail-item">لا توجد تفاصيل منتجات.</div>`}</div>${customer.notes ? `<div class="admin-order-note">📝 ملاحظات الزبون: ${escapeHTML(customer.notes)}</div>` : ""}<div class="admin-detail-total"><span>الإجمالي</span><strong>${money(order.total || 0)} دج</strong></div><div style="margin-top:16px"><label style="display:block;margin-bottom:7px">حالة الطلب</label><select id="adminModalOrderStatus" class="admin-status-select" style="width:100%"><option value="new">جديد</option><option value="confirmed">مؤكد</option><option value="preparing">قيد التجهيز</option><option value="shipped">تم الشحن</option><option value="delivered">تم التسليم</option><option value="cancelled">ملغى</option></select></div>`;
  const select = document.getElementById("adminModalOrderStatus");
  if (select) { select.value = orderStatusUiValue(order.status || "new"); select.onchange = () => { updateAdminOrderStatus(order.id, order.accountId, select.value); openAdminOrderModal(order.id, order.accountId); }; }
  modal.classList.add("show"); modal.setAttribute("aria-hidden", "false");
}
function closeAdminOrderModal() { const modal = document.getElementById("adminOrderModal"); if (!modal) return; modal.classList.remove("show"); modal.setAttribute("aria-hidden", "true"); }

function renderAdminOrders() {
  const container = document.getElementById("adminOrdersTable");
  if (!container) return;
  const { search, filter } = getAdminOrderFilters();
  const orders = getAllOrdersForAdmin().filter(order => { const customer = order.customer || {}; const haystack = `${order.id || ""} ${order.accountName || ""} ${order.accountEmail || ""} ${customer.fullName || ""} ${customer.phone || ""}`.toLowerCase(); const status = orderStatusUiValue(order.status || "new"); if (search && !haystack.includes(search)) return false; if (filter !== "all" && status !== filter) return false; return true; });
  if (!orders.length) { container.innerHTML = `<div class="admin-empty">لا توجد طلبات مطابقة.</div>`; return; }
  container.innerHTML = `<table class="admin-table"><thead><tr><th>الطلب</th><th>الزبون</th><th>المنتجات</th><th>الإجمالي</th><th>التاريخ</th><th>الحالة</th><th>التفاصيل</th></tr></thead><tbody>${orders.map(order => { const status = orderStatusUiValue(order.status || "new"); const customer = order.customer || {}; const itemCount = Number(order.totalItems || (order.items || []).reduce((n,i)=>n+Number(i.quantity||0),0)); return `<tr><td><strong>#${escapeHTML(String(order.id).slice(-8))}</strong></td><td><div><strong>${escapeHTML(customer.fullName || order.accountName || "زبون")}</strong><small>${escapeHTML(customer.phone || "")}</small></div></td><td>${itemCount}</td><td>${money(order.total || 0)} دج</td><td>${order.createdAt ? new Date(order.createdAt).toLocaleString("ar-DZ") : "-"}</td><td><select class="admin-status-select" data-order-status="${escapeHTML(order.id)}" data-account-id="${escapeHTML(order.accountId)}"><option value="new" ${status==="new"?"selected":""}>جديد</option><option value="confirmed" ${status==="confirmed"?"selected":""}>مؤكد</option><option value="preparing" ${status==="preparing"?"selected":""}>قيد التجهيز</option><option value="shipped" ${status==="shipped"?"selected":""}>تم الشحن</option><option value="delivered" ${status==="delivered"?"selected":""}>تم التسليم</option><option value="cancelled" ${status==="cancelled"?"selected":""}>ملغى</option></select></td><td><button type="button" class="admin-mini-btn" data-admin-order-details="${escapeHTML(order.id)}" data-account-id="${escapeHTML(order.accountId)}">👁️ عرض</button></td></tr>`; }).join("")}</tbody></table>`;
  container.querySelectorAll("[data-order-status]").forEach(select => select.onchange = () => updateAdminOrderStatus(select.dataset.orderStatus, select.dataset.accountId, select.value));
  container.querySelectorAll("[data-admin-order-details]").forEach(btn => btn.onclick = () => openAdminOrderModal(btn.dataset.adminOrderDetails, btn.dataset.accountId));
}
async function syncCloudOrdersForAdmin() {
  const session = getSupabaseSession();
  const token = session?.access_token;
  if (!token) return;

  try {
    // Do not trust the legacy sessionStorage role as the sole gate.
    // The current Supabase session/profile is authoritative.
    const profile = await c3GetProfile();
    const ownerRole = String(profile?.role || sessionStorage.getItem("ownerSupabaseRole") || "").toLowerCase();
    if (!profile || !["admin", "store_owner"].includes(ownerRole)) return;
    const rows = await c3Request(
      "orders?select=*&order=created_at.desc",
      "GET",
      undefined,
      token
    );
    const cloudOrders = Array.isArray(rows) ? rows : [];
    if (!cloudOrders.length) {
      window.__MYSTORE_CLOUD_ADMIN_ORDERS = [];
      return;
    }

    const ids = cloudOrders.map(o => String(o.id)).filter(Boolean);
    let itemRows = [];
    if (ids.length) {
      const quoted = ids.map(id => `"${id.replace(/"/g, "")}"`).join(",");
      itemRows = await c3Request(
        `order_items?select=*&order_id=in.(${quoted})`,
        "GET",
        undefined,
        token
      );
    }

    const byOrder = {};
    (Array.isArray(itemRows) ? itemRows : []).forEach(item => {
      const key = String(item.order_id);
      (byOrder[key] ||= []).push({
        id: item.product_id || null,
        productId: item.product_id || null,
        name: item.product_name || "منتج",
        price: Number(item.unit_price || 0),
        quantity: Number(item.quantity || 1),
        image: item.image || "",
        images: item.image ? [item.image] : []
      });
    });

    const accounts = getAccounts();
    const normalizedCloud = cloudOrders.map(cloud => {
      const account = accounts.find(a =>
        String(a.supabaseAuthId || a.id) === String(cloud.user_id)
      );
      const normalized = {
        id: cloud.id,
        cloudId: cloud.id,
        accountId: account?.id || cloud.user_id,
        accountName: account?.name || cloud.customer_name || "زبون",
        accountEmail: account?.email || "",
        createdAt: cloud.created_at,
        updatedAt: cloud.updated_at,
        customer: {
          fullName: cloud.customer_name || account?.name || "",
          lastName: "",
          phone: cloud.customer_phone || "",
          wilaya: cloud.wilaya || "",
          commune: cloud.commune || "",
          address: cloud.address || "",
          notes: cloud.notes || ""
        },
        items: byOrder[String(cloud.id)] || [],
        totalItems: (byOrder[String(cloud.id)] || []).reduce((sum, item) => sum + Number(item.quantity || 0), 0),
        total: Number(cloud.total || 0),
        status: cloud.status || "new",
        orderNumber: cloud.order_number,
        supabaseUserId: cloud.user_id
      };
      return normalized;
    });

    // Supabase is the authoritative source for the admin order list.
    window.__MYSTORE_CLOUD_ADMIN_ORDERS = normalizedCloud;

    // Also merge into a matching local account when one exists, preserving
    // existing local UI behavior without hiding cloud-only orders.
    normalizedCloud.forEach(normalized => {
      const account = accounts.find(a =>
        String(a.supabaseAuthId || a.id) === String(normalized.supabaseUserId)
      );
      if (!account) return;
      if (!Array.isArray(account.orders)) account.orders = [];
      const existingIndex = account.orders.findIndex(o =>
        String(o.cloudId || o.id) === String(normalized.id)
      );
      if (existingIndex >= 0) {
        account.orders[existingIndex] = { ...account.orders[existingIndex], ...normalized };
      } else {
        account.orders.push(normalized);
      }
    });
    saveAccounts(accounts);
  } catch (error) {
    console.warn("MyStore orders: owner cloud sync failed.", error);
  }
}

async function renderAdminDashboard() {
  if (!isAdminLoggedIn()) return;
  await syncCloudOrdersForAdmin();
  const orders = getAllOrdersForAdmin();
  const activeProducts = PRODUCTS.filter(p => p.active !== false);
  const revenue = orders.filter(order => (order.status || "new") !== "cancelled").reduce((sum, order) => sum + Number(order.total || 0), 0);
  const newOrders = orders.filter(order => (order.status || "new") === "new").length;
  const p = document.getElementById("adminProductsCount"); if (p) p.textContent = activeProducts.length;
  const o = document.getElementById("adminOrdersCount"); if (o) o.textContent = orders.length;
  const n = document.getElementById("adminNewOrdersCount"); if (n) n.textContent = newOrders;
  const r = document.getElementById("adminRevenue"); if (r) r.textContent = `${money(revenue)} دج`;
  renderAdminProducts();
  renderAdminOrders();
}

function decreaseProductStock(items) {
  if (!Array.isArray(items)) return;
  const products = PRODUCTS.map(product => {
    const item = items.find(i => sameProductId(i.productId ?? i.id, product.id));
    if (!item) return product;
    return { ...product, stock: Math.max(0, Number(product.stock || 0) - Number(item.quantity || 0)) };
  });
  saveManagedProducts(products);
}

function prepareAdminUI() {
  document.querySelectorAll("#ownerLoginBtn, [data-owner-login]").forEach(button => {
    if (button.dataset.ownerBound === "1") return;
    button.dataset.ownerBound = "1";
    button.addEventListener("click", function(event) {
      event.preventDefault();
      openAdminLogin();
    });
  });
  document.getElementById("adminLoginBackBtn")?.addEventListener("click", () => showScreen("home"));
  document.getElementById("adminLoginForm")?.addEventListener("submit", adminLogin);
  document.getElementById("adminLogoutBtn")?.addEventListener("click", adminLogout);
  document.getElementById("adminBackStoreBtn")?.addEventListener("click", () => { const account=getCurrentAccount(); if(account) openStore(); else showScreen("home"); });
  document.getElementById("adminAddProductBtn")?.addEventListener("click", () => openAdminProductModal());
  document.getElementById("adminRefreshOrdersBtn")?.addEventListener("click", renderAdminDashboard);
  document.getElementById("adminProductModalClose")?.addEventListener("click", closeAdminProductModal);
  document.getElementById("adminProductForm")?.addEventListener("submit", event => saveAdminProduct(event));
  document.getElementById("adminProductModal")?.addEventListener("click", event => { if (event.target.id === "adminProductModal") closeAdminProductModal(); });
  bindAdminProductImageUpload();
  document.getElementById("adminOrderModalClose")?.addEventListener("click", closeAdminOrderModal);
  document.getElementById("adminOrderModal")?.addEventListener("click", event => { if (event.target.id === "adminOrderModal") closeAdminOrderModal(); });
  document.getElementById("adminProductSearch")?.addEventListener("input", renderAdminProducts);
  document.getElementById("adminProductFilter")?.addEventListener("change", renderAdminProducts);
  document.getElementById("adminOrderSearch")?.addEventListener("input", renderAdminOrders);
  document.getElementById("adminOrderFilter")?.addEventListener("change", renderAdminOrders);
}

initializeManagedProducts();

// Egress protection: automatic admin order polling was removed.
// Use the existing "Refresh Orders" button for an explicit refresh.

/* =========================================
   CATEGORIES
========================================= */

const CATEGORIES = [

  {
    id: "all",
    name: "الكل",
    icon: "✨"
  },

  {
    id: "__best_selling__",
    name: "الأكثر مبيعًا",
    icon: "🔥",
    special: true
  },

  {
    id: "إلكترونيات",
    name: "إلكترونيات",
    icon: "📱"
  },

  {
    id: "أزياء",
    name: "أزياء",
    icon: "👕"
  },

  {
    id: "المنزل",
    name: "المنزل",
    icon: "🏠"
  },

  {
    id: "الرياضة",
    name: "الرياضة",
    icon: "⚽"
  }

];


/* =========================================
   STATE
========================================= */

let selectedLoginAccountId = null;

let currentCategory = "all";

let currentSearch = "";

let toastTimer;


/*
  نسخة ثابتة من السلة عند فتح صفحة الطلب.
*/

let checkoutItemsSnapshot = [];

let checkoutTotalSnapshot = 0;


/* =========================================
   HELPERS
========================================= */

function getAccounts() {

  try {

    const data =
      localStorage.getItem(KEYS.accounts);

    if (!data) return [];

    const accounts =
      JSON.parse(data);

    return Array.isArray(accounts)
      ? accounts
      : [];

  } catch {

    return [];

  }

}


function saveAccounts(accounts) {

  localStorage.setItem(
    KEYS.accounts,
    JSON.stringify(accounts)
  );

}


function getCurrentUserId() {

  return localStorage.getItem(
    KEYS.currentUser
  );

}


function setCurrentUserId(id) {

  localStorage.setItem(
    KEYS.currentUser,
    id
  );

}


function clearCurrentUser() {

  localStorage.removeItem(
    KEYS.currentUser
  );

}


/* =========================================
   CURRENT ACCOUNT
========================================= */

function getCurrentAccount() {

  const id =
    getCurrentUserId();

  if (!id) return null;

  const accounts =
    getAccounts();

  return accounts.find(
    account =>
      account.id === id
  ) || null;

}


function getCurrentAccountFrom(accounts) {

  const id =
    getCurrentUserId();

  if (!id) return null;

  return accounts.find(
    account =>
      account.id === id
  ) || null;

}


/* =========================================
   SHIPPING ADDRESS
========================================= */

function getShippingAddress() {

  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);

  if (!account) return null;


  if (!account.shippingAddress) {

    account.shippingAddress = {

      fullName:
        account.name || "",

      phone: "",

      wilaya: "",

      commune: "",

      address: "",

      notes: ""

    };

    saveAccounts(accounts);

  }


  return account.shippingAddress;

}


function saveShippingAddress(address) {

  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);

  if (!account) return false;


  account.shippingAddress = {

    fullName:
      String(address.fullName || "").trim(),

    phone:
      String(address.phone || "").trim(),

    wilaya:
      String(address.wilaya || "").trim(),

    commune:
      String(address.commune || "").trim(),

    address:
      String(address.address || "").trim(),

    notes:
      String(address.notes || "").trim()

  };


  saveAccounts(accounts);

  return true;

}


/* =========================================
   ID
========================================= */

function createId() {

  if (
    window.crypto &&
    crypto.randomUUID
  ) {

    return crypto.randomUUID();

  }

  return (
    Date.now().toString(36) +
    Math.random()
      .toString(36)
      .substring(2)
  );

}


/* =========================================
   ESCAPE HTML
========================================= */

function escapeHTML(value) {

  const div =
    document.createElement("div");

  div.textContent =
    value == null
      ? ""
      : String(value);

  return div.innerHTML;

}


/* =========================================
   MONEY
========================================= */

function money(value) {

  return Number(value || 0)
    .toLocaleString("ar-DZ");

}


/* =========================================
   PASSWORD HASH
========================================= */

async function hashPassword(password) {

  const encoder =
    new TextEncoder();

  const data =
    encoder.encode(password);

  const hashBuffer =
    await crypto.subtle.digest(
      "SHA-256",
      data
    );

  return Array.from(
    new Uint8Array(hashBuffer)
  )
    .map(
      byte =>
        byte
          .toString(16)
          .padStart(2, "0")
    )
    .join("");

}


/* =========================================
   SCREENS
========================================= */

const screenNames = [

  "home",
  "register",
  "login",
  "store",
  "productDetails",
  "favorites",
  "cart",
  "checkout",
  "account",
  "settings",
  "adminLogin",
  "admin"

];


function showScreen(name) {

  // دعم أسماء الشاشات القديمة والجديدة.
  const aliases = {
    adminLoginScreen: "adminLogin",
    adminScreen: "admin"
  };
  const target = aliases[name] || name;

  if (target === "admin" && !isAdminLoggedIn()) {
    showScreen("adminLogin");
    return;
  }

  let found = false;

  screenNames.forEach(
    screenName => {

      const element =
        document.getElementById(
          screenName + "Screen"
        );

      if (!element) return;

      const active = screenName === target;
      element.classList.toggle("active", active);
      if (active) found = true;

    }
  );

  // إذا طُلبت شاشة غير معروفة لا نترك المستخدم في حالة شاشة معلقة.
  if (!found && target !== "home") {
    const home = document.getElementById("homeScreen");
    if (home) home.classList.add("active");
  }

  window.scrollTo(0, 0);

}


/* =========================================
   AVATAR
========================================= */

function avatarHTML(account) {

  if (
    account &&
    account.avatar
  ) {

    return `
      <img
        src="${account.avatar}"
        alt="صورة الحساب"
      >
    `;

  }

  return "👤";

}


/* =========================================
   ACCOUNTS
========================================= */

function renderAccounts() {

  const accounts =
    getAccounts();

  const list =
    document.getElementById(
      "accountsList"
    );

  const empty =
    document.getElementById(
      "emptyAccounts"
    );

  const count =
    document.getElementById(
      "accountsCount"
    );

  if (!list) return;

  if (count) {

    count.textContent =
      accounts.length;

  }

  list.innerHTML = "";


  if (!accounts.length) {

    if (empty) {

      empty.style.display =
        "block";

    }

    return;

  }


  if (empty) {

    empty.style.display =
      "none";

  }


  accounts.forEach(
    account => {

      const item =
        document.createElement("button");

      item.className =
        "account-item";

      item.type =
        "button";

      item.innerHTML = `

        <div class="account-avatar">
          ${avatarHTML(account)}
        </div>

        <div class="account-details">

          <strong>
            ${escapeHTML(account.name)}
          </strong>

          <small>
            ${escapeHTML(account.email)}
          </small>

        </div>

        <div class="account-arrow">
          ‹
        </div>

      `;

      item.onclick = async () => {
        const session = getSupabaseSession();
        const sessionUserId = String(session?.user?.id || "");
        const accountUserId = String(account.supabaseAuthId || account.id || "");

        if (account.quickLoginEnabled && sessionUserId && accountUserId === sessionUserId) {
          const restored = await restoreSupabaseSession();
          if (restored?.user?.id && String(restored.user.id) === accountUserId) {
            const linked = createLocalAccountFromSupabaseUser(restored.user) || account;
            if (linked) {
              setCurrentUserId(linked.id);
              selectedLoginAccountId = null;
              getShippingAddress();
              showToast("تم الدخول إلى الحساب مباشرة", "✓");
              openStore();
              return;
            }
          }
        }

        openLoginScreen(account.id);
      };

      list.appendChild(item);

    }
  );

}


/* =========================================
   REGISTER
========================================= */

const createAccountBtn =
  document.getElementById(
    "createAccountBtn"
  );

if (createAccountBtn) {

  createAccountBtn.onclick =
    () => {

      const form =
        document.getElementById(
          "registerForm"
        );

      if (form) {

        form.reset();

      }

      clearMessage(
        "registerMessage"
      );

      showScreen("register");

    };

}


const registerForm =
  document.getElementById(
    "registerForm"
  );

if (registerForm) {
  registerForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("registerName")?.value.trim() || "";
    const email = document.getElementById("registerEmail")?.value.trim().toLowerCase() || "";
    const password = document.getElementById("registerPassword")?.value || "";
    const confirm = document.getElementById("registerConfirmPassword")?.value || "";

    if (name.length < 2) {
      setMessage("registerMessage", "الاسم قصير جدًا.", "error");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setMessage("registerMessage", "البريد الإلكتروني غير صحيح.", "error");
      return;
    }
    if (password.length < 6) {
      setMessage("registerMessage", "كلمة المرور يجب أن تكون 6 أحرف على الأقل.", "error");
      return;
    }
    if (password !== confirm) {
      setMessage("registerMessage", "كلمتا المرور غير متطابقتين.", "error");
      return;
    }

    const localAccounts = getAccounts();
    const existingLocal = localAccounts.find(account => String(account.email || "").toLowerCase() === email);
    if (existingLocal?.supabaseAuthId) {
      showExistingEmailLoginOption(email, "registerMessage");
      return;
    }

    const submitButton = this.querySelector('button[type="submit"]');
    if (submitButton) submitButton.disabled = true;
    clearMessage("registerMessage");

    try {
      const result = await supabaseSignUp(email, password, name);
      const user = result?.user || null;

      if (user) {
        const account = createLocalAccountFromSupabaseUser(user);
        if (result?.session) {
          saveSupabaseSession(result.session);
          if (account) {
            account.quickLoginEnabled = true;
            saveAccounts(getAccounts().map(a => a.id === account.id ? account : a));
          }
          setCurrentUserId(account.id);
          getShippingAddress();
          this.reset();
          setMessage("registerMessage", "تم إنشاء الحساب وتسجيل الدخول بنجاح.", "success");
          setTimeout(() => {
            renderAccounts();
            openStore();
            showToast("تم إنشاء الحساب", "✓");
          }, 500);
        } else {
          this.reset();
          renderAccounts();
          setMessage("registerMessage", "تم إنشاء الحساب. افتح بريدك الإلكتروني لتأكيد الحساب ثم سجّل الدخول.", "success");
          showToast("تم إنشاء الحساب", "✓");
        }
        return;
      }

      setMessage("registerMessage", "تم إرسال طلب إنشاء الحساب. تحقق من بريدك الإلكتروني إذا طلب منك ذلك.", "success");
    } catch (error) {
      console.warn("MyStore: Supabase sign-up failed.", error);
      setMessage("registerMessage", supabaseAuthErrorMessage(error), "error");
    } finally {
      if (submitButton) submitButton.disabled = false;
    }
  });
}

/* =========================================
   LOGIN
========================================= */

function resetEmailLoginMode() {
  const emailGroup = document.getElementById("loginEmailGroup");
  const emailInput = document.getElementById("loginEmailInput");
  const loginAvatar = document.getElementById("loginAvatar");
  const loginTitle = document.getElementById("loginTitle");
  const loginEmailText = document.getElementById("loginEmailText");

  if (emailGroup) emailGroup.style.display = "none";
  if (emailInput) {
    emailInput.required = false;
    emailInput.value = "";
  }
  if (loginAvatar) loginAvatar.style.display = "block";
  if (loginTitle) loginTitle.textContent = "تسجيل الدخول";
  if (loginEmailText) loginEmailText.textContent = "أدخل كلمة المرور للمتابعة";
}

function openEmailLoginScreen(email = "") {
  selectedLoginAccountId = null;

  const emailGroup = document.getElementById("loginEmailGroup");
  const emailInput = document.getElementById("loginEmailInput");
  const loginTitle = document.getElementById("loginTitle");
  const loginEmailText = document.getElementById("loginEmailText");
  const loginAvatar = document.getElementById("loginAvatar");
  const loginPassword = document.getElementById("loginPassword");

  if (emailGroup) emailGroup.style.display = "block";
  if (emailInput) {
    emailInput.required = true;
    emailInput.value = String(email || "").trim().toLowerCase();
  }
  if (loginAvatar) loginAvatar.style.display = "none";
  if (loginTitle) loginTitle.textContent = "تسجيل الدخول بحسابك";
  if (loginEmailText) loginEmailText.textContent = "أدخل بريدك الإلكتروني وكلمة المرور";
  if (loginPassword) loginPassword.value = "";

  clearMessage("loginMessage");
  showScreen("login");

  if (emailInput) setTimeout(() => emailInput.focus(), 100);
}

function showExistingEmailLoginOption(email, messageId = "registerMessage") {
  const message = document.getElementById(messageId);
  if (!message) return;

  message.textContent = "هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول إلى حسابك.";
  message.className = "form-message error";

  let button = document.getElementById("existingEmailLoginBtn");
  if (!button) {
    button = document.createElement("button");
    button.id = "existingEmailLoginBtn";
    button.type = "button";
    button.className = "secondary-btn full-btn";
    message.insertAdjacentElement("afterend", button);
  }

  button.textContent = "🔑 تسجيل الدخول بهذا البريد";
  button.onclick = () => openEmailLoginScreen(email);
}

function openLoginScreen(accountId) {

  const account =
    getAccounts().find(
      item =>
        item.id === accountId
    );


  if (!account) {

    renderAccounts();

    return;

  }

  resetEmailLoginMode();

  selectedLoginAccountId =
    account.id;


  const loginTitle =
    document.getElementById(
      "loginTitle"
    );

  const loginEmailText =
    document.getElementById(
      "loginEmailText"
    );

  const loginAvatar =
    document.getElementById(
      "loginAvatar"
    );

  const loginPassword =
    document.getElementById(
      "loginPassword"
    );


  if (loginTitle) {

    loginTitle.textContent =
      `مرحبًا ${account.name}`;

  }


  if (loginEmailText) {

    loginEmailText.textContent =
      account.email;

  }


  if (loginAvatar) {

    loginAvatar.innerHTML =
      avatarHTML(account);

  }


  if (loginPassword) {

    loginPassword.value =
      "";

  }


  clearMessage("loginMessage");

  showScreen("login");

}


const changeAccountBtn =
  document.getElementById(
    "changeAccountBtn"
  );

if (changeAccountBtn) {

  changeAccountBtn.onclick =
    () => {

      selectedLoginAccountId = null;
      resetEmailLoginMode();

      clearMessage(
        "loginMessage"
      );

      showScreen("home");

    };

}

const loginByEmailBtn = document.getElementById("loginByEmailBtn");
if (loginByEmailBtn) {
  loginByEmailBtn.onclick = () => openEmailLoginScreen();
}

const forgotPasswordBtn = document.getElementById("forgotPasswordBtn");
if (forgotPasswordBtn) {
  forgotPasswordBtn.onclick = () => {
    const emailInput = document.getElementById("loginEmailInput");
    const email = String(
      emailInput?.value ||
      getAccounts().find(item => item.id === selectedLoginAccountId)?.email ||
      ""
    ).trim().toLowerCase();

    if (!email) {
      setMessage("loginMessage", "أدخل بريدك الإلكتروني أولًا لاستعادة كلمة المرور.", "error");
      openEmailLoginScreen();
      return;
    }

    setMessage("loginMessage", "استعادة كلمة المرور عبر البريد الإلكتروني سيتم تفعيلها في المرحلة النهائية بعد إعداد SMTP.", "success");
  };
}


const loginForm =
  document.getElementById(
    "loginForm"
  );

if (loginForm) {
  loginForm.addEventListener("submit", async function(event) {
    event.preventDefault();

    const emailInput = document.getElementById("loginEmailInput");
    const isEmailLogin = !selectedLoginAccountId;
    const password = document.getElementById("loginPassword")?.value || "";
    const email = String(emailInput?.value || "").trim().toLowerCase();
    const account = selectedLoginAccountId
      ? getAccounts().find(item => item.id === selectedLoginAccountId)
      : getAccounts().find(item => String(item.email || "").toLowerCase() === email);

    if (isEmailLogin && !email) {
      setMessage("loginMessage", "أدخل بريدك الإلكتروني.", "error");
      return;
    }

    const submitButton = this.querySelector('button[type="submit"]');
    if (submitButton) submitButton.disabled = true;
    clearMessage("loginMessage");

    try {
      // New/linked accounts authenticate against Supabase.
      // Legacy Phase 1 accounts are retained as a fallback below.
      const result = await supabaseSignIn(email || account?.email || "", password);
      const user = result?.user;

      if (!result?.access_token || !user) {
        throw new Error("لم يتم إنشاء جلسة دخول صالحة.");
      }

      saveSupabaseSession(result);
      const linkedAccount = createLocalAccountFromSupabaseUser(user) || account;
      if (linkedAccount) {
        linkedAccount.quickLoginEnabled = true;
        saveAccounts(getAccounts().map(a => a.id === linkedAccount.id ? linkedAccount : a));
      }
      if (!linkedAccount) {
        throw new Error("تم تسجيل الدخول لكن تعذر إنشاء بيانات الحساب المحلية.");
      }
      setCurrentUserId(linkedAccount.id);
      getShippingAddress();

      showToast("تم تسجيل الدخول", "✓");

      // Luffy 4: route Supabase owners to the owner dashboard, not the customer store.
      if (await c4RouteAuthenticatedUserToCorrectArea(user, result)) {
        return;
      }

      setTimeout(() => openStore(), 350);
      return;
    } catch (supabaseError) {
      console.warn("MyStore: Supabase sign-in failed, trying legacy local account.", supabaseError);

      // Preserve the working Phase 1 accounts during migration.
      if (account?.passwordHash) {
        const hash = await hashPassword(password);
        if (hash === account.passwordHash) {
          setCurrentUserId(account.id);
          getShippingAddress();
          showToast("تم تسجيل الدخول (الحساب المحلي)", "✓");
          setTimeout(() => openStore(), 350);
          return;
        }
      }

      setMessage("loginMessage", supabaseAuthErrorMessage(supabaseError), "error");
    } finally {
      if (submitButton) submitButton.disabled = false;
    }
  });
}

/* =========================================
   STORE
========================================= */

function openStore() {

  const account =
    getCurrentAccount();


  if (!account) {

    showScreen("home");

    return;

  }


  updateStoreUser();

  renderCategories();

  renderProducts();

  updateBadges();

  updateBottomNavigation("store");

  showScreen("store");

}


function updateStoreUser() {

  const account =
    getCurrentAccount();


  if (!account) return;


  const welcome =
    document.getElementById(
      "storeWelcomeName"
    );

  const userName =
    document.getElementById(
      "headerUserName"
    );

  const avatar =
    document.getElementById(
      "headerAvatar"
    );


  if (welcome) {

    welcome.textContent =
      account.name;

  }


  if (userName) {

    userName.textContent =
      account.name;

  }


  if (avatar) {

    avatar.innerHTML =
      avatarHTML(account);

  }


  updateAccountPage();

}


/* =========================================
   CATEGORIES
========================================= */

function renderCategories() {

  const container =
    document.getElementById(
      "categoriesList"
    );

  if (!container) return;

  container.innerHTML = "";

  const categoryNames = [...new Set(PRODUCTS.map(product => String(product.category || "").trim()).filter(Boolean))];
  const cloudCategories = Array.isArray(SUPABASE_CATEGORY_UI_CACHE) ? SUPABASE_CATEGORY_UI_CACHE : [];
  const knownNames = new Set([...CATEGORIES.map(c => String(c.name || c.id || "").trim().toLowerCase()), ...cloudCategories.map(c => String(c.name || "").trim().toLowerCase())]);
  const dynamicCategories = categoryNames
    .filter(name => !knownNames.has(name.toLowerCase()))
    .map(name => ({ id: name, name, icon: "🏷️" }));
  const normalizedCloudCategories = cloudCategories.map(c => ({
    id: c.name,
    name: c.name,
    icon: c.icon || "🏷️"
  }));
  const categories = [
    ...CATEGORIES.filter(category => category.id === "all"),
    ...CATEGORIES.filter(category => category.id === "__best_selling__"),
    ...CATEGORIES.filter(category => category.id !== "all" && category.id !== "__best_selling__"),
    ...normalizedCloudCategories.filter(c => !CATEGORIES.some(base => String(base.name).trim().toLowerCase() === String(c.name).trim().toLowerCase())),
    ...dynamicCategories
  ];
  if (!categories.some(category => category.id === currentCategory)) currentCategory = "all";

  categories.forEach(
    category => {

      const button =
        document.createElement("button");

      button.className =
        "category-btn";


      if (
        category.id ===
        currentCategory
      ) {

        button.classList.add(
          "active"
        );

      }


      button.type =
        "button";


      button.innerHTML = `

        <span>
          ${category.icon}
        </span>

        <small>
          ${category.name}
        </small>

      `;


      button.onclick =
        () => {

          currentCategory =
            category.id;

          renderCategories();

          renderProducts();

        };


      container.appendChild(button);

    }
  );

}


/* =========================================
   PRODUCTS FILTER
========================================= */

function getFilteredProducts() {

  const search =
    currentSearch
      .trim()
      .toLowerCase();


  return PRODUCTS.filter(
    product => {

      if (product.active === false) return false;

      const categoryMatch =
        currentCategory === "all" ||
        (currentCategory === "__best_selling__"
          ? product.featured === true
          : product.category === currentCategory);


      const searchMatch =
        !search ||
        product.name
          .toLowerCase()
          .includes(search) ||
        product.category
          .toLowerCase()
          .includes(search) ||
        product.description
          .toLowerCase()
          .includes(search);


      return (
        categoryMatch &&
        searchMatch
      );

    }
  );

}


/* =========================================
   PRODUCT CARD
========================================= */

function productImageHTML(product) {

  const images = getProductImages(product);
  const firstImage = images[0] || product.image || "";
  const visual = firstImage
    ? `<img src="${escapeHTML(firstImage)}" alt="${escapeHTML(product.name)}" style="width:100%;height:100%;object-fit:contain" onerror="this.style.display='none'">`
    : `<span class="product-icon">${escapeHTML(product.icon || "📦")}</span>`;

  return `
    <div class="product-image">
      ${visual}
      ${favoriteButtonHTML(product)}
    </div>
  `;

}


function favoriteButtonHTML(product) {

  const account =
    getCurrentAccount();


  const favorite =
    account &&
    Array.isArray(account.favorites) &&
    account.favorites.some(id => sameProductId(id, product.id));


  return `
    <button
      class="favorite-btn ${favorite ? "active" : ""}"
      data-favorite="${product.id}"
      type="button"
      aria-label="المفضلة"
    >
      ${favorite ? "♥" : "♡"}
    </button>
  `;

}


function productCardHTML(product) {

  const price = Number(product.price || 0);
  const oldPrice = product.oldPrice == null
    ? (product.old_price == null ? null : Number(product.old_price))
    : Number(product.oldPrice);
  const hasDiscount = Number.isFinite(oldPrice) && oldPrice > price && price >= 0;
  const discountPercent = hasDiscount
    ? Math.round(((oldPrice - price) / oldPrice) * 100)
    : 0;
  const saving = hasDiscount ? oldPrice - price : 0;

  return `

    <article
      class="product-card"
      data-product="${product.id}"
    >

      ${productImageHTML(product)}

      <div class="product-info">

        <span class="product-category">
          ${escapeHTML(product.category)}
        </span>

        <h3 class="product-name">
          ${escapeHTML(product.name)}
        </h3>

        <p class="product-description">
          ${escapeHTML(product.description)}
        </p>

        <div class="product-bottom">

          <div class="product-price">

            ${hasDiscount ? `
              <div class="product-old-price">${money(oldPrice)} <small>دج</small></div>
              <div class="product-current-price">${money(price)} <small>دج</small></div>
              <div class="product-discount-row">
                <span class="product-discount-badge">خصم ${discountPercent}%</span>
                <span class="product-saving">وفّر ${money(saving)} دج</span>
              </div>
            ` : `
              <div class="product-current-price">${money(price)} <small>دج</small></div>
            `}

          </div>

          <button
            class="add-cart-btn"
            data-cart="${product.id}"
            type="button"
            aria-label="إضافة للسلة"
          >
            +
          </button>

        </div>

      </div>

    </article>

  `;

}


/* =========================================
   RENDER PRODUCTS
========================================= */

function renderProducts() {

  const container =
    document.getElementById(
      "productsGrid"
    );

  const noProducts =
    document.getElementById(
      "noProducts"
    );

  if (!container) return;


  const products =
    getFilteredProducts();


  container.innerHTML =
    products
      .map(productCardHTML)
      .join("");


  if (noProducts) {

    noProducts.classList.toggle(
      "show",
      products.length === 0
    );

  }


  const resultText =
    document.getElementById(
      "productsResultText"
    );


  if (resultText) {

    resultText.textContent =
      `${products.length} منتج`;

  }


  attachProductEvents();

}


/* =========================================
   PRODUCT EVENTS
========================================= */

function attachProductEvents() {

  document
    .querySelectorAll("[data-favorite]")
    .forEach(
      button => {

        button.onclick =
          event => {

            event.preventDefault();

            event.stopPropagation();

            toggleFavorite(button.dataset.favorite);

          };

      }
    );


  document
    .querySelectorAll("[data-cart]")
    .forEach(
      button => {

        button.onclick =
          event => {

            event.preventDefault();

            event.stopPropagation();

            addToCart(button.dataset.cart);

          };

      }
    );


  document
    .querySelectorAll(".product-card")
    .forEach(
      card => {

        card.onclick =
          () => {

            const productId =
              card.dataset.product;

            openProductDetails(
              productId
            );

          };

      }
    );

}


/* =========================================
   PRODUCT DETAILS
========================================= */

let productGalleryIndex = 0;
let productGalleryCurrentId = null;

function renderProductGallery(product) {
  const content = document.getElementById("productGalleryArea");
  if (!content) return;
  const images = getProductImages(product);
  const current = Math.min(Math.max(productGalleryIndex, 0), Math.max(images.length - 1, 0));
  productGalleryIndex = current;

  if (!images.length) {
    content.innerHTML = `<div class="product-gallery-empty">${escapeHTML(product.icon || "📦")}</div>`;
    return;
  }

  const src = images[current];
  content.innerHTML = `
    <div class="product-gallery-main">
      <img src="${escapeHTML(src)}" alt="${escapeHTML(product.name)} - صورة ${current + 1}" onerror="this.style.display='none'">
      ${images.length > 1 ? `
        <button type="button" class="product-gallery-nav prev" id="productGalleryPrev" aria-label="الصورة السابقة">‹</button>
        <button type="button" class="product-gallery-nav next" id="productGalleryNext" aria-label="الصورة التالية">›</button>
      ` : ""}
      <span class="product-gallery-counter">${current + 1} / ${images.length}</span>
    </div>
    ${images.length > 1 ? `
      <div class="product-gallery-thumbs" role="tablist" aria-label="صور المنتج">
        ${images.map((image, index) => `
          <button type="button" class="product-gallery-thumb ${index === current ? "active" : ""}" data-gallery-index="${index}" aria-label="عرض الصورة ${index + 1}">
            <img src="${escapeHTML(image)}" alt="صورة ${index + 1}" onerror="this.style.opacity='.35'">
          </button>
        `).join("")}
      </div>
    ` : ""}
  `;

  content.querySelector("#productGalleryPrev")?.addEventListener("click", event => {
    event.stopPropagation();
    productGalleryIndex = (current - 1 + images.length) % images.length;
    renderProductGallery(product);
  });
  content.querySelector("#productGalleryNext")?.addEventListener("click", event => {
    event.stopPropagation();
    productGalleryIndex = (current + 1) % images.length;
    renderProductGallery(product);
  });
  content.querySelectorAll("[data-gallery-index]").forEach(button => {
    button.addEventListener("click", event => {
      event.stopPropagation();
      productGalleryIndex = Number(button.dataset.galleryIndex);
      renderProductGallery(product);
    });
  });
}

function openProductDetails(productId) {
  const product = PRODUCTS.find(item => sameProductId(item.id, productId));
  if (!product) return;
  const content = document.getElementById("productDetailsContent");
  if (!content) return;
  const account = getCurrentAccount();
  const favorite = account && Array.isArray(account.favorites) && account.favorites.some(id => sameProductId(id, product.id));
  productGalleryCurrentId = product.id;
  productGalleryIndex = 0;

  content.innerHTML = `
    <div class="product-details-card">
      <div id="productGalleryArea" class="product-gallery-area"></div>
      <span class="product-category">${escapeHTML(product.category)}</span>
      <h1>${escapeHTML(product.name)}</h1>
      <p>${escapeHTML(product.description)}</p>
      ${(() => {
        const price = Number(product.price || 0);
        const oldPrice = product.oldPrice == null
          ? (product.old_price == null ? null : Number(product.old_price))
          : Number(product.oldPrice);
        const hasDiscount = Number.isFinite(oldPrice) && oldPrice > price && price >= 0;
        const discountPercent = hasDiscount ? Math.round(((oldPrice - price) / oldPrice) * 100) : 0;
        const saving = hasDiscount ? oldPrice - price : 0;
        return `<div class="product-details-price">
          ${hasDiscount ? `<span class="product-details-old-price">${money(oldPrice)} دج</span>` : ""}
          <strong>${money(price)} دج</strong>
          ${hasDiscount ? `<span class="product-details-discount">خصم ${discountPercent}% · وفّر ${money(saving)} دج</span>` : ""}
        </div>`;
      })()}
      <div class="product-details-actions">
        <button class="primary-btn" type="button" id="detailsAddCartBtn">🛒 إضافة إلى السلة</button>
        <button class="secondary-btn" type="button" id="detailsFavoriteBtn">${favorite ? "♥ إزالة من المفضلة" : "♡ إضافة للمفضلة"}</button>
      </div>
    </div>
  `;

  renderProductGallery(product);

  document.getElementById("detailsAddCartBtn")?.addEventListener("click", () => addToCart(product.id));
  document.getElementById("detailsFavoriteBtn")?.addEventListener("click", () => {
    toggleFavorite(product.id);
    openProductDetails(product.id);
  });

  showScreen("productDetails");
}


const productDetailsBackBtn = document.getElementById("productDetailsBackBtn");
if (productDetailsBackBtn) {
  productDetailsBackBtn.addEventListener("click", function(event) {
    event.preventDefault();
    openStore();
  });
}


/* =========================================
   FAVORITES
========================================= */

function toggleFavorite(productId) {

  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);


  if (!account) return;


  if (
    !Array.isArray(
      account.favorites
    )
  ) {

    account.favorites = [];

  }


  const index = account.favorites.findIndex(id => sameProductId(id, productId));


  if (index >= 0) {

    account.favorites.splice(
      index,
      1
    );

    saveAccounts(accounts);

    showToast(
      "تمت إزالة المنتج من المفضلة",
      "♡"
    );

  } else {

    account.favorites.push(
      productId
    );

    saveAccounts(accounts);

    showToast(
      "تمت إضافة المنتج للمفضلة",
      "♥"
    );

  }


  const activeFavoriteScreen =
    document
      .getElementById("favoritesScreen")
      ?.classList.contains("active");


  if (activeFavoriteScreen) {

    renderFavorites();

  } else {

    renderProducts();

  }


  updateBadges();

}


/* =========================================
   FAVORITES PAGE
========================================= */

function renderFavorites() {

  const account =
    getCurrentAccount();


  if (!account) return;


  const ids =
    Array.isArray(account.favorites)
      ? account.favorites
      : [];


  const products =
    PRODUCTS.filter(
      product =>
        ids.includes(product.id)
    );


  const grid =
    document.getElementById(
      "favoritesGrid"
    );

  const empty =
    document.getElementById(
      "emptyFavorites"
    );


  if (!grid) return;


  grid.innerHTML =
    products
      .map(productCardHTML)
      .join("");


  if (empty) {

    empty.style.display =
      products.length
        ? "none"
        : "block";

  }


  attachProductEvents();

}


function openFavorites() {

  const account =
    getCurrentAccount();


  if (!account) {

    showScreen("home");

    return;

  }


  renderFavorites();

  updateBadges();

  updateBottomNavigation(
    "favorites"
  );

  showScreen("favorites");

}


/* =========================================
   CART
========================================= */

function getCart() {

  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);


  if (!account) {

    return [];

  }


  if (
    !Array.isArray(
      account.cart
    )
  ) {

    account.cart = [];

    saveAccounts(accounts);

  }


  return account.cart;

}


/* =========================================
   ADD TO CART
========================================= */

function addToCart(productId) {

  const managedProduct = PRODUCTS.find(item => sameProductId(item.id, productId));
  if (managedProduct && Number(managedProduct.stock ?? 0) <= 0) {
    showToast("هذا المنتج غير متوفر حاليًا", "!");
    return;
  }


  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);


  if (!account) return;


  if (
    !Array.isArray(
      account.cart
    )
  ) {

    account.cart = [];

  }


  const item =
    account.cart.find(
      cartItem =>
        sameProductId(cartItem.productId, productId)
    );


  const availableStock = Math.max(0, Number(managedProduct?.stock ?? 0));

  if (item) {

    if (item.quantity >= availableStock) {
      showToast("لا يمكنك تجاوز الكمية المتوفرة في المخزون", "!");
      return;
    }

    item.quantity = Number(item.quantity || 0) + 1;

  } else {

    account.cart.push({

      productId,

      quantity: 1

    });

  }


  saveAccounts(accounts);

  updateBadges();


  showToast(
    "تمت إضافة المنتج للسلة",
    "🛒"
  );

}


/* =========================================
   OPEN CART
========================================= */

function openCart() {

  const account =
    getCurrentAccount();


  if (!account) {

    showScreen("home");

    return;

  }


  renderCart();

  updateBottomNavigation(
    "cart"
  );

  showScreen("cart");

}


/* =========================================
   RENDER CART
========================================= */

function renderCart() {

  const account =
    getCurrentAccount();


  if (!account) return;


  const cart =
    Array.isArray(account.cart)
      ? account.cart
      : [];


  const container =
    document.getElementById(
      "cartItems"
    );

  const empty =
    document.getElementById(
      "emptyCart"
    );

  const summary =
    document.getElementById(
      "cartSummary"
    );


  if (!container) return;


  const validItems =
    cart
      .map(
        item => ({

          ...item,

          product:
            PRODUCTS.find(
              product =>
                sameProductId(product.id, item.productId)
            )

        })
      )
      .filter(
        item =>
          item.product &&
          Number(item.quantity) > 0
      );


  container.innerHTML =
    validItems
      .map(cartItemHTML)
      .join("");


  const hasItems =
    validItems.length > 0;


  if (empty) {

    empty.style.display =
      hasItems
        ? "none"
        : "block";

  }


  if (summary) {

    summary.style.display =
      hasItems
        ? "block"
        : "none";

  }


  const totalItems =
    validItems.reduce(
      (
        total,
        item
      ) =>
        total +
        Number(item.quantity),
      0
    );


  const totalPrice =
    validItems.reduce(
      (
        total,
        item
      ) =>
        total +
        (
          item.product.price *
          Number(item.quantity)
        ),
      0
    );


  const summaryItems =
    document.getElementById(
      "summaryItems"
    );

  const summaryTotal =
    document.getElementById(
      "summaryTotal"
    );


  if (summaryItems) {

    summaryItems.textContent =
      totalItems;

  }


  if (summaryTotal) {

    summaryTotal.textContent =
      money(totalPrice);

  }


  attachCartEvents();

}


/* =========================================
   CART ITEM
========================================= */

function cartItemHTML(item) {

  const product =
    item.product;


  return `

    <div
      class="cart-item"
      data-cart-item="${product.id}"
    >

      <div class="cart-item-image">
        ${getProductImages(product)[0] ? `<img src="${escapeHTML(getProductImages(product)[0])}" alt="${escapeHTML(product.name)}" onerror="this.style.display='none'">` : `<span>${escapeHTML(product.icon || "📦")}</span>`}
      </div>


      <div class="cart-item-info">

        <strong>
          ${escapeHTML(product.name)}
        </strong>

        <small>
          ${money(product.price)} دج
        </small>


        <div class="quantity-controls">

          <button
            type="button"
            data-quantity="minus"
            data-id="${product.id}"
          >
            −
          </button>

          <span>
            ${item.quantity}
          </span>

          <button
            type="button"
            data-quantity="plus"
            data-id="${product.id}"
          >
            +
          </button>

        </div>

      </div>


      <div class="cart-item-total">

        ${money(
          product.price *
          item.quantity
        )}
        دج

        <br>

        <button
          type="button"
          class="remove-cart"
          data-remove-cart="${product.id}"
          aria-label="حذف المنتج"
        >
          🗑️
        </button>

      </div>

    </div>

  `;

}


/* =========================================
   CART EVENTS
========================================= */

function attachCartEvents() {

  document
    .querySelectorAll("[data-quantity]")
    .forEach(
      button => {

        button.onclick =
          event => {

            event.preventDefault();

            event.stopPropagation();

            changeQuantity(
              button.dataset.id,
              button.dataset.quantity
            );

          };

      }
    );


  document
    .querySelectorAll("[data-remove-cart]")
    .forEach(
      button => {

        button.onclick =
          event => {

            event.preventDefault();

            event.stopPropagation();

            removeFromCart(
              button.dataset.removeCart
            );

          };

      }
    );

}


/* =========================================
   CHANGE QUANTITY
========================================= */

function changeQuantity(
  productId,
  action
) {

  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);


  if (!account) return;


  if (
    !Array.isArray(
      account.cart
    )
  ) {

    account.cart = [];

  }


  const item =
    account.cart.find(
      cartItem =>
        sameProductId(cartItem.productId, productId)
    );


  if (!item) return;


  if (action === "plus") {

    const managedProduct = PRODUCTS.find(product => sameProductId(product.id, productId));
    const stock = managedProduct ? Number(managedProduct.stock ?? Infinity) : Infinity;
    if (item.quantity >= stock) {
      showToast("لا يمكن تجاوز الكمية المتوفرة في المخزون", "!");
      return;
    }
    item.quantity = Number(item.quantity || 0) + 1;

  } else {

    item.quantity = Math.max(1, Number(item.quantity || 1) - 1);

  }


  if (item.quantity <= 0) {

    account.cart =
      account.cart.filter(
        cartItem =>
          !sameProductId(cartItem.productId, productId)
      );

  }


  saveAccounts(accounts);

  renderCart();

  updateBadges();

}


/* =========================================
   REMOVE FROM CART
========================================= */

function removeFromCart(productId) {

  const accounts =
    getAccounts();

  const account =
    getCurrentAccountFrom(accounts);


  if (!account) return;


  if (
    !Array.isArray(
      account.cart
    )
  ) {

    account.cart = [];

  }


  const oldLength =
    account.cart.length;


  account.cart = account.cart.filter(item => !sameProductId(item.productId, productId));


  if (
    account.cart.length !==
    oldLength
  ) {

    saveAccounts(accounts);

    renderCart();

    updateBadges();

    showToast(
      "تم حذف المنتج من السلة",
      "🗑️"
    );

  }

}


/* =========================================
   CHECKOUT
========================================= */

function getCheckoutItems() {

  const account =
    getCurrentAccount();

  if (!account) {

    return [];

  }


  const cart =
    Array.isArray(account.cart)
      ? account.cart
      : [];


  return cart
    .map(item => {

      const product =
        PRODUCTS.find(
          product =>
            sameProductId(product.id, item.productId)
        );


      if (!product) {

        return null;

      }


      const quantity =
        Math.max(
          1,
          Number(item.quantity) || 1
        );


      return {

        productId:
          product.id,

        name:
          product.name,

        icon:
          product.icon,

        image:
          getProductImages(product)[0] || product.image || "",

        images:
          getProductImages(product),

        price:
          product.price,

        quantity,

        total:
          product.price * quantity

      };

    })
    .filter(Boolean);

}


function getCheckoutItemsCount(items) {

  return items.reduce(
    (
      total,
      item
    ) =>
      total +
      Number(item.quantity),
    0
  );

}


function getCheckoutTotal(items) {

  return items.reduce(
    (
      total,
      item
    ) =>
      total +
      (
        Number(item.price) *
        Number(item.quantity)
      ),
    0
  );

}


/* =========================================
   FIND ELEMENT
========================================= */

function findElement(...ids) {

  for (const id of ids) {

    const element =
      document.getElementById(id);

    if (element) {

      return element;

    }

  }

  return null;

}


/* =========================================
   إصلاح خانات الحي والملاحظات
========================================= */

/*
  هذه الإضافة مهمة للمشكلة التي ذكرتها.

  بعض تنسيقات CSS قد تجعل النص داخل
  input أو textarea غير واضح، خصوصًا
  مع اتجاه RTL.

  لذلك نضبط الخانات مباشرة من JavaScript.
*/

function fixCheckoutTextFields() {

  const fields = [

    findElement(
      "checkoutCommune",
      "orderCommune",
      "checkoutDistrict",
      "orderDistrict"
    ),

    findElement(
      "checkoutNotes",
      "orderNotes",
      "checkoutNote"
    ),

    findElement(
      "checkoutAddress",
      "orderAddress",
      "checkoutFullAddress"
    )

  ];


  fields.forEach(
    field => {

      if (!field) return;


      field.setAttribute(
        "dir",
        "rtl"
      );


      field.style.direction =
        "rtl";


      field.style.textAlign =
        "right";


      /*
        منع بعض مشاكل CSS التي تجعل
        النص أبيض أو شبه شفاف.
      */

      field.style.opacity =
        "1";


      field.style.webkitTextFillColor =
        "inherit";


      /*
        التأكد من أن الكتابة مسموحة.
      */

      field.readOnly =
        false;


      field.disabled =
        false;

    }
  );

}


/*
  نعيد إصلاح الخانات بعد فتح صفحة
  إتمام الطلب، وبعد ملء البيانات.
*/

function prepareCheckoutFields() {

  fixCheckoutTextFields();


  const commune =
    findElement(
      "checkoutCommune",
      "orderCommune",
      "checkoutDistrict",
      "orderDistrict"
    );


  const notes =
    findElement(
      "checkoutNotes",
      "orderNotes",
      "checkoutNote"
    );


  if (commune) {

    commune.addEventListener(
      "input",
      function() {

        this.style.direction =
          "rtl";

        this.style.textAlign =
          "right";

        this.style.opacity =
          "1";

      }
    );

  }


  if (notes) {

    notes.addEventListener(
      "input",
      function() {

        this.style.direction =
          "rtl";

        this.style.textAlign =
          "right";

        this.style.opacity =
          "1";

      }
    );

  }

}


/* =========================================
   RENDER CHECKOUT ITEMS
========================================= */

function renderCheckoutItems() {

  const container =
    findElement(
      "checkoutItems",
      "orderItems",
      "checkoutProducts",
      "orderProducts"
    );


  if (!container) return;


  const items =
    checkoutItemsSnapshot;


  if (!items.length) {

    container.innerHTML = `

      <div class="empty-state">

        <div>🛒</div>

        <h3>
          لا توجد منتجات في الطلب
        </h3>

        <p>
          عد إلى السلة وأضف المنتجات أولًا
        </p>

      </div>

    `;

    return;

  }


  container.innerHTML =
    items
      .map(
        item => `

          <div
            class="checkout-product-item"
            data-checkout-product="${item.productId}"
          >

            <div class="checkout-product-icon">
              ${item.icon}
            </div>

            <div class="checkout-product-info">

              <strong>
                ${escapeHTML(item.name)}
              </strong>

              <span>
                ${money(item.price)} دج
              </span>

              <small>
                الكمية:
                ${item.quantity}
              </small>

            </div>

            <div class="checkout-product-total">

              ${money(item.total)}
              دج

            </div>

          </div>

        `
      )
      .join("");

}


/* =========================================
   CHECKOUT SUMMARY
========================================= */

function renderCheckoutSummary() {

  const items =
    checkoutItemsSnapshot;


  const total =
    checkoutTotalSnapshot;


  const count =
    getCheckoutItemsCount(items);


  const countElements = [

    findElement(
      "checkoutItemsCount",
      "checkoutProductsCount",
      "orderItemsCount",
      "checkoutCount"
    ),

    document.getElementById(
      "summaryItems"
    )

  ];


  countElements.forEach(
    element => {

      if (element) {

        element.textContent =
          count;

      }

    }
  );


  const totalElements = [

    findElement(
      "checkoutTotal",
      "checkoutGrandTotal",
      "orderTotal",
      "checkoutSummaryTotal"
    ),

    document.getElementById(
      "summaryTotal"
    )

  ];


  totalElements.forEach(
    element => {

      if (element) {

        element.textContent =
          money(total);

      }

    }
  );


  const orderCountText =
    findElement(
      "checkoutOrderCount",
      "orderCountText",
      "checkoutResultText"
    );


  if (orderCountText) {

    orderCountText.textContent =
      `${count} طلبية`;

  }

}


/* =========================================
   FILL CHECKOUT FORM
========================================= */

function fillCheckoutForm() {

  const account =
    getCurrentAccount();

  if (!account) return;


  const address =
    account.shippingAddress || {

      fullName:
        account.name || "",

      phone: "",

      wilaya: "",

      commune: "",

      address: "",

      notes: ""

    };


  const fullName =
    findElement(
      "checkoutFullName",
      "orderFullName"
    );

  if (fullName) {

    fullName.value =
      address.fullName ||
      account.name ||
      "";

  }


  const lastName =
    findElement(
      "checkoutLastName",
      "orderLastName",
      "checkoutSurname"
    );

  if (lastName) {

    lastName.value =
      address.lastName ||
      "";

  }


  const phone =
    findElement(
      "checkoutPhone",
      "orderPhone"
    );

  if (phone) {

    phone.value =
      address.phone ||
      "";

  }


  const wilaya =
    findElement(
      "checkoutWilaya",
      "orderWilaya"
    );

  if (wilaya) {

    wilaya.value =
      address.wilaya ||
      "";

  }


  const commune =
    findElement(
      "checkoutCommune",
      "orderCommune",
      "checkoutDistrict",
      "orderDistrict"
    );

  if (commune) {

    commune.value =
      address.commune ||
      "";

  }


  const addressInput =
    findElement(
      "checkoutAddress",
      "orderAddress",
      "checkoutFullAddress"
    );

  if (addressInput) {

    addressInput.value =
      address.address ||
      "";

  }


  const notes =
    findElement(
      "checkoutNotes",
      "orderNotes",
      "checkoutNote"
    );

  if (notes) {

    notes.value =
      address.notes ||
      "";

  }


  /*
    بعد تعبئة الخانات نصلح مظهرها.
  */

  fixCheckoutTextFields();

}


/* =========================================
   READ CHECKOUT FORM
========================================= */

function readCheckoutForm() {

  const getValue =
    (...ids) => {

      const element =
        findElement(...ids);

      return element
        ? String(
            element.value || ""
          ).trim()
        : "";

    };


  return {

    fullName:
      getValue(
        "checkoutFullName",
        "orderFullName"
      ),

    lastName:
      getValue(
        "checkoutLastName",
        "orderLastName",
        "checkoutSurname"
      ),

    phone:
      getValue(
        "checkoutPhone",
        "orderPhone"
      ),

    wilaya:
      getValue(
        "checkoutWilaya",
        "orderWilaya"
      ),

    commune:
      getValue(
        "checkoutCommune",
        "orderCommune",
        "checkoutDistrict",
        "orderDistrict"
      ),

    address:
      getValue(
        "checkoutAddress",
        "orderAddress",
        "checkoutFullAddress"
      ),

    notes:
      getValue(
        "checkoutNotes",
        "orderNotes",
        "checkoutNote"
      )

  };

}


/* =========================================
   OPEN CHECKOUT
========================================= */

function openCheckout() {

  const account =
    getCurrentAccount();


  if (!account) {

    showScreen("home");

    return;

  }


  const items =
    getCheckoutItems();


  if (!items.length) {

    showToast(
      "السلة فارغة",
      "🛒"
    );

    openCart();

    return;

  }


  checkoutItemsSnapshot =
    items.map(
      item => ({
        ...item
      })
    );


  checkoutTotalSnapshot =
    getCheckoutTotal(
      checkoutItemsSnapshot
    );


  hideCheckoutSuccess();


  renderCheckoutItems();

  renderCheckoutSummary();

  fillCheckoutForm();

  showCheckoutForm();

  prepareCheckoutFields();

  updateBottomNavigation(
    null
  );


  showScreen("checkout");


  /*
    نؤكد الإصلاح مرة أخرى بعد ظهور الشاشة.
  */

  setTimeout(
    () => {

      fixCheckoutTextFields();

    },
    50
  );

}


/* =========================================
   SHOW CHECKOUT FORM
========================================= */

function showCheckoutForm() {

  // Every time a fresh checkout is opened, reset the previous submission
  // state. Luffy 23 could leave the confirm button disabled after the first
  // successful checkout because the success element was still visible.
  window.__MYSTORE_ORDER_SUBMISSION_LOCK = false;
  confirmCheckoutOrder.processing = false;

  const confirmButton = findElement(
    "confirmCheckoutBtn",
    "checkoutConfirmBtn",
    "confirmOrderBtn",
    "confirmOrder",
    "submitOrderBtn",
    "placeOrderBtn"
  );
  if (confirmButton) {
    confirmButton.disabled = false;
    confirmButton.removeAttribute("aria-disabled");
  }

  const form =
    findElement(
      "checkoutForm",
      "orderForm"
    );


  if (form) {

    form.style.display =
      "";

  }


  const content =
    findElement(
      "checkoutContent",
      "checkoutFormContent",
      "orderContent"
    );


  if (content) {

    content.style.display =
      "";

  }

}


/* =========================================
   HIDE CHECKOUT FORM
========================================= */

function hideCheckoutForm() {

  const form =
    findElement(
      "checkoutForm",
      "orderForm"
    );


  if (form) {

    form.style.display =
      "none";

  }


  const content =
    findElement(
      "checkoutContent",
      "checkoutFormContent",
      "orderContent"
    );


  if (content) {

    content.style.display =
      "none";

  }

}


/* =========================================
   CREATE SUCCESS MESSAGE IF NEEDED
========================================= */

function createCheckoutSuccessElement() {

  let success =
    findElement(
      "orderSuccessMessage",
      "checkoutSuccess",
      "orderSuccess",
      "checkoutSuccessMessage"
    );


  if (success) {

    return success;

  }


  /*
    إذا لم توجد رسالة النجاح في HTML،
    ننشئها تلقائيًا داخل صفحة checkout.
  */

  const screen =
    document.getElementById(
      "checkoutScreen"
    );


  if (!screen) {

    return null;

  }


  success =
    document.createElement("div");


  success.id =
    "checkoutSuccessAuto";


  success.setAttribute(
    "dir",
    "rtl"
  );


  success.style.display =
    "none";


  success.style.margin =
    "20px auto";


  success.style.padding =
    "24px";


  success.style.maxWidth =
    "500px";


  success.style.textAlign =
    "center";


  success.style.borderRadius =
    "18px";


  success.style.background =
    "#e8f8ee";


  success.style.color =
    "#176b3a";


  success.style.border =
    "1px solid #a9dfbd";


  success.style.fontSize =
    "18px";


  success.style.fontWeight =
    "700";


  success.innerHTML = `

    <div style="font-size:48px;margin-bottom:10px;">
      🎉
    </div>

    <div>
      تم تأكيد طلبك بنجاح!
    </div>

    <div
      id="checkoutSuccessDetailsAuto"
      style="
        margin-top:10px;
        font-size:14px;
        font-weight:500;
      "
    ></div>

    <button
      id="checkoutSuccessAutoBackBtn"
      type="button"
      class="primary-btn full-btn"
      style="margin-top:18px"
    >
      🛍️ العودة إلى المتجر
    </button>

  `;


  screen.appendChild(
    success
  );


  return success;

}


/* =========================================
   SHOW CHECKOUT SUCCESS
========================================= */

function showCheckoutSuccess() {

  const success =
    createCheckoutSuccessElement();


  if (!success) {

    /*
      حتى لو لم نستطع إنشاء العنصر،
      نضمن أن المستخدم يرى رسالة النجاح.
    */

    showToast(
      "🎉 تم تأكيد طلبك بنجاح!",
      "✓"
    );

    return;

  }


  success.style.display =
    "block";


  success.classList.add(
    "show"
  );


  /*
    عرض عدد المنتجات والإجمالي
    داخل رسالة النجاح إذا كان العنصر
    الذي أنشأناه نحن.
  */

  const details =
    document.getElementById(
      "checkoutSuccessDetailsAuto"
    );


  if (details) {

    details.textContent =
      `${getCheckoutItemsCount(checkoutItemsSnapshot)} منتجات — الإجمالي ${money(checkoutTotalSnapshot)} دج`;

  }

}


/* =========================================
   HIDE CHECKOUT SUCCESS
========================================= */

function hideCheckoutSuccess() {

  const success =
    findElement(
      "orderSuccessMessage",
      "checkoutSuccess",
      "orderSuccess",
      "checkoutSuccessMessage",
      "checkoutSuccessAuto"
    );


  if (success) {

    success.style.display =
      "none";

    success.classList.remove(
      "show"
    );

  }

}


/* =========================================
   SAVE ORDER
========================================= */
/*
  ORDER SUBMISSION LOCK
  يمنع تكرار الطلب حتى لو تم تسجيل أكثر من event
  أو أعيد تنفيذ واجهة الصفحة داخل WebView/CodePen.
*/
window.__MYSTORE_ORDER_SUBMISSION_LOCK =
  window.__MYSTORE_ORDER_SUBMISSION_LOCK || false;
window.__MYSTORE_LAST_SUBMITTED_ORDER_KEY =
  window.__MYSTORE_LAST_SUBMITTED_ORDER_KEY || null;


async function saveOrder(orderData) {
  const account = getCurrentAccount();
  const session = getSupabaseSession();
  const token = session?.access_token || "";
  const supabaseUserId = session?.user?.id || "";

  if (!account || !token || !supabaseUserId) {
    console.error("MyStore orders: missing authenticated Supabase session.", {
      hasAccount: !!account,
      supabaseUserId: !!supabaseUserId,
      hasToken: !!token
    });
    return false;
  }

  const items = Array.isArray(checkoutItemsSnapshot)
    ? checkoutItemsSnapshot.map(item => ({ ...item }))
    : [];
  if (!items.length) return false;

  const customerName = [orderData.fullName, orderData.lastName]
    .map(v => String(v || "").trim()).filter(Boolean).join(" ");
  const subtotal = items.reduce((sum, item) =>
    sum + Number(item.price || 0) * Math.max(1, Number(item.quantity || 1)), 0);
  const total = Number(checkoutTotalSnapshot || subtotal);

  // Keep one stable order number for this checkout attempt. If the client
  // times out after Supabase has committed, a retry reuses the same number
  // instead of creating a second order.
  const pendingKey = `mystore_pending_order_${supabaseUserId}`;
  let pending = null;
  try { pending = JSON.parse(localStorage.getItem(pendingKey) || "null"); } catch { pending = null; }
  const snapshotKey = JSON.stringify({
    items: items.map(i => [i.productId ?? i.id ?? null, i.name || i.title || "", Number(i.quantity || 1), Number(i.price || 0)]),
    customerName,
    phone: String(orderData.phone || "").trim(),
    wilaya: String(orderData.wilaya || "").trim(),
    commune: String(orderData.commune || "").trim(),
    address: String(orderData.address || "").trim(),
    total
  });
  let orderNumber = Number(pending?.orderNumber);
  if (!pending || pending.snapshotKey !== snapshotKey || !Number.isFinite(orderNumber) || orderNumber <= 0) {
    orderNumber = Number(`${Date.now()}${Math.floor(Math.random() * 10)}`.slice(-12));
    try { localStorage.setItem(pendingKey, JSON.stringify({ orderNumber, snapshotKey })); } catch {}
  }

  const orderPayload = {
    order_number: orderNumber,
    user_id: supabaseUserId,
    customer_name: customerName,
    customer_phone: String(orderData.phone || "").trim(),
    wilaya: String(orderData.wilaya || "").trim(),
    commune: String(orderData.commune || "").trim(),
    address: String(orderData.address || "").trim(),
    notes: String(orderData.notes || "").trim() || null,
    subtotal: Number(subtotal),
    delivery_fee: Math.max(0, Number(total - subtotal)),
    total: Number(total),
    status: "new",
    payment_method: "cash_on_delivery"
  };

  let createdOrder = null;
  try {
    // First recover a previously committed order if a prior attempt timed out
    // after the server had already inserted it.
    const existing = await c3Request(
      `orders?select=*&order_number=eq.${encodeURIComponent(String(orderNumber))}&limit=1`,
      "GET", undefined, token
    );
    if (Array.isArray(existing) && existing[0]?.id) {
      createdOrder = existing[0];
    } else {
      const createdRows = await c3Request("orders?select=*", "POST", orderPayload, token);
      createdOrder = Array.isArray(createdRows) ? createdRows[0] : createdRows;
    }
    if (!createdOrder?.id) throw new Error("Supabase did not return the created order.");

    // If the recovered order already has items, it is already a completed
    // checkout. Otherwise create exactly the missing item rows.
    const existingItems = await c3Request(
      `order_items?select=*&order_id=eq.${encodeURIComponent(String(createdOrder.id))}`,
      "GET", undefined, token
    );
    const existingItemRows = Array.isArray(existingItems) ? existingItems : [];

    const itemRows = items.map(item => {
      const rawProductId = item.productId ?? item.product_id ?? item.id ?? null;
      const productId = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(rawProductId || ""))
        ? String(rawProductId) : null;
      return {
        order_id: createdOrder.id,
        product_id: productId,
        product_name: String(item.name || item.title || "منتج"),
        quantity: Math.max(1, Number(item.quantity || 1)),
        unit_price: Number(item.price || 0),
        image: String(item.image || (Array.isArray(item.images) ? item.images[0] : "") || "") || null
      };
    });

    if (existingItemRows.length === 0) {
      for (const row of itemRows) await c3Request("order_items", "POST", row, token);
    }

    // Cloud success is now definitive. Local bookkeeping must never turn a
    // successfully committed cloud order into a false checkout error.
    try {
      if (!Array.isArray(account.orders)) account.orders = [];
      const localOrder = {
        id: createdOrder.id,
        cloudId: createdOrder.id,
        createdAt: createdOrder.created_at || new Date().toISOString(),
        updatedAt: createdOrder.updated_at || new Date().toISOString(),
        customer: { fullName: orderData.fullName, lastName: orderData.lastName, phone: orderData.phone, wilaya: orderData.wilaya, commune: orderData.commune, address: orderData.address, notes: orderData.notes },
        items,
        totalItems: getCheckoutItemsCount(items),
        total,
        status: createdOrder.status || "new"
      };
      const idx = account.orders.findIndex(o => String(o.cloudId || o.id) === String(createdOrder.id));
      if (idx >= 0) account.orders[idx] = { ...account.orders[idx], ...localOrder };
      else account.orders.unshift(localOrder);
      account.shippingAddress = { fullName: orderData.fullName, phone: orderData.phone, wilaya: orderData.wilaya, commune: orderData.commune, address: orderData.address, notes: orderData.notes };

      // Clear and persist the cart immediately after the cloud order is
      // confirmed. Stock bookkeeping is deliberately kept OUTSIDE the
      // success-critical path so a stock/local-sync problem can never make
      // a successfully saved order look like a failed checkout.
      account.cart = [];
      const persistedAccounts = getAccounts();
      const persistedIndex = persistedAccounts.findIndex(a => String(a.id) === String(account.id));
      if (persistedIndex >= 0) {
        persistedAccounts[persistedIndex] = { ...persistedAccounts[persistedIndex], cart: [] };
        saveAccounts(persistedAccounts);
      } else {
        saveAccounts([...persistedAccounts, { ...account, cart: [] }]);
      }
      // Keep the in-memory checkout state empty as well so reopening the cart
      // after leaving the page cannot resurrect the submitted items.
      checkoutItemsSnapshot = [];
      checkoutTotalSnapshot = 0;

      // Stock is best-effort local bookkeeping only. It must never affect
      // the checkout result or prevent a second checkout later.
      try { decreaseProductStock(items); } catch (stockError) {
        console.warn("MyStore orders: local stock bookkeeping failed after successful order.", stockError);
      }
    } catch (localError) {
      console.warn("MyStore orders: local bookkeeping failed after cloud success; keeping checkout successful.", localError);
    }

    try { localStorage.removeItem(pendingKey); } catch {}
    return true;
  } catch (error) {
    console.error("MyStore orders: cloud order creation failed.", error);

    // Network/WebView clients can report a fetch failure even after
    // Supabase has committed the INSERT. Before declaring checkout failed,
    // recover the same pending order and verify that its items exist.
    try {
      const recovery = await c3Request(
        `orders?select=*&order_number=eq.${encodeURIComponent(String(orderNumber))}&limit=1`,
        "GET", undefined, token
      );
      const recoveredOrder = Array.isArray(recovery) ? recovery[0] : null;
      if (recoveredOrder?.id) {
        const recoveredItems = await c3Request(
          `order_items?select=*&order_id=eq.${encodeURIComponent(String(recoveredOrder.id))}`,
          "GET", undefined, token
        );
        const rows = Array.isArray(recoveredItems) ? recoveredItems : [];
        if (rows.length >= items.length) {
          try {
            if (!Array.isArray(account.orders)) account.orders = [];
            account.cart = [];
            const recoveredLocal = {
              id: recoveredOrder.id,
              cloudId: recoveredOrder.id,
              createdAt: recoveredOrder.created_at || new Date().toISOString(),
              updatedAt: recoveredOrder.updated_at || new Date().toISOString(),
              customer: { fullName: orderData.fullName, lastName: orderData.lastName, phone: orderData.phone, wilaya: orderData.wilaya, commune: orderData.commune, address: orderData.address, notes: orderData.notes },
              items,
              totalItems: getCheckoutItemsCount(items),
              total,
              status: recoveredOrder.status || "new"
            };
            const idx = account.orders.findIndex(o => String(o.cloudId || o.id) === String(recoveredOrder.id));
            if (idx >= 0) account.orders[idx] = { ...account.orders[idx], ...recoveredLocal };
            else account.orders.unshift(recoveredLocal);
            saveAccounts(getAccounts().map(a => String(a.id) === String(account.id) ? account : a));
          } catch (localRecoveryError) {
            console.warn("MyStore orders: local recovery bookkeeping failed.", localRecoveryError);
          }
          try { localStorage.removeItem(pendingKey); } catch {}
          return true;
        }
      }
    } catch (recoveryError) {
      console.warn("MyStore orders: recovery check failed.", recoveryError);
    }

    return false;
  }
}

/* =========================================
   VALIDATE CHECKOUT
========================================= */

function validateCheckoutData(data) {

  if (
    data.fullName.length < 2
  ) {

    return {
      valid: false,
      message: "يرجى كتابة الاسم."
    };

  }


  if (
    data.lastName.length < 2
  ) {

    return {
      valid: false,
      message: "يرجى كتابة اللقب."
    };

  }


  if (
    data.phone.length < 8
  ) {

    return {
      valid: false,
      message: "يرجى كتابة رقم الهاتف بشكل صحيح."
    };

  }


  if (
    data.wilaya.length < 2
  ) {

    return {
      valid: false,
      message: "يرجى اختيار أو كتابة الولاية."
    };

  }


  if (
    data.commune.length < 2
  ) {

    return {
      valid: false,
      message: "يرجى كتابة الحي."
    };

  }


  if (
    data.address.length < 3
  ) {

    return {
      valid: false,
      message: "يرجى كتابة العنوان بالتفصيل."
    };

  }


  return {
    valid: true,
    message: ""
  };

}


/* =========================================
   CHECKOUT MESSAGE
========================================= */

function setCheckoutMessage(
  message,
  type = "error"
) {

  const messageElement =
    findElement(
      "checkoutMessage",
      "orderMessage",
      "checkoutFormMessage"
    );


  if (!messageElement) {

    showToast(
      message,
      "!"
    );

    return;

  }


  messageElement.textContent =
    message;

  messageElement.className =
    `form-message ${type}`;

}


/* =========================================
   CONFIRM CHECKOUT ORDER
========================================= */

async function confirmCheckoutOrder() {
  /*
    قفل عالمي على window وليس خاصًا بالدالة فقط.
    هذا يمنع تكرار إنشاء الطلب حتى لو أعيد ربط event
    أو حدث submit/click متزامنان.
  */
  if (window.__MYSTORE_ORDER_SUBMISSION_LOCK) {
    return;
  }

  window.__MYSTORE_ORDER_SUBMISSION_LOCK = true;
  confirmCheckoutOrder.processing = true;

  const confirmButton = findElement(
    "confirmCheckoutBtn",
    "checkoutConfirmBtn",
    "confirmOrderBtn",
    "confirmOrder",
    "submitOrderBtn",
    "placeOrderBtn"
  );

  if (confirmButton) {
    confirmButton.disabled = true;
    confirmButton.setAttribute("aria-disabled", "true");
  }

  try {
    if (!Array.isArray(checkoutItemsSnapshot) || !checkoutItemsSnapshot.length) {
      showToast("لا توجد منتجات في الطلب", "!");
      return;
    }

    const data = readCheckoutForm();
    const validation = validateCheckoutData(data);

    if (!validation.valid) {
      setCheckoutMessage(validation.message, "error");
      return;
    }

    const stockValid = checkoutItemsSnapshot.every(item => {
      const product = PRODUCTS.find(
        p => sameProductId(
          p.id,
          item.productId ?? item.id
        )
      );

      return (
        product &&
        product.active !== false &&
        Number(product.stock || 0) >=
          Number(item.quantity || 0)
      );
    });

    if (!stockValid) {
      setCheckoutMessage(
        "بعض المنتجات لم تعد متوفرة بالكمية المطلوبة. عد إلى السلة وعدّل الكميات.",
        "error"
      );
      return;
    }

    /*
      لا نعلن النجاح ولا نفرغ السلة إلا بعد saveOrder=true.
    */
    const saved = await saveOrder(data);

    if (!saved) {
      setCheckoutMessage(
        "حدث خطأ أثناء إرسال الطلب. لم يتم حذف السلة، ويمكنك المحاولة مرة أخرى.",
        "error"
      );
      return;
    }

    checkoutItemsSnapshot = [];
    checkoutTotalSnapshot = 0;
    updateBadges();
    renderCart();
    hideCheckoutForm();
    showCheckoutSuccess();

    showToast(
      "🎉 تم تأكيد طلبك بنجاح!",
      "✓"
    );

  } finally {
    confirmCheckoutOrder.processing = false;
    window.__MYSTORE_ORDER_SUBMISSION_LOCK = false;

    /*
      لا نعيد تفعيل الزر إذا انتقلنا إلى شاشة النجاح.
      إذا بقي المستخدم في شاشة الدفع بسبب خطأ، يمكنه المحاولة مجددًا.
    */
    const success = findElement(
      "checkoutSuccess",
      "orderSuccess",
      "orderSuccessMessage",
      "checkoutSuccessMessage"
    );

    if (confirmButton && (!success || success.style.display === "none")) {
      confirmButton.disabled = false;
      confirmButton.removeAttribute("aria-disabled");
    }
  }
}

/* =========================================
   CHECKOUT FORM EVENT
========================================= */

const checkoutForm =
  findElement(
    "checkoutForm",
    "orderForm"
  );


if (checkoutForm && !checkoutForm.dataset.mystoreOrderBound) {

  checkoutForm.dataset.mystoreOrderBound = "1";
  checkoutForm.addEventListener(
    "submit",
    async function(event) {

      event.preventDefault();

      event.stopPropagation();

      await confirmCheckoutOrder();

    }
  );

}


/* =========================================
   CHECKOUT CONFIRM BUTTON
========================================= */

/*
  بعض صفحات HTML يكون فيها زر التأكيد
  خارج الـform.

  لذلك نبحث عن عدة أسماء محتملة.
*/

const checkoutConfirmBtn =
  findElement(
    "confirmCheckoutBtn",
    "checkoutConfirmBtn",
    "confirmOrderBtn",
    "confirmOrder",
    "submitOrderBtn",
    "placeOrderBtn"
  );


if (checkoutConfirmBtn && !checkoutConfirmBtn.dataset.mystoreOrderBound) {

  checkoutConfirmBtn.dataset.mystoreOrderBound = "1";
  checkoutConfirmBtn.type =
    "button";


  checkoutConfirmBtn.addEventListener(
    "click",
    async function(event) {

      event.preventDefault();

      event.stopPropagation();

      await confirmCheckoutOrder();

    }
  );

}


/* =========================================
   CHECKOUT BUTTON
========================================= */

const checkoutBtn =
  document.getElementById(
    "checkoutBtn"
  );


if (checkoutBtn) {

  checkoutBtn.onclick =
    () => {

      openCheckout();

    };

}


/* =========================================
   CHECKOUT BACK BUTTON
========================================= */

const checkoutBackBtn =
  findElement(
    "checkoutBackBtn",
    "orderBackBtn",
    "backToCartFromCheckout"
  );


if (checkoutBackBtn) {

  checkoutBackBtn.onclick =
    () => {

      renderCart();

      showScreen("cart");

    };

}


/* =========================================
   BACK HOME AFTER SUCCESS
========================================= */

const checkoutHomeBtn =
  findElement(
    "checkoutHomeBtn",
    "orderHomeBtn",
    "backHomeFromCheckout",
    "successHomeBtn"
  );


if (checkoutHomeBtn) {

  checkoutHomeBtn.onclick =
    () => {

      checkoutItemsSnapshot = [];

      checkoutTotalSnapshot = 0;

      hideCheckoutSuccess();

      renderAccounts();

      showScreen("home");

    };

}


/* =========================================
   BADGES
========================================= */

function updateBadges() {

  const account =
    getCurrentAccount();


  if (!account) return;


  const favorites =
    Array.isArray(account.favorites)
      ? account.favorites.length
      : 0;


  const cart =
    Array.isArray(account.cart)
      ? account.cart.reduce(
          (
            total,
            item
          ) =>
            total +
            Number(item.quantity),
          0
        )
      : 0;


  const favoritesCount =
    document.getElementById(
      "favoritesCount"
    );

  const cartCount =
    document.getElementById(
      "cartCount"
    );

  const bottomCartCount =
    document.getElementById(
      "bottomCartCount"
    );


  if (favoritesCount) {

    favoritesCount.textContent =
      favorites;

  }


  if (cartCount) {

    cartCount.textContent =
      cart;

  }


  if (bottomCartCount) {

    bottomCartCount.textContent =
      cart;

  }

}


/* =========================================
   SEARCH
========================================= */

const productSearch =
  document.getElementById(
    "productSearch"
  );


if (productSearch) {

  productSearch.addEventListener(
    "input",
    function() {

      currentSearch =
        this.value;

      const clearButton =
        document.getElementById(
          "clearSearchBtn"
        );


      if (clearButton) {

        clearButton.classList.toggle(
          "show",
          this.value.length > 0
        );

      }


      renderProducts();

    }
  );

}


const clearSearchBtn =
  document.getElementById(
    "clearSearchBtn"
  );


if (clearSearchBtn) {

  clearSearchBtn.onclick =
    () => {

      const searchInput =
        document.getElementById(
          "productSearch"
        );


      if (searchInput) {

        searchInput.value =
          "";

      }


      currentSearch =
        "";


      clearSearchBtn.classList.remove(
        "show"
      );


      renderProducts();

    };

}


const resetFiltersBtn =
  document.getElementById(
    "resetFiltersBtn"
  );


if (resetFiltersBtn) {

  resetFiltersBtn.onclick =
    () => {

      currentCategory =
        "all";

      currentSearch =
        "";


      if (productSearch) {

        productSearch.value =
          "";

      }


      if (clearSearchBtn) {

        clearSearchBtn.classList.remove(
          "show"
        );

      }


      renderCategories();

      renderProducts();

    };

}


/* =========================================
   HEADER NAVIGATION
========================================= */

const favoritesHeaderBtn =
  document.getElementById(
    "favoritesHeaderBtn"
  );


if (favoritesHeaderBtn) {

  favoritesHeaderBtn.onclick =
    openFavorites;

}


const cartHeaderBtn =
  document.getElementById(
    "cartHeaderBtn"
  );


if (cartHeaderBtn) {

  cartHeaderBtn.onclick =
    openCart;

}


const profileHeaderBtn =
  document.getElementById(
    "profileHeaderBtn"
  );


if (profileHeaderBtn) {

  profileHeaderBtn.onclick =
    () => {

      updateAccountPage();

      updateBottomNavigation(
        "account"
      );

      showScreen("account");

    };

}


/* =========================================
   BOTTOM NAVIGATION
========================================= */

function updateBottomNavigation(
  activeNav
) {

  document
    .querySelectorAll(
      ".bottom-nav-item"
    )
    .forEach(
      item => {

        item.classList.toggle(
          "active",
          item.dataset.nav ===
            activeNav
        );

      }
    );

}


document
  .querySelectorAll(
    ".bottom-nav-item"
  )
  .forEach(
    button => {

      button.onclick =
        () => {

          const nav =
            button.dataset.nav;


          updateBottomNavigation(
            nav
          );


          if (nav === "store") {

            openStore();

          }


          if (nav === "favorites") {

            openFavorites();

          }


          if (nav === "cart") {

            openCart();

          }


          if (nav === "account") {

            updateAccountPage();

            showScreen("account");

          }

        };

    }
  );


/* =========================================
   ACCOUNT PAGE
========================================= */

function updateAccountPage() {

  const account =
    getCurrentAccount();


  if (!account) return;


  const name =
    document.getElementById(
      "profileName"
    );

  const email =
    document.getElementById(
      "profileEmail"
    );

  const avatar =
    document.getElementById(
      "profileAvatar"
    );


  if (name) {

    name.textContent =
      account.name;

  }


  if (email) {

    email.textContent =
      account.email;

  }


  if (avatar) {

    avatar.innerHTML =
      avatarHTML(account);

  }

}


const backToStoreFromAccount =
  document.getElementById(
    "backToStoreFromAccount"
  );


if (backToStoreFromAccount) {

  backToStoreFromAccount.onclick =
    openStore;

}


/* =========================================
   LOGOUT
========================================= */

const logoutBtn =
  document.getElementById(
    "logoutBtn"
  );


if (logoutBtn) {

  logoutBtn.onclick =
    async () => {

      // Keep the refresh session on this device so the saved account on the
      // home screen can be opened again without asking for the password.
      clearCurrentUser();

      selectedLoginAccountId =
        null;


      checkoutItemsSnapshot = [];

      checkoutTotalSnapshot = 0;


      showToast(
        "تم تسجيل الخروج",
        "✓"
      );


      setTimeout(
        () => {

          renderAccounts();

          showScreen("home");

        },
        350
      );

    };

}


/* =========================================
   ACCOUNT SETTINGS
========================================= */

const openProfileSettings =
  document.getElementById(
    "openProfileSettings"
  );


if (openProfileSettings) {

  openProfileSettings.onclick =
    openSettings;

}


const openSecuritySettings =
  document.getElementById(
    "openSecuritySettings"
  );


if (openSecuritySettings) {

  openSecuritySettings.onclick =
    openSettings;

}


function openSettings() {

  const account =
    getCurrentAccount();


  if (!account) return;


  const settingsName =
    document.getElementById(
      "settingsName"
    );

  const settingsEmail =
    document.getElementById(
      "settingsEmail"
    );

  const settingsAvatar =
    document.getElementById(
      "settingsAvatar"
    );


  if (settingsName) {

    settingsName.value =
      account.name;

  }


  if (settingsEmail) {

    settingsEmail.value =
      account.email;

  }


  if (settingsAvatar) {

    settingsAvatar.innerHTML =
      avatarHTML(account);

  }


  clearMessage(
    "profileSettingsMessage"
  );

  clearMessage(
    "passwordSettingsMessage"
  );


  showScreen("settings");

}


const settingsBackBtn =
  document.getElementById(
    "settingsBackBtn"
  );


if (settingsBackBtn) {

  settingsBackBtn.onclick =
    () => {

      updateAccountPage();

      showScreen("account");

    };

}


/* =========================================
   PROFILE SETTINGS
========================================= */

const profileSettingsForm =
  document.getElementById(
    "profileSettingsForm"
  );


if (profileSettingsForm) {

  profileSettingsForm.addEventListener(
    "submit",
    function(event) {

      event.preventDefault();


      const id =
        getCurrentUserId();


      const name =
        document
          .getElementById(
            "settingsName"
          )
          .value
          .trim();


      const email =
        document
          .getElementById(
            "settingsEmail"
          )
          .value
          .trim()
          .toLowerCase();


      if (name.length < 2) {

        setMessage(
          "profileSettingsMessage",
          "الاسم قصير جدًا.",
          "error"
        );

        return;

      }


      if (
        !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      ) {

        setMessage(
          "profileSettingsMessage",
          "البريد غير صحيح.",
          "error"
        );

        return;

      }


      const accounts =
        getAccounts();


      const duplicate =
        accounts.some(
          account =>
            account.id !== id &&
            account.email === email
        );


      if (duplicate) {

        setMessage(
          "profileSettingsMessage",
          "البريد مستخدم في حساب آخر.",
          "error"
        );

        return;

      }


      const account =
        accounts.find(
          item =>
            item.id === id
        );


      if (!account) return;


      const oldName =
        account.name;


      account.name =
        name;

      account.email =
        email;


      if (
        account.shippingAddress &&
        (
          !account.shippingAddress.fullName ||
          account.shippingAddress.fullName ===
            oldName
        )
      ) {

        account.shippingAddress.fullName =
          name;

      }


      saveAccounts(accounts);

      updateStoreUser();


      setMessage(
        "profileSettingsMessage",
        "تم حفظ المعلومات.",
        "success"
      );


      showToast(
        "تم تحديث الحساب",
        "✓"
      );

    }
  );

}


/* =========================================
   PASSWORD SETTINGS
========================================= */

const passwordSettingsForm =
  document.getElementById(
    "passwordSettingsForm"
  );


if (passwordSettingsForm) {

  passwordSettingsForm.addEventListener(
    "submit",
    async function(event) {

      event.preventDefault();


      const accounts =
        getAccounts();

      const account =
        getCurrentAccountFrom(accounts);


      if (!account) return;


      const current =
        document
          .getElementById(
            "currentPassword"
          )
          .value;


      const newPassword =
        document
          .getElementById(
            "newPassword"
          )
          .value;


      const confirm =
        document
          .getElementById(
            "confirmNewPassword"
          )
          .value;


      const currentHash =
        await hashPassword(current);


      if (
        currentHash !==
        account.passwordHash
      ) {

        setMessage(
          "passwordSettingsMessage",
          "كلمة المرور الحالية غير صحيحة.",
          "error"
        );

        return;

      }


      if (
        newPassword.length < 6
      ) {

        setMessage(
          "passwordSettingsMessage",
          "كلمة المرور الجديدة قصيرة.",
          "error"
        );

        return;

      }


      if (
        newPassword !==
        confirm
      ) {

        setMessage(
          "passwordSettingsMessage",
          "كلمتا المرور غير متطابقتين.",
          "error"
        );

        return;

      }


      account.passwordHash =
        await hashPassword(
          newPassword
        );


      saveAccounts(accounts);


      this.reset();


      setMessage(
        "passwordSettingsMessage",
        "تم تغيير كلمة المرور.",
        "success"
      );


      showToast(
        "تم تغيير كلمة المرور",
        "✓"
      );

    }
  );

}


/* =========================================
   AVATAR
========================================= */

const avatarInput =
  document.getElementById(
    "avatarInput"
  );


if (avatarInput) {

  avatarInput.addEventListener(
    "change",
    function() {

      const file =
        this.files[0];


      if (!file) return;


      if (
        !file.type.startsWith("image/")
      ) {

        showToast(
          "الملف ليس صورة",
          "!"
        );

        this.value =
          "";

        return;

      }


      if (
        file.size >
        2 * 1024 * 1024
      ) {

        showToast(
          "الصورة يجب ألا تتجاوز 2MB",
          "!"
        );

        this.value =
          "";

        return;

      }


      const reader =
        new FileReader();


      reader.onload =
        () => {

          const accounts =
            getAccounts();

          const id =
            getCurrentUserId();


          const account =
            accounts.find(
              item =>
                item.id === id
            );


          if (!account) return;


          account.avatar =
            reader.result;


          saveAccounts(accounts);

          updateStoreUser();


          const settingsAvatar =
            document.getElementById(
              "settingsAvatar"
            );


          if (settingsAvatar) {

            settingsAvatar.innerHTML =
              avatarHTML(account);

          }


          showToast(
            "تم تغيير الصورة",
            "✓"
          );

        };


      reader.readAsDataURL(file);

    }
  );

}


/* =========================================
   REMOVE AVATAR
========================================= */

const removeAvatarBtn =
  document.getElementById(
    "removeAvatarBtn"
  );


if (removeAvatarBtn) {

  removeAvatarBtn.onclick =
    () => {

      const accounts =
        getAccounts();

      const id =
        getCurrentUserId();


      const account =
        accounts.find(
          item =>
            item.id === id
        );


      if (!account) return;


      account.avatar =
        null;


      saveAccounts(accounts);

      updateStoreUser();


      const settingsAvatar =
        document.getElementById(
          "settingsAvatar"
        );


      if (settingsAvatar) {

        settingsAvatar.innerHTML =
          "👤";

      }


      showToast(
        "تم إزالة الصورة",
        "✓"
      );

    };

}



/* =========================================
   BACK BUTTONS
========================================= */

document.addEventListener("click", function(event) {
  const homeBack = event.target.closest("[data-back='home']");
  if (homeBack) {
    event.preventDefault();
    showScreen("home");
    return;
  }

  const successBack = event.target.closest("#successBackToStoreBtn, #checkoutSuccessAutoBackBtn");
  if (successBack) {
    event.preventDefault();
    checkoutItemsSnapshot = [];
    checkoutTotalSnapshot = 0;
    hideCheckoutSuccess();
    renderProducts();
    updateBadges();
    openStore();
  }
});


const favoritesBackBtn =
  document.getElementById(
    "favoritesBackBtn"
  );


if (favoritesBackBtn) {

  favoritesBackBtn.onclick =
    openStore;

}


const cartBackBtn =
  document.getElementById(
    "cartBackBtn"
  );


if (cartBackBtn) {

  cartBackBtn.onclick =
    openStore;

}


/* =========================================
   PASSWORD TOGGLES
========================================= */

document
  .querySelectorAll(
    ".password-toggle"
  )
  .forEach(
    button => {

      button.onclick =
        () => {

          const input =
            document.getElementById(
              button.dataset.target
            );


          if (!input) return;


          if (
            input.type ===
            "password"
          ) {

            input.type =
              "text";

            button.textContent =
              "🙈";

          } else {

            input.type =
              "password";

            button.textContent =
              "👁️";

          }

        };

    }
  );


/* =========================================
   MESSAGES
========================================= */

function setMessage(
  id,
  message,
  type
) {

  const element =
    document.getElementById(id);


  if (!element) return;


  element.textContent =
    message;


  element.className =
    `form-message ${type}`;

}


function clearMessage(id) {

  const element =
    document.getElementById(id);


  if (!element) return;


  element.textContent =
    "";

  element.className =
    "form-message";

}


/* =========================================
   TOAST
========================================= */

function showToast(
  message,
  icon = "✓"
) {

  const toast =
    document.getElementById(
      "toast"
    );

  const toastText =
    document.getElementById(
      "toastText"
    );

  const toastIcon =
    document.getElementById(
      "toastIcon"
    );


  if (!toast) return;


  if (toastText) {

    toastText.textContent =
      message;

  }


  if (toastIcon) {

    toastIcon.textContent =
      icon;

  }


  toast.classList.add("show");


  clearTimeout(toastTimer);


  toastTimer =
    setTimeout(
      () => {

        toast.classList.remove(
          "show"
        );

      },
      2500
    );

}


/* =========================================
   INITIALIZE
========================================= */

async function initialize() {

  // First handle a Supabase email-confirmation redirect.
  await handleSupabaseAuthCallback();

  const accounts =
    getAccounts();


  let changed =
    false;


  accounts.forEach(
    account => {

      if (
        !Array.isArray(
          account.orders
        )
      ) {

        account.orders = [];

        changed = true;

      }

      account.orders.forEach(order => {
        if (!order.status) { order.status = "new"; changed = true; }
      });


      if (
        !account.shippingAddress
      ) {

        account.shippingAddress = {

          fullName:
            account.name || "",

          phone: "",

          wilaya: "",

          commune: "",

          address: "",

          notes: ""

        };

        changed = true;

      }

    }
  );


  if (changed) {

    saveAccounts(accounts);

  }


  renderAccounts();


  const restoredSession = await restoreSupabaseSession();
  if (restoredSession?.user) {
    const restoredAccount = createLocalAccountFromSupabaseUser(restoredSession.user);
    if (restoredAccount) setCurrentUserId(restoredAccount.id);
    try {
      const restoredProfile = await c4GetOwnerProfile(restoredSession);
      const restoredRole = String(restoredProfile?.role || "").toLowerCase();
      if (restoredRole === "admin" || restoredRole === "store_owner") {
        sessionStorage.setItem("ownerSupabaseRole", restoredRole);
        sessionStorage.setItem("ownerSupabaseUserId", restoredSession.user.id);
        sessionStorage.setItem(ADMIN_SESSION_KEY, "1");
      }
    } catch (error) {
      console.warn("MyStore Luffy 4: restored owner role check failed", error);
    }
  }


  const account =
    getCurrentAccount();


  if (account) {

    getShippingAddress();

    if (isAdminLoggedIn() && sessionStorage.getItem("ownerSupabaseRole")) {
      await openAdminDashboard();
    } else {
      openStore();
    }

  } else {

    showScreen("home");

  }


  /*
    تجهيز خانات checkout إن كانت موجودة.
  */

  prepareCheckoutFields();

}


initialize().catch(error => console.warn("MyStore: initialization warning.", error));


/* =========================================
   ADMIN UI BOOTSTRAP
========================================= */
prepareAdminUI();
testSupabaseConnection();



/* =========================================
   2-C — SUPABASE CLOUD PRODUCTS READ
   MyStore Luffy 1
========================================= */

let SUPABASE_CLOUD_PRODUCTS_LOADED = false;
let SUPABASE_CATEGORY_UI_CACHE = [];

function sameProductId(a, b) {
  return String(a ?? "") === String(b ?? "");
}

function normalizeSupabaseProduct(product, categories = []) {
  if (!product || !product.id) return null;

  const category = categories.find(c => c.id === product.category_id);

  let images = [];
  if (Array.isArray(product.images)) {
    images = product.images.filter(Boolean).map(String);
  } else if (typeof product.images === "string") {
    try {
      const parsed = JSON.parse(product.images);
      if (Array.isArray(parsed)) images = parsed.filter(Boolean).map(String);
    } catch {}
  }

  if (!images.length && product.image) images = [String(product.image)];

  return {
    ...product,
    id: String(product.id),
    category_id: product.category_id ? String(product.category_id) : "",
    category: category?.name || product.category || "بدون تصنيف",
    images,
    image: product.image || images[0] || "",
    price: Number(product.price || 0),
    oldPrice: product.old_price == null ? null : Number(product.old_price),
    old_price: product.old_price == null ? null : Number(product.old_price),
    stock: Number(product.stock || 0),
    active: product.active !== false,
    featured: product.featured === true,
    salesCount: Math.max(0, Number(product.sales_count ?? 0))
  };
}

async function loadProductsFromSupabaseC2() {
  try {
    const headers = {
      apikey: SUPABASE_CONFIG.publishableKey,
      Accept: "application/json"
    };

    const [catResponse, productResponse] = await Promise.all([
      fetch(
        `${SUPABASE_CONFIG.url}/rest/v1/categories?select=id,name,active,icon&active=eq.true&order=name.asc`,
        { headers, cache: "no-store" }
      ),
      fetch(
        `${SUPABASE_CONFIG.url}/rest/v1/products?select=id,name,description,category_id,price,old_price,stock,active,featured,sales_count,image,images,icon,created_at&active=eq.true&order=created_at.desc`,
        { headers, cache: "no-store" }
      )
    ]);

    if (!catResponse.ok || !productResponse.ok) {
      throw new Error(
        `Supabase C-2 read failed: categories=${catResponse.status}, products=${productResponse.status}`
      );
    }

    const categories = await catResponse.json();
    const cloudProductsRaw = await productResponse.json();
    SUPABASE_CATEGORY_UI_CACHE = Array.isArray(categories) ? categories.map(c => ({ id: c.id, name: c.name, active: c.active !== false, icon: c.icon || "🏷️" })) : [];
    if (SUPABASE_C3_STARTED) {
      return { products: cloudProductsRaw.map(product => normalizeSupabaseProduct(product, categories)).filter(Boolean), categories };
    }

    const cloudProducts = cloudProductsRaw
      .map(product => normalizeSupabaseProduct(product, categories))
      .filter(Boolean);

    // Keep the application's existing PRODUCTS variable when it exists.
    if (Array.isArray(window.PRODUCTS)) {
      window.PRODUCTS.length = 0;
      window.PRODUCTS.push(...cloudProducts);
    }

    // Some builds use PRODUCTS as a lexical/global binding rather than window.PRODUCTS.
    try {
      if (typeof PRODUCTS !== "undefined" && Array.isArray(PRODUCTS)) {
        PRODUCTS.length = 0;
        PRODUCTS.push(...cloudProducts);
      }
    } catch {}

    SUPABASE_CLOUD_PRODUCTS_LOADED = true;

    console.info(
      `MyStore C-2: loaded ${cloudProducts.length} products and ${categories.length} categories from Supabase.`
    );

    // Refresh existing UI renderers if they exist.
    try {
      if (typeof renderCategories === "function") renderCategories();
    } catch (e) {
      console.warn("MyStore C-2: renderCategories refresh failed.", e);
    }

    try {
      if (typeof renderProducts === "function") renderProducts();
    } catch (e) {
      console.warn("MyStore C-2: renderProducts refresh failed.", e);
    }

    return { products: cloudProducts, categories };
  } catch (error) {
    SUPABASE_CLOUD_PRODUCTS_LOADED = false;
    console.warn("MyStore C-2: cloud products unavailable; keeping local data.", error);
    return null;
  }
}

function startSupabaseProductsC2() {
  // Run after the current script/UI has initialized so we don't disturb Phase 1.
  Promise.resolve().then(() => loadProductsFromSupabaseC2());
}



/* C-2 startup hook */
document.addEventListener("DOMContentLoaded", function () {
  startSupabaseProductsC2();
});

/* =========================================
   3-C — SUPABASE CLOUD ADMIN PRODUCTS
   MyStore Luffy 2
   Product add / edit / delete / hide / featured
========================================= */

let SUPABASE_C3_CATEGORY_CACHE = null;
let SUPABASE_C3_STARTED = false;

function c3AccessToken() {
  return getSupabaseSession()?.access_token || "";
}

async function c3GetProfile() {
  const token = c3AccessToken();
  if (!token) return null;
  try {
    const r = await fetch(`${SUPABASE_CONFIG.url}/rest/v1/profiles?select=id,role&id=eq.${encodeURIComponent(getSupabaseSession()?.user?.id || "")}&limit=1`, {
      headers: supabaseHeaders(token), cache: "no-store"
    });
    if (!r.ok) return null;
    const rows = await r.json();
    return rows[0] || null;
  } catch { return null; }
}

async function c3RequireOwner() {
  const token = c3AccessToken();
  if (!token) throw new Error("يجب تسجيل الدخول بحساب صاحب المتجر عبر Supabase قبل إدارة المنتجات سحابيًا.");
  const profile = await c3GetProfile();
  if (!profile || !["admin", "store_owner"].includes(String(profile.role || "").toLowerCase())) {
    throw new Error("هذا الحساب ليس لديه صلاحية إدارة منتجات المتجر.");
  }
  return token;
}

async function c3Request(path, method = "GET", body = undefined, token = "") {
  // Prevent a WebView/CodePen network request from hanging forever and
  // leaving checkout permanently waiting with no success/error message.
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  let response;
  try {
    response = await fetch(`${SUPABASE_CONFIG.url}/rest/v1/${path}`, {
      method,
      headers: { ...supabaseHeaders(token), ...(method === "POST" || method === "PATCH" || method === "PUT" ? { Prefer: "return=representation" } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
      cache: "no-store",
      signal: controller.signal
    });
  } catch (error) {
    if (error?.name === "AbortError") {
      throw new Error(`انتهت مهلة الاتصال بـ Supabase أثناء ${method} ${path}`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
  const text = await response.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!response.ok) {
    const detail = typeof data === "string" ? data : (data?.message || data?.hint || data?.details || data?.error || "");
    throw new Error(`Supabase ${method} failed (${response.status})${detail ? `: ${detail}` : ""}`);
  }
  return data;
}

async function c3LoadCategories() {
  if (Array.isArray(SUPABASE_C3_CATEGORY_CACHE)) return SUPABASE_C3_CATEGORY_CACHE;
  try {
    const rows = await c3Request("categories?select=id,name,active,icon&order=name.asc", "GET", undefined, c3AccessToken());
    SUPABASE_C3_CATEGORY_CACHE = Array.isArray(rows) ? rows : [];
  } catch (error) {
    // Backward compatibility until the one-time category-icon SQL migration is run.
    const rows = await c3Request("categories?select=id,name,active&order=name.asc", "GET", undefined, c3AccessToken());
    SUPABASE_C3_CATEGORY_CACHE = (Array.isArray(rows) ? rows : []).map(c => ({ ...c, icon: "🏷️" }));
  }
  SUPABASE_CATEGORY_UI_CACHE = SUPABASE_C3_CATEGORY_CACHE;
  return SUPABASE_C3_CATEGORY_CACHE;
}

function c3FindCategoryId(categoryName, categories) {
  const target = String(categoryName || "").trim().toLowerCase();
  const found = categories.find(c => String(c.name || "").trim().toLowerCase() === target && c.active !== false);
  return found?.id || null;
}

function c3ProductPayload(data, categoryId) {
  return {
    name: data.name,
    description: data.description,
    category_id: categoryId,
    price: Number(data.price),
    old_price: data.oldPrice == null ? null : Number(data.oldPrice),
    stock: Math.max(0, Number(data.stock || 0)),
    image: data.image || "",
    images: Array.isArray(data.images) ? data.images.slice(0, 5) : [],
    icon: data.icon || "📦",
    active: data.active !== false,
    featured: data.featured === true,
    updated_at: new Date().toISOString()
  };
}

function c3ApplyProducts(rows) {
  const categories = Array.isArray(SUPABASE_C3_CATEGORY_CACHE) ? SUPABASE_C3_CATEGORY_CACHE : [];
  SUPABASE_CATEGORY_UI_CACHE = categories;
  const mapped = (Array.isArray(rows) ? rows : []).map(p => normalizeSupabaseProduct(p, categories)).filter(Boolean);
  PRODUCTS = mapped;
  try {
    if (Array.isArray(window.PRODUCTS)) {
      window.PRODUCTS.length = 0;
      window.PRODUCTS.push(...mapped);
    }
  } catch {}
}

async function c3ReloadProducts() {
  const categories = await c3LoadCategories();
  const rows = await c3Request("products?select=*&order=created_at.desc", "GET", undefined, c3AccessToken());
  c3ApplyProducts(rows);
  try { renderCategories(); } catch {}
  try { renderProducts(); } catch {}
  try { renderAdminDashboard(); } catch {}
  return rows;
}

async function c3RenderCategoriesAdmin() {
  const list = document.getElementById("adminCategoriesList");
  if (!list) return;
  try {
    const categories = await c3LoadCategories();
    if (!categories.length) {
      list.innerHTML = `<div class="admin-empty">لا توجد تصنيفات بعد. يمكنك إضافة أول تصنيف من الأعلى.</div>`;
      return;
    }
    list.innerHTML = categories.map(category => `
      <div class="admin-category-item">
        <div><span class="admin-category-icon">${escapeHTML(category.icon || "🏷️")}</span><strong>${escapeHTML(category.name)}</strong></div>
        <button class="admin-mini-btn danger" type="button" data-admin-delete-category="${escapeHTML(category.id)}">حذف</button>
      </div>
    `).join("");
    list.querySelectorAll("[data-admin-delete-category]").forEach(button => {
      button.addEventListener("click", () => c3DeleteCategory(button.dataset.adminDeleteCategory));
    });
  } catch (error) {
    list.innerHTML = `<div class="admin-empty">تعذر تحميل التصنيفات.</div>`;
  }
}

async function c3AddCategory() {
  const input = document.getElementById("adminNewCategoryName");
  const name = String(input?.value || "").trim();
  const icon = String(document.getElementById("adminNewCategoryIcon")?.value || "🏷️").trim() || "🏷️";
  if (!name) {
    setMessage("adminCategoryMessage", "اكتب اسم التصنيف أولًا.", "error");
    return;
  }
  try {
    const token = await c3RequireOwner();
    const categories = await c3LoadCategories();
    const existing = c3FindCategoryId(name, categories);
    if (existing) {
      setMessage("adminCategoryMessage", "هذا التصنيف موجود بالفعل.", "error");
      return;
    }
    await c3Request("categories", "POST", { name, icon, active: true }, token);
    SUPABASE_C3_CATEGORY_CACHE = null;
    if (input) input.value = "";
    setMessage("adminCategoryMessage", "تمت إضافة التصنيف بنجاح.", "success");
    await c3RenderCategoriesAdmin();
    await c3ReloadProducts();
    showToast("تمت إضافة التصنيف", "✓");
  } catch (error) {
    setMessage("adminCategoryMessage", error.message || "تعذر إضافة التصنيف.", "error");
  }
}

async function c3DeleteCategory(categoryId) {
  const categories = await c3LoadCategories();
  const category = categories.find(item => String(item.id) === String(categoryId));
  if (!category) return;
  if (!confirm(`هل تريد حذف التصنيف «${category.name}»؟ المنتجات المرتبطة به ستبقى بدون تصنيف.`)) return;
  try {
    const token = await c3RequireOwner();
    await c3Request(`categories?id=eq.${encodeURIComponent(categoryId)}`, "DELETE", undefined, token);
    SUPABASE_C3_CATEGORY_CACHE = null;
    await c3RenderCategoriesAdmin();
    await c3ReloadProducts();
    showToast("تم حذف التصنيف", "✓");
  } catch (error) {
    showToast(error.message || "تعذر حذف التصنيف", "!");
  }
}

async function c3SaveAdminProduct(event) {
  event.preventDefault();
  const idValue = document.getElementById("adminProductId")?.value.trim();
  const name = document.getElementById("adminProductName")?.value.trim() || "";
  const category = document.getElementById("adminProductCategory")?.value.trim() || "";
  const priceRaw = document.getElementById("adminProductPrice")?.value ?? "";
  const price = priceRaw === "" ? 0 : Number(priceRaw);
  const oldPriceRaw = document.getElementById("adminProductOldPrice")?.value ?? "";
  const stockRaw = document.getElementById("adminProductStock")?.value ?? "";
  const stock = stockRaw === "" ? 0 : Math.max(0, Number(stockRaw));
  const icon = document.getElementById("adminProductIcon")?.value.trim() || "📦";
  const urlImage = document.getElementById("adminProductImage")?.value.trim() || "";
  if (urlImage && !adminSelectedProductImages.includes(urlImage)) {
    adminSelectedProductImages = [urlImage, ...adminSelectedProductImages].slice(0, 5);
  }
  const images = adminSelectedProductImages.slice(0, 5);
  const image = images[0] || urlImage || "";
  const description = document.getElementById("adminProductDescription")?.value.trim() || "";
  const active = document.getElementById("adminProductActive")?.checked === true;
  const featured = document.getElementById("adminProductFeatured")?.checked === true;

  if (!name || !Number.isFinite(price) || price < 0 || !Number.isFinite(stock) || stock < 0) {
    setMessage("adminProductMessage", "اسم المنتج مطلوب، أما باقي الخانات فيمكن تركها فارغة.", "error");
    return;
  }

  try {
    const token = await c3RequireOwner();
    let categories = await c3LoadCategories();
    let categoryId = c3FindCategoryId(category, categories);

    // التصنيف اختياري. وإذا كتب صاحب المتجر تصنيفًا غير موجود، ننشئه تلقائيًا بدل رفض المنتج.
    if (category && !categoryId) {
      const createdRows = await c3Request("categories", "POST", { name: category, active: true }, token);
      const createdCategory = Array.isArray(createdRows) ? createdRows[0] : null;
      if (!createdCategory?.id) throw new Error("تعذر إنشاء التصنيف الجديد في Supabase.");
      SUPABASE_C3_CATEGORY_CACHE = null;
      categories = await c3LoadCategories();
      categoryId = createdCategory.id;
    }

    const data = {
      name, category, price,
      oldPrice: oldPriceRaw === "" ? null : Math.max(0, Number(oldPriceRaw)),
      stock, icon, image, images, description, active, featured
    };
    const payload = c3ProductPayload(data, categoryId);

    if (idValue) {
      await c3Request(`products?id=eq.${encodeURIComponent(idValue)}`, "PATCH", payload, token);
    } else {
      delete payload.updated_at;
      const savedRows = await c3Request("products", "POST", payload, token);
      if (!Array.isArray(savedRows) || !savedRows[0]?.id) {
        throw new Error("لم تُرجع Supabase المنتج بعد الحفظ؛ لم نعتبر العملية ناجحة.");
      }
    }

    await c3ReloadProducts();
    closeAdminProductModal();
    showToast(idValue ? "تم تعديل المنتج سحابيًا" : "تمت إضافة المنتج سحابيًا", "✓");
  } catch (error) {
    console.error("MyStore C-3 save error", error);
    setMessage("adminProductMessage", error.message || "تعذر حفظ المنتج في Supabase.", "error");
  }
}

async function c3DeleteAdminProduct(productId) {
  const product = PRODUCTS.find(item => String(item.id) === String(productId));
  if (!product) return;
  if (!confirm(`هل تريد حذف المنتج «${product.name}» نهائيًا من Supabase؟`)) return;
  try {
    const token = await c3RequireOwner();
    await c3Request(`products?id=eq.${encodeURIComponent(productId)}`, "DELETE", undefined, token);
    await c3ReloadProducts();
    showToast("تم حذف المنتج من Supabase", "✓");
  } catch (error) {
    console.error("MyStore C-3 delete error", error);
    showToast(error.message || "تعذر حذف المنتج", "!");
  }
}

async function c3ToggleAdminProduct(productId) {
  const product = PRODUCTS.find(item => String(item.id) === String(productId));
  if (!product) return;
  try {
    const token = await c3RequireOwner();
    await c3Request(`products?id=eq.${encodeURIComponent(productId)}`, "PATCH", {
      active: product.active === false,
      updated_at: new Date().toISOString()
    }, token);
    await c3ReloadProducts();
    showToast(product.active === false ? "تم إظهار المنتج" : "تم إخفاء المنتج", "✓");
  } catch (error) {
    console.error("MyStore C-3 toggle error", error);
    showToast(error.message || "تعذر تغيير حالة المنتج", "!");
  }
}

// Featured is saved together with the product edit form. This helper is kept
// explicit for future UI buttons without changing the Phase-1 interface.
async function c3SetFeaturedProduct(productId, featured) {
  try {
    const token = await c3RequireOwner();
    await c3Request(`products?id=eq.${encodeURIComponent(productId)}`, "PATCH", {
      featured: !!featured,
      updated_at: new Date().toISOString()
    }, token);
    await c3ReloadProducts();
  } catch (error) {
    showToast(error.message || "تعذر تحديث المنتج المميز", "!");
  }
}

// Replace only the product-management actions with the C-3 cloud versions.
saveAdminProduct = c3SaveAdminProduct;
deleteAdminProduct = c3DeleteAdminProduct;
toggleAdminProduct = c3ToggleAdminProduct;

// Keep the existing dashboard/list UI but make its data cloud-first.
async function startSupabaseProductsC3() {
  SUPABASE_C3_STARTED = true;
  try {
    await c3ReloadProducts();
    await c3RenderCategoriesAdmin();
    console.info("MyStore C-3: cloud product management layer ready.");
  } catch (error) {
    console.warn("MyStore C-3: initial cloud refresh failed; C-2 data remains active.", error);
  }
}

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("adminAddCategoryBtn")?.addEventListener("click", c3AddCategory);
  document.getElementById("adminNewCategoryName")?.addEventListener("keydown", event => {
    if (event.key === "Enter") { event.preventDefault(); c3AddCategory(); }
  });
  startSupabaseProductsC3();
});

/* Luffy 7 product gallery fix */
document.addEventListener("click", function (ev) {
  const img = ev.target.closest?.("img[data-product-id], .product-card img, .product-image img");
  if (!img) return;

  const holder = img.closest("[data-product-id], .product-card, .product-item");
  const id = img.getAttribute("data-product-id") || holder?.getAttribute("data-product-id");
  if (!id) return;

  const products = (typeof PRODUCTS !== "undefined" && Array.isArray(PRODUCTS)) ? PRODUCTS : [];
  const product = products.find(p => String(p.id) === String(id));
  if (!product) return;

  const images = Array.isArray(product.images) ? product.images.filter(Boolean) :
                 (product.image ? [product.image] : []);
  if (images.length < 2) return;

  ev.preventDefault();
  ev.stopPropagation();

  for (const name of ["openProductGallery","showProductGallery","openGallery","viewProductImages"]) {
    if (typeof window[name] === "function") {
      window[name](product);
      return;
    }
  }
});



/* Luffy 8 — product image/gallery fix */
document.addEventListener("click", function(event) {
  const card = event.target.closest?.(".product-card");
  if (!card) return;

  // Buttons inside the card have their own handlers.
  if (event.target.closest("[data-cart], [data-favorite]")) return;

  const productId = card.dataset.product;
  if (!productId) return;

  const product = Array.isArray(PRODUCTS)
    ? PRODUCTS.find(p => sameProductId(p.id, productId))
    : null;

  if (!product) return;

  openProductDetails(product.id);
});


/* =========================================
   Luffy 9 — LIVE CLOUD SYNCHRONIZATION
   Customer-facing products/categories are re-fetched from Supabase.
   This intentionally does not overwrite the owner dashboard's full product list.
========================================= */
let luffy9SyncBusy = false;
let luffy9LastSignature = "";

function luffy9ResetCustomerViewState() {
  currentSearch = "";
  currentCategory = "all";
  const input = document.getElementById("productSearch");
  if (input) input.value = "";
  const clear = document.getElementById("clearSearchBtn");
  if (clear) clear.classList.remove("show");
}

function luffy9IsCustomerStoreVisible() {
  const store = document.getElementById("storeScreen");
  const account = getCurrentAccount?.();
  if (!store || !account) return false;
  return store.classList.contains("active") && account.role !== "admin";
}

let luffy9LastCloudFetchAt = 0;
const LUFFY9_CLOUD_REFRESH_COOLDOWN_MS = 30000;

async function luffy9RefreshCustomerCloud(forceRender = false) {
  if (luffy9SyncBusy || !luffy9IsCustomerStoreVisible()) return;
  const now = Date.now();
  if (!forceRender && now - luffy9LastCloudFetchAt < LUFFY9_CLOUD_REFRESH_COOLDOWN_MS) return;
  luffy9LastCloudFetchAt = now;
  luffy9SyncBusy = true;
  try {
    const result = await loadProductsFromSupabaseC2();
    if (!result) return;

    const products = Array.isArray(result.products) ? result.products : [];
    const categories = Array.isArray(result.categories) ? result.categories : [];
    const signature = JSON.stringify({
      p: products.map(p => [p.id,p.name,p.price,p.oldPrice,p.stock,p.active,p.featured,p.category,(p.images||[]).join("|")]),
      c: categories.map(c => [c.id,c.name,c.active,c.icon])
    });

    if (forceRender || signature !== luffy9LastSignature) {
      luffy9LastSignature = signature;
      renderCategories();
      renderProducts();
      updateBadges();
    }
  } catch (e) {
    console.warn("MyStore Luffy 9 cloud refresh failed", e);
  } finally {
    luffy9SyncBusy = false;
  }
}

// Egress protection: do not refresh on every focus/visibility event
// and do not poll continuously. Data is refreshed when the app starts
// and when the customer explicitly opens the store.

// Clear stale search/filter state when a new customer session opens the store.
const luffy9OriginalOpenStore = openStore;
openStore = function() {
  luffy9ResetCustomerViewState();
  const result = luffy9OriginalOpenStore.apply(this, arguments);
  setTimeout(() => luffy9RefreshCustomerCloud(false), 0);
  return result;
};

// Also clear the old search state on logout, before returning to the home screen.
const luffy9LogoutButton = document.getElementById("logoutBtn");
if (luffy9LogoutButton) {
  luffy9LogoutButton.addEventListener("click", () => {
    luffy9ResetCustomerViewState();
    luffy9LastSignature = "";
  }, true);
}

// When the email login succeeds, reset stale store state before the delayed navigation.
if (typeof loginForm !== "undefined" && loginForm) {
  loginForm.addEventListener("submit", () => {
    luffy9ResetCustomerViewState();
    luffy9LastSignature = "";
  }, true);
}




/* =========================================================
   MyStore — Egress protection
   The previous Luffy 11 polling system was removed.
   It repeatedly downloaded the complete products/categories
   datasets every 2.5 seconds and duplicated Luffy 9 requests.
   Customer data is now loaded on initial app startup and when
   the store is explicitly opened, instead of continuous polling.
   ========================================================= */

/* Luffy 30 - Complete UI language system
   Arabic/French/English. Translates interface labels only; customer/product/order data is preserved. */
(function(){
  const KEY='mystore_language';
  const LANGS=['ar','fr','en'];
  const T={
    ar:{
      'متجرك الإلكتروني في مكان واحد':'متجرك الإلكتروني في مكان واحد','حساباتك':'حساباتك','اختر حسابًا لتسجيل الدخول':'اختر حسابًا لتسجيل الدخول','لا توجد حسابات بعد':'لا توجد حسابات بعد','أنشئ حسابك الأول للبدء':'أنشئ حسابك الأول للبدء','إنشاء حساب جديد':'إنشاء حساب جديد','تسجيل الدخول بالبريد الإلكتروني':'تسجيل الدخول بالبريد الإلكتروني','دخول صاحب المتجر':'دخول صاحب المتجر','نظام الحسابات':'نظام الحسابات','العودة':'العودة','إنشاء حساب':'إنشاء حساب','أنشئ حسابك للبدء في استخدام المتجر':'أنشئ حسابك للبدء في استخدام المتجر','اسم المستخدم':'اسم المستخدم','البريد الإلكتروني':'البريد الإلكتروني','كلمة المرور':'كلمة المرور','تأكيد كلمة المرور':'تأكيد كلمة المرور','إنشاء الحساب':'إنشاء الحساب','تسجيل الدخول':'تسجيل الدخول','أدخل كلمة المرور للمتابعة':'أدخل كلمة المرور للمتابعة','الحسابات':'الحسابات','نسيت كلمة المرور؟':'نسيت كلمة المرور؟','تسجيل الخروج':'تسجيل الخروج','الرئيسية':'الرئيسية','حسابي':'حسابي','السلة':'السلة','الطلبات':'الطلبات','الإعدادات':'الإعدادات','المنتجات':'المنتجات','المفضلة':'المفضلة','البحث':'البحث','بحث':'بحث','اكتشف منتجاتنا':'اكتشف منتجاتنا','اكتشف منتجات رائعة بأسعار مميزة':'اكتشف منتجات رائعة بأسعار مميزة','تصفح المنتجات':'تصفح المنتجات','تصفح حسب القسم':'تصفح حسب القسم','الكل':'الكل','الأكثر مبيعًا':'الأكثر مبيعًا','لا توجد منتجات':'لا توجد منتجات','لم نجد منتجات':'لم نجد منتجات','جرب كلمة بحث أو قسمًا آخر':'جرب كلمة بحث أو قسمًا آخر','إضافة إلى السلة':'إضافة إلى السلة','إضافة للسلة':'إضافة للسلة','إضافة للمفضلة':'إضافة للمفضلة','إزالة من المفضلة':'إزالة من المفضلة','إتمام الطلب':'إتمام الطلب','تأكيد الطلب':'تأكيد الطلب','تأكيد الطلبية':'تأكيد الطلبية','جاهز لتأكيد الطلب؟':'جاهز لتأكيد الطلب؟','معلومات الشاري':'معلومات الشاري','المعلومات المطلوبة لتوصيل الطلب':'المعلومات المطلوبة لتوصيل الطلب','الاسم واللقب':'الاسم واللقب','رقم الهاتف':'رقم الهاتف','الولاية':'الولاية','البلدية':'البلدية','العنوان بالتفصيل':'العنوان بالتفصيل','ملاحظات إضافية':'ملاحظات إضافية','الملاحظات':'الملاحظات','الشحن':'الشحن','الإجمالي':'الإجمالي','المجموع':'المجموع','المجموع النهائي':'المجموع النهائي','التكلفة الإجمالية':'التكلفة الإجمالية','الكمية':'الكمية','تفاصيل الطلب':'تفاصيل الطلب','متابعة الطلب':'متابعة الطلب','العودة إلى المتجر':'العودة إلى المتجر','العودة للسلة':'العودة للسلة','تم إرسال الطلبية بنجاح 🎉':'تم إرسال الطلبية بنجاح 🎉','شكرًا لك! تم استلام طلبك بنجاح.':'شكرًا لك! تم استلام طلبك بنجاح.','تحديث':'تحديث','حفظ':'حفظ','حفظ المعلومات':'حفظ المعلومات','إلغاء':'إلغاء','تعديل':'تعديل','حذف':'حذف','الملف الشخصي':'الملف الشخصي','المعلومات الشخصية':'المعلومات الشخصية','تعديل معلومات الحساب':'تعديل معلومات الحساب','عدّل معلومات حسابك':'عدّل معلومات حسابك','تغيير الصورة':'تغيير الصورة','صورة الحساب':'صورة الحساب','الأمان':'الأمان','الأمان وكلمة المرور':'الأمان وكلمة المرور','تغيير كلمة المرور':'تغيير كلمة المرور','كلمة المرور الحالية':'كلمة المرور الحالية','كلمة المرور الجديدة':'كلمة المرور الجديدة','حذف الحساب؟':'حذف الحساب؟','حذف الحساب نهائيًا':'حذف الحساب نهائيًا','هل أنت متأكد أنك تريد حذف هذا الحساب؟':'هل أنت متأكد أنك تريد حذف هذا الحساب؟','نعم، احذف الحساب':'نعم، احذف الحساب','تبديل الحساب':'تبديل الحساب','اللغة':'اللغة','العربية':'العربية','الفرنسية':'الفرنسية','الإنجليزية':'الإنجليزية','لوحة التحكم':'لوحة التحكم','لوحة إدارة المتجر':'لوحة إدارة المتجر','لوحة صاحب المتجر':'لوحة صاحب المتجر','إدارة المنتجات':'إدارة المنتجات','إدارة الطلبات':'إدارة الطلبات','إدارة التصنيفات':'إدارة التصنيفات','إضافة منتج':'إضافة منتج','إضافة التصنيف':'إضافة التصنيف','إدارة منتجاتك وطلبات الزبائن من مكان واحد':'إدارة منتجاتك وطلبات الزبائن من مكان واحد','أضف منتجاتك وعدّل السعر والمخزون والحالة.':'أضف منتجاتك وعدّل السعر والمخزون والحالة.','تابع الطلبات وغيّر حالتها.':'تابع الطلبات وغيّر حالتها.','كل المنتجات':'كل المنتجات','الظاهرة':'الظاهرة','المخفية':'المخفية','نفد المخزون':'نفد المخزون','كل الحالات':'كل الحالات','جديد':'جديد','مؤكد':'مؤكد','قيد التجهيز':'قيد التجهيز','تم الشحن':'تم الشحن','تم التسليم':'تم التسليم','ملغى':'ملغى','اسم المنتج':'اسم المنتج','التصنيف':'التصنيف','السعر (دج)':'السعر (دج)','السعر القديم (اختياري)':'السعر القديم (اختياري)','المخزون':'المخزون','الأيقونة':'الأيقونة','صور المنتج (حتى 5 صور)':'صور المنتج (حتى 5 صور)','رابط الصورة الأولى (اختياري)':'رابط الصورة الأولى (اختياري)','حذف كل الصور':'حذف كل الصور','الوصف والتفاصيل':'الوصف والتفاصيل','المنتج ظاهر للزبائن':'المنتج ظاهر للزبائن','ضمن المنتجات الأكثر مبيعًا':'ضمن المنتجات الأكثر مبيعًا','حفظ المنتج':'حفظ المنتج','إزالة الصورة':'إزالة الصورة','عدد المنتجات':'عدد المنتجات','إجمالي الطلبات':'إجمالي الطلبات','طلبات جديدة':'طلبات جديدة','منطقة الخطر':'منطقة الخطر','المتجر':'المتجر','حسابك':'حسابك','الاسم':'الاسم','اللقب':'اللقب','المستخدم':'المستخدم','العنوان':'العنوان','المخزون':'المخزون','صور':'صور','عرض':'عرض','نفد':'نفد','ظاهر':'ظاهر','مخفي':'مخفي','الطلب':'الطلب','الطلبية':'الطلبية','الحالة':'الحالة','الزبون':'الزبون','التاريخ':'التاريخ','الإجراءات':'الإجراءات','بدون تصنيف':'بدون تصنيف','في MyStore':'في MyStore','مرحبًا بك 👋':'مرحبًا بك 👋'
    },
    fr:{
      'متجرك الإلكتروني في مكان واحد':'Votre boutique en ligne au même endroit','حساباتك':'Vos comptes','اختر حسابًا لتسجيل الدخول':'Choisissez un compte pour vous connecter','لا توجد حسابات بعد':'Aucun compte pour le moment','أنشئ حسابك الأول للبدء':'Créez votre premier compte pour commencer','إنشاء حساب جديد':'Créer un nouveau compte','تسجيل الدخول بالبريد الإلكتروني':'Connexion avec e-mail','دخول صاحب المتجر':'Accès propriétaire','نظام الحسابات':'Système de comptes','العودة':'Retour','إنشاء حساب':'Créer un compte','أنشئ حسابك للبدء في استخدام المتجر':'Créez votre compte pour commencer à utiliser la boutique','اسم المستخدم':'Nom d’utilisateur','البريد الإلكتروني':'Adresse e-mail','كلمة المرور':'Mot de passe','تأكيد كلمة المرور':'Confirmer le mot de passe','إنشاء الحساب':'Créer le compte','تسجيل الدخول':'Connexion','أدخل كلمة المرور للمتابعة':'Entrez votre mot de passe pour continuer','الحسابات':'Comptes','نسيت كلمة المرور؟':'Mot de passe oublié ?','تسجيل الخروج':'Déconnexion','الرئيسية':'Accueil','حسابي':'Mon compte','السلة':'Panier','الطلبات':'Commandes','الإعدادات':'Paramètres','المنتجات':'Produits','المفضلة':'Favoris','البحث':'Recherche','بحث':'Rechercher','اكتشف منتجاتنا':'Découvrez nos produits','اكتشف منتجات رائعة بأسعار مميزة':'Découvrez de superbes produits à des prix attractifs','تصفح المنتجات':'Parcourir les produits','تصفح حسب القسم':'Parcourir par catégorie','الكل':'Tous','الأكثر مبيعًا':'Meilleures ventes','لا توجد منتجات':'Aucun produit','لم نجد منتجات':'Aucun produit trouvé','جرب كلمة بحث أو قسمًا آخر':'Essayez un autre mot-clé ou une autre catégorie','إضافة إلى السلة':'Ajouter au panier','إضافة للسلة':'Ajouter au panier','إضافة للمفضلة':'Ajouter aux favoris','إزالة من المفضلة':'Retirer des favoris','إتمام الطلب':'Passer la commande','تأكيد الطلب':'Confirmer la commande','تأكيد الطلبية':'Confirmer la commande','جاهز لتأكيد الطلب؟':'Prêt à confirmer la commande ?','معلومات الشاري':'Informations de l’acheteur','المعلومات المطلوبة لتوصيل الطلب':'Informations nécessaires à la livraison','الاسم واللقب':'Nom et prénom','رقم الهاتف':'Numéro de téléphone','الولاية':'Wilaya','البلدية':'Commune','العنوان بالتفصيل':'Adresse détaillée','ملاحظات إضافية':'Remarques supplémentaires','الملاحظات':'Remarques','الشحن':'Livraison','الإجمالي':'Total','المجموع':'Sous-total','المجموع النهائي':'Total final','التكلفة الإجمالية':'Coût total','الكمية':'Quantité','تفاصيل الطلب':'Détails de la commande','متابعة الطلب':'Suivre la commande','العودة إلى المتجر':'Retour à la boutique','العودة للسلة':'Retour au panier','تم إرسال الطلبية بنجاح 🎉':'Commande envoyée avec succès 🎉','شكرًا لك! تم استلام طلبك بنجاح.':'Merci ! Votre commande a bien été reçue.','تحديث':'Actualiser','حفظ':'Enregistrer','حفظ المعلومات':'Enregistrer les informations','إلغاء':'Annuler','تعديل':'Modifier','حذف':'Supprimer','الملف الشخصي':'Profil','المعلومات الشخصية':'Informations personnelles','تعديل معلومات الحساب':'Modifier les informations du compte','عدّل معلومات حسابك':'Modifiez les informations de votre compte','تغيير الصورة':'Changer la photo','صورة الحساب':'Photo de profil','الأمان':'Sécurité','الأمان وكلمة المرور':'Sécurité et mot de passe','تغيير كلمة المرور':'Changer le mot de passe','كلمة المرور الحالية':'Mot de passe actuel','كلمة المرور الجديدة':'Nouveau mot de passe','حذف الحساب؟':'Supprimer le compte ?','حذف الحساب نهائيًا':'Supprimer définitivement le compte','هل أنت متأكد أنك تريد حذف هذا الحساب؟':'Voulez-vous vraiment supprimer ce compte ?','نعم، احذف الحساب':'Oui, supprimer le compte','تبديل الحساب':'Changer de compte','اللغة':'Langue','العربية':'Arabe','الفرنسية':'Français','الإنجليزية':'Anglais','لوحة التحكم':'Tableau de bord','لوحة إدارة المتجر':'Administration de la boutique','لوحة صاحب المتجر':'Espace propriétaire','إدارة المنتجات':'Gestion des produits','إدارة الطلبات':'Gestion des commandes','إدارة التصنيفات':'Gestion des catégories','إضافة منتج':'Ajouter un produit','إضافة التصنيف':'Ajouter une catégorie','إدارة منتجاتك وطلبات الزبائن من مكان واحد':'Gérez vos produits et commandes au même endroit','أضف منتجاتك وعدّل السعر والمخزون والحالة.':'Ajoutez vos produits et modifiez le prix, le stock et le statut.','تابع الطلبات وغيّر حالتها.':'Suivez les commandes et modifiez leur statut.','كل المنتجات':'Tous les produits','الظاهرة':'Visibles','المخفية':'Masqués','نفد المخزون':'Rupture de stock','كل الحالات':'Tous les statuts','جديد':'Nouveau','مؤكد':'Confirmé','قيد التجهيز':'En préparation','تم الشحن':'Expédié','تم التسليم':'Livré','ملغى':'Annulé','اسم المنتج':'Nom du produit','التصنيف':'Catégorie','السعر (دج)':'Prix (DZD)','السعر القديم (اختياري)':'Ancien prix (facultatif)','المخزون':'Stock','الأيقونة':'Icône','صور المنتج (حتى 5 صور)':'Images du produit (jusqu’à 5)','رابط الصورة الأولى (اختياري)':'Lien de la première image (facultatif)','حذف كل الصور':'Supprimer toutes les images','الوصف والتفاصيل':'Description et détails','المنتج ظاهر للزبائن':'Produit visible pour les clients','ضمن المنتجات الأكثر مبيعًا':'Parmi les meilleures ventes','حفظ المنتج':'Enregistrer le produit','إزالة الصورة':'Supprimer l’image','عدد المنتجات':'Nombre de produits','إجمالي الطلبات':'Total des commandes','طلبات جديدة':'Nouvelles commandes','منطقة الخطر':'Zone dangereuse','المتجر':'Boutique','حسابك':'Votre compte','الاسم':'Nom','اللقب':'Prénom','المستخدم':'Utilisateur','العنوان':'Adresse','صور':'Images','عرض':'Afficher','نفد':'Épuisé','ظاهر':'Visible','مخفي':'Masqué','الطلب':'Commande','الطلبية':'Commande','الحالة':'Statut','الزبون':'Client','التاريخ':'Date','الإجراءات':'Actions','بدون تصنيف':'Sans catégorie','في MyStore':'Dans MyStore','مرحبًا بك 👋':'Bienvenue 👋'
    },
    en:{
      'متجرك الإلكتروني في مكان واحد':'Your online store in one place','حساباتك':'Your accounts','اختر حسابًا لتسجيل الدخول':'Choose an account to log in','لا توجد حسابات بعد':'No accounts yet','أنشئ حسابك الأول للبدء':'Create your first account to get started','إنشاء حساب جديد':'Create new account','تسجيل الدخول بالبريد الإلكتروني':'Log in with email','دخول صاحب المتجر':'Store owner login','نظام الحسابات':'Account system','العودة':'Back','إنشاء حساب':'Create account','أنشئ حسابك للبدء في استخدام المتجر':'Create your account to start using the store','اسم المستخدم':'Username','البريد الإلكتروني':'Email','كلمة المرور':'Password','تأكيد كلمة المرور':'Confirm password','إنشاء الحساب':'Create account','تسجيل الدخول':'Log in','أدخل كلمة المرور للمتابعة':'Enter your password to continue','الحسابات':'Accounts','نسيت كلمة المرور؟':'Forgot password?','تسجيل الخروج':'Log out','الرئيسية':'Home','حسابي':'My account','السلة':'Cart','الطلبات':'Orders','الإعدادات':'Settings','المنتجات':'Products','المفضلة':'Favorites','البحث':'Search','بحث':'Search','اكتشف منتجاتنا':'Discover our products','اكتشف منتجات رائعة بأسعار مميزة':'Discover great products at great prices','تصفح المنتجات':'Browse products','تصفح حسب القسم':'Browse by category','الكل':'All','الأكثر مبيعًا':'Best sellers','لا توجد منتجات':'No products','لم نجد منتجات':'No products found','جرب كلمة بحث أو قسمًا آخر':'Try another search term or category','إضافة إلى السلة':'Add to cart','إضافة للسلة':'Add to cart','إضافة للمفضلة':'Add to favorites','إزالة من المفضلة':'Remove from favorites','إتمام الطلب':'Checkout','تأكيد الطلب':'Confirm order','تأكيد الطلبية':'Confirm order','جاهز لتأكيد الطلب؟':'Ready to confirm your order?','معلومات الشاري':'Buyer information','المعلومات المطلوبة لتوصيل الطلب':'Information required for delivery','الاسم واللقب':'Full name','رقم الهاتف':'Phone number','الولاية':'Wilaya','البلدية':'Commune','العنوان بالتفصيل':'Detailed address','ملاحظات إضافية':'Additional notes','الملاحظات':'Notes','الشحن':'Delivery','الإجمالي':'Total','المجموع':'Subtotal','المجموع النهائي':'Grand total','التكلفة الإجمالية':'Total cost','الكمية':'Quantity','تفاصيل الطلب':'Order details','متابعة الطلب':'Track order','العودة إلى المتجر':'Back to store','العودة للسلة':'Back to cart','تم إرسال الطلبية بنجاح 🎉':'Order sent successfully 🎉','شكرًا لك! تم استلام طلبك بنجاح.':'Thank you! Your order was received successfully.','تحديث':'Refresh','حفظ':'Save','حفظ المعلومات':'Save information','إلغاء':'Cancel','تعديل':'Edit','حذف':'Delete','الملف الشخصي':'Profile','المعلومات الشخصية':'Personal information','تعديل معلومات الحساب':'Edit account information','عدّل معلومات حسابك':'Edit your account information','تغيير الصورة':'Change photo','صورة الحساب':'Profile photo','الأمان':'Security','الأمان وكلمة المرور':'Security and password','تغيير كلمة المرور':'Change password','كلمة المرور الحالية':'Current password','كلمة المرور الجديدة':'New password','حذف الحساب؟':'Delete account?','حذف الحساب نهائيًا':'Delete account permanently','هل أنت متأكد أنك تريد حذف هذا الحساب؟':'Are you sure you want to delete this account?','نعم، احذف الحساب':'Yes, delete account','تبديل الحساب':'Switch account','اللغة':'Language','العربية':'Arabic','الفرنسية':'French','الإنجليزية':'English','لوحة التحكم':'Dashboard','لوحة إدارة المتجر':'Store administration','لوحة صاحب المتجر':'Store owner area','إدارة المنتجات':'Product management','إدارة الطلبات':'Order management','إدارة التصنيفات':'Category management','إضافة منتج':'Add product','إضافة التصنيف':'Add category','إدارة منتجاتك وطلبات الزبائن من مكان واحد':'Manage your products and orders in one place','أضف منتجاتك وعدّل السعر والمخزون والحالة.':'Add products and edit price, stock and status.','تابع الطلبات وغيّر حالتها.':'Track orders and change their status.','كل المنتجات':'All products','الظاهرة':'Visible','المخفية':'Hidden','نفد المخزون':'Out of stock','كل الحالات':'All statuses','جديد':'New','مؤكد':'Confirmed','قيد التجهيز':'Preparing','تم الشحن':'Shipped','تم التسليم':'Delivered','ملغى':'Cancelled','اسم المنتج':'Product name','التصنيف':'Category','السعر (دج)':'Price (DZD)','السعر القديم (اختياري)':'Previous price (optional)','المخزون':'Stock','الأيقونة':'Icon','صور المنتج (حتى 5 صور)':'Product images (up to 5)','رابط الصورة الأولى (اختياري)':'First image URL (optional)','حذف كل الصور':'Delete all images','الوصف والتفاصيل':'Description and details','المنتج ظاهر للزبائن':'Product visible to customers','ضمن المنتجات الأكثر مبيعًا':'Mark as best seller','حفظ المنتج':'Save product','إزالة الصورة':'Remove image','عدد المنتجات':'Number of products','إجمالي الطلبات':'Total orders','طلبات جديدة':'New orders','منطقة الخطر':'Danger zone','المتجر':'Store','حسابك':'Your account','الاسم':'Name','اللقب':'Surname','المستخدم':'User','العنوان':'Address','صور':'Images','عرض':'Visible','نفد':'Out','ظاهر':'Visible','مخفي':'Hidden','الطلب':'Order','الطلبية':'Order','الحالة':'Status','الزبون':'Customer','التاريخ':'Date','الإجراءات':'Actions','بدون تصنيف':'No category','في MyStore':'In MyStore','مرحبًا بك 👋':'Welcome 👋'
    }
  };
  // Luffy 31 — extended interface/messages coverage.
  // Product names/descriptions and customer-entered data are intentionally not included.
  const EXTRA={
    fr:{
      '＋ إنشاء حساب جديد':'＋ Créer un nouveau compte','🔑 تسجيل الدخول بالبريد الإلكتروني':'🔑 Connexion avec e-mail','🔐 دخول صاحب المتجر':'🔐 Accès propriétaire','MyStore • نظام الحسابات':'MyStore • Système de comptes','← العودة':'← Retour','← الحسابات':'← Comptes','التصنيفات':'Catégories','إعادة ضبط':'Réinitialiser','🛍️ العودة إلى المتجر':'🛍️ Retour à la boutique','🛍️ تفاصيل المنتج':'🛍️ Détails du produit','❤️ المفضلة':'❤️ Favoris','لا توجد منتجات مفضلة':'Aucun produit favori','اضغط على ❤️ بجانب أي منتج لإضافته هنا':'Appuyez sur ❤️ à côté d’un produit pour l’ajouter ici','🛒 سلة المشتريات':'🛒 Panier','السلة فارغة':'Le panier est vide','أضف بعض المنتجات للبدء':'Ajoutez des produits pour commencer','دج':'DZD','← العودة للسلة':'← Retour au panier','أدخل معلومات الشحن لتأكيد طلبيتك':'Entrez vos informations de livraison pour confirmer votre commande','الولاية والبلدية':'Wilaya et commune','ملاحظات':'Remarques','(اختياري)':'(Facultatif)','المنتجات والكميات والتكلفة':'Produits, quantités et coût','راجع معلوماتك والمنتجات قبل إرسال الطلبية.':'Vérifiez vos informations et vos produits avant d’envoyer la commande.','سنتواصل معك باستخدام رقم الهاتف الذي أدخلته لتأكيد تفاصيل التوصيل.':'Nous vous contacterons au numéro indiqué pour confirmer les détails de la livraison.','🚪 خروج':'🚪 Déconnexion','← العودة للحساب':'← Retour au compte','إعدادات الحساب':'Paramètres du compte','🖼️ تغيير الصورة':'🖼️ Changer la photo','💾 حفظ المعلومات':'💾 Enregistrer les informations','تأكيد كلمة المرور الجديدة':'Confirmer le nouveau mot de passe','🔒 تغيير كلمة المرور':'🔒 Changer le mot de passe','حذف الحساب سيزيل بياناته من هذا الجهاز.':'La suppression du compte supprimera ses données de cet appareil.','🗑️ حذف الحساب نهائيًا':'🗑️ Supprimer définitivement le compte','تم بنجاح':'Terminé avec succès','🏠 العودة إلى الصفحة الرئيسية':'🏠 Retour à l’accueil','دخول لوحة التحكم':'Accéder au tableau de bord','🛍️ المتجر':'🛍️ Boutique','🏷️ إدارة التصنيفات':'🏷️ Gestion des catégories','أضف أي تصنيف تريده في أي وقت. التصنيف اختياري عند إضافة المنتج.':'Ajoutez une catégorie à tout moment. La catégorie est facultative lors de l’ajout d’un produit.','＋ إضافة التصنيف':'＋ Ajouter une catégorie','📦 إدارة المنتجات':'📦 Gestion des produits','＋ إضافة منتج':'＋ Ajouter un produit','🧾 إدارة الطلبات':'🧾 Gestion des commandes','↻ تحديث':'↻ Actualiser','(اختياري — يمكنك كتابة تصنيف جديد مباشرة)':'(Facultatif — vous pouvez saisir directement une nouvelle catégorie)','يمكنك اختيار حتى 5 صور من الهاتف دفعة واحدة، وسيتمكن الزبون من تصفحها كلها.':'Vous pouvez sélectionner jusqu’à 5 photos à la fois depuis votre téléphone, et le client pourra toutes les parcourir.','🔥 ضمن المنتجات الأكثر مبيعًا':'🔥 Parmi les meilleures ventes','💾 حفظ المنتج':'💾 Enregistrer le produit',
      '☁️ جاري الاتصال بـ Supabase...':'☁️ Connexion à Supabase...','☁️ متصل بـ Supabase':'☁️ Connecté à Supabase','☁️ وضع محلي':'☁️ Mode local',' — تعذر الاتصال بـ Supabase':' — Connexion à Supabase impossible','يجب تأكيد البريد الإلكتروني أولًا، ثم حاول تسجيل الدخول.':'Veuillez d’abord confirmer votre adresse e-mail, puis réessayez de vous connecter.','البريد الإلكتروني أو كلمة المرور غير صحيحة.':'Adresse e-mail ou mot de passe incorrect.','هذا البريد الإلكتروني مسجل بالفعل.':'Cette adresse e-mail est déjà enregistrée.','كلمة المرور يجب أن تكون 6 أحرف على الأقل.':'Le mot de passe doit contenir au moins 6 caractères.','تم تجاوز عدد المحاولات المسموح بها مؤقتًا. حاول لاحقًا.':'Trop de tentatives. Veuillez réessayer plus tard.','حدث خطأ أثناء الاتصال بخدمة الحسابات.':'Une erreur est survenue lors de la connexion au service des comptes.','بيانات دخول صاحب المتجر غير صحيحة.':'Les identifiants du propriétaire sont incorrects.','تم الدخول إلى لوحة صاحب المتجر':'Connexion à l’espace propriétaire réussie','تم تسجيل الخروج من لوحة المتجر':'Déconnexion de l’espace propriétaire réussie','حذف الصورة':'Supprimer la photo','أحد الملفات المختارة ليس صورة.':'L’un des fichiers sélectionnés n’est pas une image.','حجم إحدى الصور كبير جدًا. اختر صورًا أقل من 12MB للصورة الواحدة.':'Une image est trop volumineuse. Choisissez des images de moins de 12 Mo chacune.','تعذر قراءة الصورة.':'Impossible de lire l’image.','تعذر معالجة الصورة.':'Impossible de traiter l’image.','المتصفح لا يدعم معالجة الصورة.':'Le navigateur ne prend pas en charge le traitement des images.','يمكنك إضافة 5 صور فقط لكل منتج':'Vous pouvez ajouter seulement 5 images par produit','صورة':'Image','صور':'Images','تعذر تحميل الصور':'Impossible de charger les images','تعديل المنتج':'Modifier le produit','يرجى إدخال بيانات المنتج بشكل صحيح.':'Veuillez saisir correctement les informations du produit.','تم تعديل المنتج':'Produit modifié','تمت إضافة المنتج':'Produit ajouté','تم حذف المنتج':'Produit supprimé','تم الدخول إلى الحساب مباشرة':'Connexion directe au compte réussie','الاسم قصير جدًا.':'Le nom est trop court.','البريد الإلكتروني غير صحيح.':'L’adresse e-mail est incorrecte.','كلمتا المرور غير متطابقتين.':'Les deux mots de passe ne correspondent pas.','تم إنشاء الحساب وتسجيل الدخول بنجاح.':'Compte créé et connexion réussie.','تم إنشاء الحساب':'Compte créé','تم إنشاء الحساب. افتح بريدك الإلكتروني لتأكيد الحساب ثم سجّل الدخول.':'Compte créé. Ouvrez votre e-mail pour confirmer le compte, puis connectez-vous.','تم إرسال طلب إنشاء الحساب. تحقق من بريدك الإلكتروني إذا طلب منك ذلك.':'La demande de création du compte a été envoyée. Vérifiez votre e-mail si nécessaire.','تسجيل الدخول بحسابك':'Connexion à votre compte','أدخل بريدك الإلكتروني وكلمة المرور':'Entrez votre e-mail et votre mot de passe','هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول إلى حسابك.':'Cette adresse e-mail est déjà enregistrée. Vous pouvez vous connecter à votre compte.','🔑 تسجيل الدخول بهذا البريد':'🔑 Se connecter avec cet e-mail','أدخل بريدك الإلكتروني أولًا لاستعادة كلمة المرور.':'Saisissez d’abord votre adresse e-mail pour récupérer votre mot de passe.','استعادة كلمة المرور عبر البريد الإلكتروني سيتم تفعيلها في المرحلة النهائية بعد إعداد SMTP.':'La récupération du mot de passe par e-mail sera activée dans la phase finale après la configuration SMTP.','أدخل بريدك الإلكتروني.':'Saisissez votre adresse e-mail.','لم يتم إنشاء جلسة دخول صالحة.':'Aucune session de connexion valide n’a été créée.','تم تسجيل الدخول لكن تعذر إنشاء بيانات الحساب المحلية.':'Connexion réussie, mais impossible de créer les données locales du compte.','تم تسجيل الدخول':'Connexion réussie','تم تسجيل الدخول (الحساب المحلي)':'Connexion réussie (compte local)','الصورة السابقة':'Image précédente','الصورة التالية':'Image suivante','صور المنتج':'Images du produit','عرض الصورة ${index + 1}':'Afficher l’image ${index + 1}','صورة ${index + 1}':'Image ${index + 1}','♥ إزالة من المفضلة':'♥ Retirer des favoris','♡ إضافة للمفضلة':'♡ Ajouter aux favoris','تمت إزالة المنتج من المفضلة':'Produit retiré des favoris','تمت إضافة المنتج للمفضلة':'Produit ajouté aux favoris','هذا المنتج غير متوفر حاليًا':'Ce produit est actuellement indisponible','لا يمكنك تجاوز الكمية المتوفرة في المخزون':'Vous ne pouvez pas dépasser la quantité disponible en stock','تمت إضافة المنتج للسلة':'Produit ajouté au panier','حذف المنتج':'Supprimer le produit','لا يمكن تجاوز الكمية المتوفرة في المخزون':'La quantité disponible en stock ne peut pas être dépassée','تم حذف المنتج من السلة':'Produit supprimé du panier','🎉 تم تأكيد طلبك بنجاح!':'🎉 Votre commande a été confirmée avec succès !','منتج':'Produit','يرجى كتابة الاسم.':'Veuillez saisir le nom.','يرجى كتابة اللقب.':'Veuillez saisir le prénom.','يرجى كتابة رقم الهاتف بشكل صحيح.':'Veuillez saisir correctement le numéro de téléphone.','يرجى اختيار أو كتابة الولاية.':'Veuillez sélectionner ou saisir la wilaya.','يرجى كتابة الحي.':'Veuillez saisir le quartier.','يرجى كتابة العنوان بالتفصيل.':'Veuillez saisir l’adresse en détail.','لا توجد منتجات في الطلب':'Aucun produit dans la commande','بعض المنتجات لم تعد متوفرة بالكمية المطلوبة. عد إلى السلة وعدّل الكميات.':'Certains produits ne sont plus disponibles dans la quantité demandée. Retournez au panier et modifiez les quantités.','حدث خطأ أثناء إرسال الطلب. لم يتم حذف السلة، ويمكنك المحاولة مرة أخرى.':'Une erreur est survenue lors de l’envoi de la commande. Le panier n’a pas été supprimé, vous pouvez réessayer.','تم تسجيل الخروج':'Déconnexion réussie','البريد غير صحيح.':'E-mail incorrect.','البريد مستخدم في حساب آخر.':'Cet e-mail est utilisé par un autre compte.','تم حفظ المعلومات.':'Informations enregistrées.','تم تحديث الحساب':'Compte mis à jour','كلمة المرور الحالية غير صحيحة.':'Le mot de passe actuel est incorrect.','كلمة المرور الجديدة قصيرة.':'Le nouveau mot de passe est trop court.','تم تغيير كلمة المرور.':'Mot de passe modifié.','تم تغيير كلمة المرور':'Mot de passe modifié','الملف ليس صورة':'Le fichier n’est pas une image','الصورة يجب ألا تتجاوز 2MB':'L’image ne doit pas dépasser 2 Mo','تم تغيير الصورة':'Photo modifiée','تم إزالة الصورة':'Photo supprimée','تم حذف الحساب':'Compte supprimé','بدون تصنيف':'Sans catégorie','يجب تسجيل الدخول بحساب صاحب المتجر عبر Supabase قبل إدارة المنتجات سحابيًا.':'Connectez-vous avec le compte propriétaire via Supabase avant de gérer les produits dans le cloud.','هذا الحساب ليس لديه صلاحية إدارة منتجات المتجر.':'Ce compte n’a pas l’autorisation de gérer les produits de la boutique.','اكتب اسم التصنيف أولًا.':'Saisissez d’abord le nom de la catégorie.','هذا التصنيف موجود بالفعل.':'Cette catégorie existe déjà.','تمت إضافة التصنيف بنجاح.':'Catégorie ajoutée avec succès.','تمت إضافة التصنيف':'Catégorie ajoutée','تعذر إضافة التصنيف.':'Impossible d’ajouter la catégorie.','تم حذف التصنيف':'Catégorie supprimée','تعذر حذف التصنيف':'Impossible de supprimer la catégorie','اسم المنتج مطلوب، أما باقي الخانات فيمكن تركها فارغة.':'Le nom du produit est obligatoire, les autres champs peuvent rester vides.','تعذر إنشاء التصنيف الجديد في Supabase.':'Impossible de créer la nouvelle catégorie dans Supabase.','لم تُرجع Supabase المنتج بعد الحفظ؛ لم نعتبر العملية ناجحة.':'Supabase n’a pas renvoyé le produit après l’enregistrement ; l’opération n’a pas été considérée comme réussie.','تم تعديل المنتج سحابيًا':'Produit modifié dans le cloud','تمت إضافة المنتج سحابيًا':'Produit ajouté dans le cloud','تعذر حفظ المنتج في Supabase.':'Impossible d’enregistrer le produit dans Supabase.','تم حذف المنتج من Supabase':'Produit supprimé de Supabase','تعذر حذف المنتج':'Impossible de supprimer le produit','تم إظهار المنتج':'Produit rendu visible','تم إخفاء المنتج':'Produit masqué','تعذر تغيير حالة المنتج':'Impossible de modifier l’état du produit','تعذر تحديث المنتج المميز':'Impossible de mettre à jour le produit mis en avant'
    },
    en:{}
  };
  EXTRA.fr['مثال: عبدو']='Exemple : Abdo';
  EXTRA.fr['ابحث عن منتج...']='Rechercher un produit...';
  EXTRA.fr['مثال: بن علي']='Exemple : Ben Ali';
  EXTRA.fr['مثال: 0550123456']='Exemple : 0550123456';
  EXTRA.fr['الحي، الشارع، رقم المنزل...']='Quartier, rue, numéro de maison...';
  EXTRA.fr['أي ملاحظات تريد إضافتها للطلب...']='Toute remarque à ajouter à la commande...';
  EXTRA.fr['اكتب اسم تصنيف جديد...']='Saisissez le nom d’une nouvelle catégorie...';
  EXTRA.fr['اللوغو 🌳']='Logo 🌳';
  EXTRA.fr['🔎 ابحث عن منتج...']='🔎 Rechercher un produit...';
  EXTRA.fr['🔎 ابحث برقم الطلب أو اسم الزبون أو الهاتف...']='🔎 Rechercher par numéro de commande, nom du client ou téléphone...';
  EXTRA.fr['مثال: إلكترونيات أو اتركه فارغًا']='Exemple : Électronique ou laissez vide';
  EXTRA.fr['رابط الصورة الأولى (اختياري)']='URL de la première image (facultatif)';
  EXTRA.fr['يمكنك تركه فارغًا']='Vous pouvez laisser ce champ vide';
  EXTRA.en['مثال: عبدو']='Example: Abdo';
  EXTRA.en['ابحث عن منتج...']='Search for a product...';
  EXTRA.en['مثال: بن علي']='Example: Ben Ali';
  EXTRA.en['مثال: 0550123456']='Example: 0550123456';
  EXTRA.en['الحي، الشارع، رقم المنزل...']='Neighborhood, street, house number...';
  EXTRA.en['أي ملاحظات تريد إضافتها للطلب...']='Any notes you want to add to the order...';
  EXTRA.en['اكتب اسم تصنيف جديد...']='Enter a new category name...';
  EXTRA.en['اللوغو 🌳']='Logo 🌳';
  EXTRA.en['🔎 ابحث عن منتج...']='🔎 Search for a product...';
  EXTRA.en['🔎 ابحث برقم الطلب أو اسم الزبون أو الهاتف...']='🔎 Search by order number, customer name, or phone...';
  EXTRA.en['مثال: إلكترونيات أو اتركه فارغًا']='Example: Electronics or leave blank';
  EXTRA.en['رابط الصورة الأولى (اختياري)']='First image URL (optional)';
  EXTRA.en['يمكنك تركه فارغًا']='You can leave this blank';
  // English mirrors the same coverage.
  EXTRA.en={
    '＋ إنشاء حساب جديد':'＋ Create new account','🔑 تسجيل الدخول بالبريد الإلكتروني':'🔑 Log in with email','🔐 دخول صاحب المتجر':'🔐 Store owner login','MyStore • نظام الحسابات':'MyStore • Account system','← العودة':'← Back','← الحسابات':'← Accounts','التصنيفات':'Categories','إعادة ضبط':'Reset','🛍️ العودة إلى المتجر':'🛍️ Back to store','🛍️ تفاصيل المنتج':'🛍️ Product details','❤️ المفضلة':'❤️ Favorites','لا توجد منتجات مفضلة':'No favorite products','اضغط على ❤️ بجانب أي منتج لإضافته هنا':'Tap ❤️ next to a product to add it here','🛒 سلة المشتريات':'🛒 Shopping cart','السلة فارغة':'Your cart is empty','أضف بعض المنتجات للبدء':'Add some products to get started','دج':'DZD','← العودة للسلة':'← Back to cart','أدخل معلومات الشحن لتأكيد طلبيتك':'Enter your delivery information to confirm your order','الولاية والبلدية':'Wilaya and commune','ملاحظات':'Notes','(اختياري)':'(Optional)','المنتجات والكميات والتكلفة':'Products, quantities and cost','راجع معلوماتك والمنتجات قبل إرسال الطلبية.':'Review your information and products before sending the order.','سنتواصل معك باستخدام رقم الهاتف الذي أدخلته لتأكيد تفاصيل التوصيل.':'We will contact you using the phone number you entered to confirm delivery details.','🚪 خروج':'🚪 Log out','← العودة للحساب':'← Back to account','إعدادات الحساب':'Account settings','🖼️ تغيير الصورة':'🖼️ Change photo','💾 حفظ المعلومات':'💾 Save information','تأكيد كلمة المرور الجديدة':'Confirm new password','🔒 تغيير كلمة المرور':'🔒 Change password','حذف الحساب سيزيل بياناته من هذا الجهاز.':'Deleting the account will remove its data from this device.','🗑️ حذف الحساب نهائيًا':'🗑️ Permanently delete account','تم بنجاح':'Completed successfully','🏠 العودة إلى الصفحة الرئيسية':'🏠 Back to home','دخول لوحة التحكم':'Open dashboard','🛍️ المتجر':'🛍️ Store','🏷️ إدارة التصنيفات':'🏷️ Category management','أضف أي تصنيف تريده في أي وقت. التصنيف اختياري عند إضافة المنتج.':'Add any category at any time. Category is optional when adding a product.','＋ إضافة التصنيف':'＋ Add category','📦 إدارة المنتجات':'📦 Product management','＋ إضافة منتج':'＋ Add product','🧾 إدارة الطلبات':'🧾 Order management','↻ تحديث':'↻ Refresh','(اختياري — يمكنك كتابة تصنيف جديد مباشرة)':'(Optional — you can type a new category directly)','يمكنك اختيار حتى 5 صور من الهاتف دفعة واحدة، وسيتمكن الزبون من تصفحها كلها.':'You can select up to 5 photos from your phone at once, and the customer can browse them all.','🔥 ضمن المنتجات الأكثر مبيعًا':'🔥 Among best sellers','💾 حفظ المنتج':'💾 Save product',
    '☁️ جاري الاتصال بـ Supabase...':'☁️ Connecting to Supabase...','☁️ متصل بـ Supabase':'☁️ Connected to Supabase','☁️ وضع محلي':'☁️ Local mode',' — تعذر الاتصال بـ Supabase':' — Could not connect to Supabase','يجب تأكيد البريد الإلكتروني أولًا، ثم حاول تسجيل الدخول.':'Please confirm your email first, then try logging in again.','البريد الإلكتروني أو كلمة المرور غير صحيحة.':'Incorrect email or password.','هذا البريد الإلكتروني مسجل بالفعل.':'This email is already registered.','كلمة المرور يجب أن تكون 6 أحرف على الأقل.':'Password must be at least 6 characters.','تم تجاوز عدد المحاولات المسموح بها مؤقتًا. حاول لاحقًا.':'Too many attempts. Please try again later.','حدث خطأ أثناء الاتصال بخدمة الحسابات.':'An error occurred while connecting to the account service.','بيانات دخول صاحب المتجر غير صحيحة.':'Store owner credentials are incorrect.','تم الدخول إلى لوحة صاحب المتجر':'Store owner dashboard opened','تم تسجيل الخروج من لوحة المتجر':'Logged out of the store dashboard','حذف الصورة':'Delete image','أحد الملفات المختارة ليس صورة.':'One of the selected files is not an image.','حجم إحدى الصور كبير جدًا. اختر صورًا أقل من 12MB للصورة الواحدة.':'An image is too large. Choose images under 12 MB each.','تعذر قراءة الصورة.':'Could not read the image.','تعذر معالجة الصورة.':'Could not process the image.','المتصفح لا يدعم معالجة الصورة.':'Your browser does not support image processing.','يمكنك إضافة 5 صور فقط لكل منتج':'You can add only 5 images per product','صورة':'Image','صور':'Images','تعذر تحميل الصور':'Could not load images','تعديل المنتج':'Edit product','يرجى إدخال بيانات المنتج بشكل صحيح.':'Please enter the product information correctly.','تم تعديل المنتج':'Product updated','تمت إضافة المنتج':'Product added','تم حذف المنتج':'Product deleted','تم الدخول إلى الحساب مباشرة':'Logged in directly to the account','الاسم قصير جدًا.':'Name is too short.','البريد الإلكتروني غير صحيح.':'Invalid email address.','كلمتا المرور غير متطابقتين.':'Passwords do not match.','تم إنشاء الحساب وتسجيل الدخول بنجاح.':'Account created and logged in successfully.','تم إنشاء الحساب':'Account created','تم إنشاء الحساب. افتح بريدك الإلكتروني لتأكيد الحساب ثم سجّل الدخول.':'Account created. Open your email to confirm the account, then log in.','تم إرسال طلب إنشاء الحساب. تحقق من بريدك الإلكتروني إذا طلب منك ذلك.':'Account creation request sent. Check your email if needed.','تسجيل الدخول بحسابك':'Log in to your account','أدخل بريدك الإلكتروني وكلمة المرور':'Enter your email and password','هذا البريد الإلكتروني مسجل بالفعل. يمكنك تسجيل الدخول إلى حسابك.':'This email is already registered. You can log in to your account.','🔑 تسجيل الدخول بهذا البريد':'🔑 Log in with this email','أدخل بريدك الإلكتروني أولًا لاستعادة كلمة المرور.':'Enter your email address first to recover your password.','استعادة كلمة المرور عبر البريد الإلكتروني سيتم تفعيلها في المرحلة النهائية بعد إعداد SMTP.':'Email password recovery will be enabled in the final phase after SMTP setup.','أدخل بريدك الإلكتروني.':'Enter your email address.','لم يتم إنشاء جلسة دخول صالحة.':'No valid login session was created.','تم تسجيل الدخول لكن تعذر إنشاء بيانات الحساب المحلية.':'Logged in, but local account data could not be created.','تم تسجيل الدخول':'Logged in','تم تسجيل الدخول (الحساب المحلي)':'Logged in (local account)','الصورة السابقة':'Previous image','الصورة التالية':'Next image','صور المنتج':'Product images','عرض الصورة ${index + 1}':'View image ${index + 1}','صورة ${index + 1}':'Image ${index + 1}','♥ إزالة من المفضلة':'♥ Remove from favorites','♡ إضافة للمفضلة':'♡ Add to favorites','تمت إزالة المنتج من المفضلة':'Product removed from favorites','تمت إضافة المنتج للمفضلة':'Product added to favorites','هذا المنتج غير متوفر حاليًا':'This product is currently unavailable','لا يمكنك تجاوز الكمية المتوفرة في المخزون':'You cannot exceed the available stock quantity','تمت إضافة المنتج للسلة':'Product added to cart','حذف المنتج':'Delete product','لا يمكن تجاوز الكمية المتوفرة في المخزون':'Cannot exceed available stock quantity','تم حذف المنتج من السلة':'Product removed from cart','🎉 تم تأكيد طلبك بنجاح!':'🎉 Your order was confirmed successfully!','منتج':'Product','يرجى كتابة الاسم.':'Please enter the name.','يرجى كتابة اللقب.':'Please enter the surname.','يرجى كتابة رقم الهاتف بشكل صحيح.':'Please enter a valid phone number.','يرجى اختيار أو كتابة الولاية.':'Please select or enter the wilaya.','يرجى كتابة الحي.':'Please enter the neighborhood.','يرجى كتابة العنوان بالتفصيل.':'Please enter the full address.','لا توجد منتجات في الطلب':'There are no products in the order','بعض المنتجات لم تعد متوفرة بالكمية المطلوبة. عد إلى السلة وعدّل الكميات.':'Some products are no longer available in the requested quantity. Return to the cart and adjust the quantities.','حدث خطأ أثناء إرسال الطلب. لم يتم حذف السلة، ويمكنك المحاولة مرة أخرى.':'An error occurred while sending the order. The cart was not deleted; you can try again.','تم تسجيل الخروج':'Logged out','البريد غير صحيح.':'Invalid email.','البريد مستخدم في حساب آخر.':'This email is used by another account.','تم حفظ المعلومات.':'Information saved.','تم تحديث الحساب':'Account updated','كلمة المرور الحالية غير صحيحة.':'Current password is incorrect.','كلمة المرور الجديدة قصيرة.':'New password is too short.','تم تغيير كلمة المرور.':'Password changed.','تم تغيير كلمة المرور':'Password changed','الملف ليس صورة':'File is not an image','الصورة يجب ألا تتجاوز 2MB':'Image must not exceed 2 MB','تم تغيير الصورة':'Photo changed','تم إزالة الصورة':'Photo removed','تم حذف الحساب':'Account deleted','بدون تصنيف':'No category','يجب تسجيل الدخول بحساب صاحب المتجر عبر Supabase قبل إدارة المنتجات سحابيًا.':'Log in with the store owner account through Supabase before managing products in the cloud.','هذا الحساب ليس لديه صلاحية إدارة منتجات المتجر.':'This account is not authorized to manage store products.','اكتب اسم التصنيف أولًا.':'Enter the category name first.','هذا التصنيف موجود بالفعل.':'This category already exists.','تمت إضافة التصنيف بنجاح.':'Category added successfully.','تمت إضافة التصنيف':'Category added','تعذر إضافة التصنيف.':'Could not add the category.','تم حذف التصنيف':'Category deleted','تعذر حذف التصنيف':'Could not delete the category','اسم المنتج مطلوب، أما باقي الخانات فيمكن تركها فارغة.':'Product name is required; the other fields can be left empty.','تعذر إنشاء التصنيف الجديد في Supabase.':'Could not create the new category in Supabase.','لم تُرجع Supabase المنتج بعد الحفظ؛ لم نعتبر العملية ناجحة.':'Supabase did not return the product after saving; the operation was not considered successful.','تم تعديل المنتج سحابيًا':'Product updated in the cloud','تمت إضافة المنتج سحابيًا':'Product added in the cloud','تعذر حفظ المنتج في Supabase.':'Could not save the product in Supabase.','تم حذف المنتج من Supabase':'Product deleted from Supabase','تعذر حذف المنتج':'Could not delete the product','تم إظهار المنتج':'Product made visible','تم إخفاء المنتج':'Product hidden','تعذر تغيير حالة المنتج':'Could not change product status','تعذر تحديث المنتج المميز':'Could not update featured product'
  };
  const base=T.ar;
  const originals=new WeakMap();
  const ONLINE_CACHE_KEY='mystore_online_translation_cache_v1';
  let onlineCache={};
  try{ onlineCache=JSON.parse(localStorage.getItem(ONLINE_CACHE_KEY)||'{}')||{}; }catch(e){ onlineCache={}; }
  const onlinePending=new Map();
  const onlineQueue=[];
  let onlineWorkers=0;
  const MAX_ONLINE_WORKERS=3;

  function getLang(){const x=localStorage.getItem(KEY);return LANGS.includes(x)?x:'ar';}
  function clean(x){return String(x||'').replace(/\s+/g,' ').trim();}
  function saveOnlineCache(){
    try{
      const keys=Object.keys(onlineCache);
      if(keys.length>500){ keys.slice(0,keys.length-500).forEach(k=>delete onlineCache[k]); }
      localStorage.setItem(ONLINE_CACHE_KEY,JSON.stringify(onlineCache));
    }catch(e){}
  }
  function trExact(x){const k=clean(x), l=getLang(); return (EXTRA[l]&&EXTRA[l][k]) || (T[l]&&T[l][k]) || x;}
  function trPhrases(x){
    let out=String(x);
    const map=Object.assign({},T[getLang()]||{},EXTRA[getLang()]||{});
    const keys=Object.keys(map).filter(k=>k.length>=3 && !k.includes('${')).sort((a,b)=>b.length-a.length);
    for(const k of keys){ if(out.includes(k)) out=out.split(k).join(map[k]); }
    return out;
  }
  function looksArabic(x){return /[\u0600-\u06FF]/.test(String(x||''));}
  function isTranslatableText(x){
    const t=clean(x);
    if(!t || t.length<2 || !looksArabic(t)) return false;
    if(/^https?:\/\//i.test(t)) return false;
    // Currency-only labels must never be sent to an online translator.
    if(/^(دج|DA|DZD|دينار(?:\s+جزائري)?)$/i.test(t)) return false;
    // Never send prices, quantities, order numbers, dates, or currency-only
    // text to the online translator. Some translation services rewrite
    // numeric strings (e.g. 33527 دج) into formats such as 033.527.00.
    if(/^[\d٠-٩\s.,٬٫:+\-\/()%]+(?:دج|DA|DZD)?$/i.test(t)) return false;
    if(/[\d٠-٩]+/.test(t) && /(?:دج|DA|DZD|السعر|الإجمالي|الكمية)/i.test(t)) return false;
    return true;
  }
  async function fetchJson(url,ms=7000){
    const c=new AbortController(); const timer=setTimeout(()=>c.abort(),ms);
    try{ const r=await fetch(url,{signal:c.signal,cache:'no-store'}); if(!r.ok) throw new Error('HTTP '+r.status); return await r.json(); }
    finally{clearTimeout(timer);}
  }
  async function onlineTranslateText(text,target){
    const source=clean(text); if(!source || target==='ar' || !navigator.onLine) return null;
    const key=target+'|'+source;
    if(Object.prototype.hasOwnProperty.call(onlineCache,key)) return onlineCache[key];
    if(onlinePending.has(key)) return onlinePending.get(key);
    const promise=(async()=>{
      let translated=null;
      try{
        const q=encodeURIComponent(source);
        const d=await fetchJson(`https://api.mymemory.translated.net/get?q=${q}&langpair=ar|${target}`,8000);
        translated=clean(d?.responseData?.translatedText||'');
        if(!translated || translated.toLowerCase()===source.toLowerCase()) translated=null;
      }catch(e){}
      if(!translated){
        try{
          const q=encodeURIComponent(source);
          const d=await fetchJson(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl=${target}&dt=t&q=${q}`,8000);
          translated=clean(Array.isArray(d?.[0])?d[0].map(x=>x?.[0]||'').join(' '):'');
          if(!translated || translated.toLowerCase()===source.toLowerCase()) translated=null;
        }catch(e){}
      }
      if(translated){onlineCache[key]=translated;saveOnlineCache();}
      onlinePending.delete(key); return translated;
    })();
    onlinePending.set(key,promise); return promise;
  }
  function enqueueOnline(text,target,apply){
    if(!navigator.onLine || target==='ar' || !isTranslatableText(text)) return;
    const key=target+'|'+clean(text);
    onlineQueue.push({key,text:clean(text),target,apply});
    pumpOnlineQueue();
  }
  function pumpOnlineQueue(){
    while(onlineWorkers<MAX_ONLINE_WORKERS && onlineQueue.length){
      const job=onlineQueue.shift(); onlineWorkers++;
      onlineTranslateText(job.text,job.target).then(v=>{if(v) job.apply(v);}).finally(()=>{onlineWorkers--;pumpOnlineQueue();});
    }
  }
  function translateTextNode(node){
    if(!node||!node.nodeValue||!node.parentElement) return;
    const p=node.parentElement;
    if(['SCRIPT','STYLE','NOSCRIPT','OPTION','TEXTAREA'].includes(p.tagName)) return;
    if(p.closest('#mystore-language-home,#mystore-language-settings')) return;
    // Never translate financial values or their currency labels. This prevents
    // online translation services from inventing/rewriting numbers such as
    // "033.527.00" when they see Arabic currency text next to a price.
    if(p.closest('.product-price,.product-current-price,.product-old-price,.product-saving,.product-details-price,.product-details-old-price,.product-details-discount,.cart-item-price,.cart-item-total,.checkout-product-price,.checkout-product-total,#summaryTotal,#summaryItems,#bottomCartCount,.header-badge')) return;
    let original=originals.get(node);
    const current=clean(node.nodeValue);
    if(!original){
      if(!isTranslatableText(current)) return;
      original=current; originals.set(node,original);
    }
    const local=trPhrases(original);
    if(getLang()==='ar'){
      if(clean(node.nodeValue)!==original) node.nodeValue=node.nodeValue.replace(clean(node.nodeValue),original);
      return;
    }
    if(local!==original){
      if(clean(node.nodeValue)!==local) node.nodeValue=node.nodeValue.replace(clean(node.nodeValue),local);
      return;
    }
    if(clean(node.nodeValue)!==original) node.nodeValue=node.nodeValue.replace(clean(node.nodeValue),original);
    enqueueOnline(original,getLang(),v=>{
      if(originals.get(node)===original && document.contains(node) && getLang()!== 'ar'){
        const now=clean(node.nodeValue); if(now===original || now===local) node.nodeValue=node.nodeValue.replace(now,v); else node.nodeValue=v;
      }
    });
  }
  function translateAttrs(root){
    (root||document).querySelectorAll('input,textarea,button,[aria-label],[title],[placeholder]').forEach(el=>{
      ['placeholder','aria-label','title'].forEach(a=>{
        if(!el.hasAttribute(a)) return;
        const cur=el.getAttribute(a); let rec=el.dataset['i18nOriginal'+a];
        if(!rec && isTranslatableText(cur)){rec=cur;el.dataset['i18nOriginal'+a]=cur;}
        if(!rec) return;
        const local=trExact(rec);
        if(getLang()==='ar') el.setAttribute(a,rec);
        else if(local!==rec) el.setAttribute(a,local);
        else enqueueOnline(rec,getLang(),v=>{if(el.dataset['i18nOriginal'+a]===rec && getLang()!=='ar') el.setAttribute(a,v);});
      });
      if(el.tagName==='INPUT' && /^(button|submit|reset)$/i.test(el.type)){
        const cur=el.value; let rec=el.dataset.i18nOriginalValue;
        if(!rec && isTranslatableText(cur)){rec=cur;el.dataset.i18nOriginalValue=cur;}
        if(rec){const local=trExact(rec); if(getLang()==='ar')el.value=rec; else if(local!==rec)el.value=local; else enqueueOnline(rec,getLang(),v=>{if(el.dataset.i18nOriginalValue===rec&&getLang()!=='ar')el.value=v;});}
      }
    });
  }
  function translateTree(root=document.body){
    if(!root) return;
    const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);const arr=[];let n;while(n=w.nextNode())arr.push(n);arr.forEach(translateTextNode);translateAttrs(root);
  }
  function syncSelectors(){document.querySelectorAll('.mystore-lang-select,#mystore-language-select').forEach(s=>s.value=getLang());}
  function setLanguage(l){if(!LANGS.includes(l))return;localStorage.setItem(KEY,l);apply();window.dispatchEvent(new CustomEvent('mystore:languagechange',{detail:{lang:l}}));}
  function addHomeSelector(){
    if(document.getElementById('mystore-language-home')) return;
    const home=document.getElementById('homeScreen'); if(!home) return;
    const wrap=document.createElement('div');wrap.id='mystore-language-home';
    wrap.innerHTML='<span class="mystore-online-icon" title="Online translation">🌐</span><select id="mystore-language-home-select" class="mystore-lang-select" aria-label="Language"><option value="ar">🇩🇿 AR</option><option value="fr">🇫🇷 FR</option><option value="en">🇬🇧 EN</option></select>';
    home.querySelector('.home-container')?.prepend(wrap);
    wrap.querySelector('select').addEventListener('change',e=>setLanguage(e.target.value));
  }
  function addStoreSelector(){
    const slot=document.getElementById('mystore-store-language-slot');
    if(!slot || slot.querySelector('select')) return;
    slot.innerHTML='<span class="mystore-online-icon" title="Online translation">🌐</span><select class="mystore-lang-select" id="mystore-language-store-select" aria-label="Language"><option value="ar">🇩🇿 AR</option><option value="fr">🇫🇷 FR</option><option value="en">🇬🇧 EN</option></select>';
    slot.querySelector('select').addEventListener('change',e=>setLanguage(e.target.value));
  }
  function subpageBackTarget(screenId){
    const map={
      productDetails:'store', favorites:'store', cart:'store', checkout:'cart', account:'store', settings:'account', admin:'admin'
    };
    return map[screenId] || 'store';
  }
  function addSubpageNavigation(){
    const ids=['productDetailsScreen','favoritesScreen','cartScreen','checkoutScreen','accountScreen','settingsScreen','adminScreen'];
    ids.forEach(id=>{
      const screen=document.getElementById(id); if(!screen) return;
      const header=screen.querySelector('header'); if(!header) return;
      header.classList.add('mystore-subpage-header');
      let nav=header.querySelector('.mystore-subpage-nav');
      if(!nav){
        nav=document.createElement('div');
        nav.className='mystore-subpage-nav';
        nav.innerHTML='<button type="button" class="back-btn mystore-return-store"><span class="mystore-return-store-icon">🏠</span><span>العودة إلى المتجر</span></button>';
        header.prepend(nav);
        nav.querySelector('.mystore-return-store').addEventListener('click',()=>openStore());
      }
      // Keep the product title physically on the left and the return-store
      // control physically on the right, independent of RTL/LTR.
      if(id==='productDetailsScreen'){
        header.classList.add('product-details-header');
      }
      // On the profile/account page, keep MyStore centered while the
      // return-store control stays on the right.
      if(id==='accountScreen'){
        header.classList.add('account-profile-header');
      }
    });
  }
  function addSettingsSelector(){
    const settings=document.getElementById('settingsScreen')||document.querySelector('[id*="settings"]'); if(!settings) return;
    if(document.getElementById('mystore-language-settings')) return;
    const box=document.createElement('div');box.id='mystore-language-settings';box.innerHTML='<label>اللغة</label><select id="mystore-language-select"><option value="ar">🇩🇿 العربية</option><option value="fr">🇫🇷 Français</option><option value="en">🇬🇧 English</option></select>';
    const target=settings.querySelector('.settings-card,.settings-container,.screen')||settings;target.appendChild(box);
    box.querySelector('select').addEventListener('change',e=>setLanguage(e.target.value));
  }
  const nativeAlert=window.alert.bind(window), nativeConfirm=window.confirm.bind(window);
  window.alert=function(msg){ return nativeAlert(trPhrases(msg)); };
  window.confirm=function(msg){ return nativeConfirm(trPhrases(msg)); };
  function apply(){
    const l=getLang(); document.documentElement.lang=l; document.documentElement.dir=l==='ar'?'rtl':'ltr';
    addHomeSelector();addStoreSelector();addSettingsSelector();addSubpageNavigation();translateTree(document.body);syncSelectors();
    const icon=document.querySelector('.mystore-online-icon'); if(icon){icon.title=navigator.onLine?'Online translation active':'Offline — using system translations';icon.style.opacity=navigator.onLine&&l!=='ar'?'1':'.55';}
  }
  window.myStoreGetLanguage=getLang;window.myStoreSetLanguage=setLanguage;window.myStoreTranslate=trExact;window.myStoreApplyLanguage=apply;
  window.addEventListener('online',()=>apply());window.addEventListener('offline',()=>apply());
  document.addEventListener('DOMContentLoaded',()=>{apply();const obs=new MutationObserver(m=>{for(const x of m){x.addedNodes&&x.addedNodes.forEach(n=>{if(n.nodeType===1||n.nodeType===3)translateTree(n.nodeType===1?n:n.parentElement);});}});obs.observe(document.body,{childList:true,subtree:true});});
  window.addEventListener('mystore:languagechange',apply);
})();
