# MyStore — Luffy 40 Android wrapper

This project packages the supplied Luffy 40 HTML/CSS/JS as local Android app assets.

## Important behavior
- The Luffy 40 interface is bundled inside the APK; the app does not depend on CodePen to render the UI.
- JavaScript and DOM storage are enabled because the project uses localStorage/sessionStorage and JavaScript logic.
- The app can still contact Supabase and other online APIs used by Luffy 40 when an Internet connection is available.
- The product image picker supports selecting multiple images from the phone.
- Launcher icon is generated from the supplied MyStore image.

## Build
Use JDK 17 and Gradle 8.7 with Android Gradle Plugin 8.6.1.

Debug APK:
`gradle assembleDebug`

Output:
`app/build/outputs/apk/debug/app-debug.apk`
